package gui;

import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;

public class GUIHelp {

	public static void centerHor(JComponent jc) {
		
		
		Rectangle r1 = jc.getBounds();
		Container p = jc.getParent();
		
		int wp = p.getWidth(), wc = (int)r1.getWidth();
		r1.setLocation((wp-wc)/2, (int)r1.getY());
		jc.setBounds(r1);
	}
	
	static Graphics g;
	static boolean startedg = true;
	public static int getStringWidth(String s, Font f) {
		if (startedg) {
			startedg = false;
			g = (new BufferedImage(1,1,1)).getGraphics();
		}
		g.setFont(f);
		
		return g.getFontMetrics().stringWidth(s);
	}
	
	
}
