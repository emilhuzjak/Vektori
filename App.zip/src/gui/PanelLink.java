package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import vectUtilities.Constants;

public class PanelLink extends JPanel {

	private static final long serialVersionUID = -3849071524293114086L;

	JButton b = new JButton();

	public PanelLink(String text, JPanel jp) {
		b = new JButton(text);
		add(b);
		b.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				Constants.root.replacePanel(jp, true);
			}
		});
	}

}
