package vectUtilities;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class Graph extends JPanel {

	private static final long serialVersionUID = 6697552502073039091L;

	
	
	public Graph() {

	}

	public Graph(int w, int h) {
		setPreferredSize(new Dimension(w, h));
	}

	
	String xLabel="", yLabel="";
	boolean xlab = true, ylab=true;
	
	public Graph(int w, int h, double[] vals) {
		this(w,h);
		this.vals = vals;
		find();
		n = vals.length;
		x = new double[n];
		for (int i = 1; i<=n; i++) {
			x[i-1] = i;
		}
	}
	
	boolean startZero = true;
	
	double[] vals, x;
	String[] labels;

	int minNumYLines = 4, maxNumYLines = 20;
	
	
	boolean customColors = false;
	
	boolean drawDots = true;
	
	Color[] colors = new Color[] {Constants.orange, Constants.purple, Constants.orange, Constants.purple};
	
	int n;
	
	public void find() {
		double[] mm = Utility.maxmin(vals);
		min = mm[0];
		max = mm[1];
		if (startZero) min = 0;
		n = vals.length;
	}
	
	
	double marg = 0.1;
	int barSpacePix = 10;

	double max = 1, min = 0;

	int bot, left, right, top;

	
	
	public void randomTerrain(int n, double middle, double range) {
		this.n = n;
		vals = new double[n]; x = new double[n];
		for (int i = 1; i<=n; i++) {
			x[i-1] = i;
		}
		double v = Utility.random(-range,range);
		vals[0] = Utility.random(-range, range);
		for (int i = 1; i<n; i++) {
			v += Utility.random(-range,range);
			vals[i] = vals[i-1] + v + Utility.random(-10*range/2,10*range/2);
			
			//vals[i] = vals[i-1] + Utility.random(-range,range);
			
		}
		find();
	}
	
	int spaceL = 20;
	
	public boolean drawYLines = true;
	public double yLSpacing = 1;
	
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		Graphics2D g2 = (Graphics2D) g;
		

		int width = getWidth(), height = getHeight();

		bot = (int) ((1 - marg) * height);
		left = (int) (marg * width);
		top = (int) (marg * height);
		right = (int) ((1 - marg) * width);
		g.setFont(Constants.font10);

		
		int wbars = right - left-spaceL, wbar = wbars / n, hbars = bot-top;
		int xloc = left+barSpacePix;
		double scalingV = hbars*1.0/(max-min), scalingH = wbars/(x[n-1]-x[0]);
		if (drawYLines) {
			
			
			g.setColor(Constants.lgray);
			double amtFit = (max-min)/yLSpacing;
			int amtY = (int)amtFit;
			if (amtFit < minNumYLines) {
				amtY = minNumYLines;
				yLSpacing = (max-min)/amtY;
			}
			else if (amtFit > maxNumYLines) {
				amtY = maxNumYLines;
				yLSpacing = (max-min)/amtY;
			}
			
			for (int i = 0; i<amtY; i++) {
				double y = min + yLSpacing*i;
				double rectHeight = (int)((y-min)*scalingV);
				double y2 = bot-rectHeight;
				g2.drawLine((int)left, (int)y2, (int)right, (int)y2);
				//g2.drawString((int)y+"",left-20,(int)y2+5);
			}
			g2.setColor(Color.black);
			g2.setStroke(Constants.bs2);
			for (int i = 0; i<amtY; i++) {
				double y = min + yLSpacing*i;
				double rectHeight = (int)((y-min)*scalingV);
				double y2 = bot-rectHeight;
				g2.drawLine((int)left-3, (int)y2, (int)left+3, (int)y2);
				g2.drawString( (Math.abs(y)>2 ? (int)y+"" : y+"") ,left-20,(int)y2+5);
			}
			
		}
		
		g2.setColor(Constants.dark_green2);
		
		double rectHeight = (int)((vals[0]-min)*scalingV);
		double y1 = bot-rectHeight, y2;
		double x1 = left+spaceL, x2;
		for (int i = 1; i<n; i++) {
			g2.setStroke(Constants.bs2);
			if (customColors) {
				g2.setColor(colors[i]);
			}
			
			rectHeight = (int)((vals[i]-min)*scalingV);
			y2 = bot-rectHeight;
			x2 = (x[i]-x[0])*scalingH + left+spaceL;
			g2.drawLine((int)x1, (int)y1, (int)x2, (int)y2);
			if(drawDots) {
				Utility.fillCircle(g2, x1, y1, 3);
			}
			x1 = x2;
			y1 = y2;
		}
		if(drawDots) {
			Utility.fillCircle(g2, x1, y1, 3);
		}
		g2.setStroke(Constants.bs2);
		g2.setColor(Color.black);
		g2.drawLine(left, bot, right, bot);
		g2.drawLine(left, bot, left, top);
		
	}
	
	
	
	
}
