package vectUtilities;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Stroke;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Timer;

import mainpackage.MainPanel;

public class Constants {

	public static List<Timer> timers = new ArrayList<>();

	public static int fontSize = 20;
	public static Font font1 = new Font("Arial", 0, fontSize),
			font2 = new Font("Arial", 1, 20),
			font7 = new Font("Arial", 0, 7),
			font10 = new Font("Arial", 0, 10),
			font30 = new Font("Arial", 1, 30),
			font40 = new Font("Arial", 0, 40);

	
	public static MainPanel root;

	public static Color brownCol = new Color(100, 80, 30), orange = new Color(255, 150, 0),
			purple = new Color(150, 0, 255), dark_green1 = new Color(0, 100, 0), dark_green2 = new Color(0,150,0),
			lgray = new Color(200,200,200);

	
	public static String deg = "°", theta = "θ", angle = "∢", dot = "•", partialD = "∂", grad = "∇", mu = "μ",
			quadrantQ = "U kojem od četiri kvadranta vrijedi x<0 i y<0?",
			quadrantA = "Kvadranti se broje suprotno od kazaljke na satu"
					+ "\npočevši od gornje desnog. Stoga, x i y su oboje negativni"
					+ "\nu trećem kvadrantu.";
	
	
	public static Stroke bs1 = new BasicStroke(1), bs2 = new BasicStroke(2), bs3 = new BasicStroke(3),
			bs4 = new BasicStroke(4), bs5 = new BasicStroke(5);

	
	static String zad1 = "Računanje skalarnog produkta - 60 sek",
			zad2 = "Računanje kuta između vektora - 60 sek";

	public static String corr = " točnih",
			res = "Vaši rezultati", acc = "Postotak točnosti na testu",
			yes = "Da", no = "Ne";
	
	
	
	public static BufferedImage checkMarkImg = Utility.readImage("Files/images/checkmark.png");
	
}
