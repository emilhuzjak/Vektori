package vectUtilities;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class BarChart extends JPanel {

	private static final long serialVersionUID = 941552055138518495L;

	public BarChart() {

	}

	public BarChart(int w, int h) {
		setPreferredSize(new Dimension(w, h));
	}

	
	public BarChart(int w, int h, double[] vals) {
		this(w,h);
		this.vals = vals;
		find();
	}
	
	double[] vals;
	String[] labels;

	public boolean customColors = false;
	
	public Color[] colors = new Color[] {Constants.orange, Constants.purple, Constants.orange, Constants.purple};
	
	int n;
	
	public void find() {
		double[] mm = Utility.maxmin(vals);
		min = mm[0];
		max = mm[1];
		n = vals.length;
	}
	
	
	double marg = 0.1;
	int barSpacePix = 10;

	double max = 1, min = 0;

	int bot, left, right, top;

	public String yAxLabel = "", xAxLabel = "";
	public boolean labelYAxis = true, labelXAxis = true;
	
	public double spacingY = 0.1;
	public boolean yMarks = true;
	
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		Graphics2D g2 = (Graphics2D) g;
		

		int width = getWidth(), height = getHeight();

		bot = (int) ((1 - marg) * height);
		left = (int) (marg * width);
		top = (int) (marg * height);
		right = (int) ((1 - marg) * width);

		
		
		g2.setColor(Constants.orange);
		int wbars = right - left, wbar = wbars / n, hbars = bot-top;
		int xloc = left+barSpacePix;
		double scaling = hbars*1.0/max;
		for (int i = 0; i<n; i++) {
			if (customColors) {
				g2.setColor(colors[i]);
			}
			int rectHeight = (int)(vals[i]*scaling);
			g2.fillRect(xloc, bot-rectHeight, wbar-barSpacePix, rectHeight);
			xloc += wbar;
		}
		
		g2.setStroke(Constants.bs2);
		g2.setColor(Color.black);
		g2.drawLine(left, bot, right, bot);
		g2.drawLine(left, bot, left, top);
		
		g2.setFont(Constants.font1);
		if (labelYAxis) {
			g2.drawString(yAxLabel, 0, top-20);
		}
		if (labelXAxis) {
			g2.drawString(xAxLabel, (left+right)/2, bot+20);

		}
		
		if (yMarks) {
			
			for (double d = 0; d<max; d += spacingY) {
				int rectHeight = (int)(d*scaling);
				g2.drawLine(left-3, bot-rectHeight, left+3, bot-rectHeight);
				g2.drawString(Utility.roundToDec(d,1)+"", left-40, bot-rectHeight);
			}
			

		}
		
	}

}
