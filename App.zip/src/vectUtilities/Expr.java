package vectUtilities;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Expr {

	public static enum Op {
		mult, div, sqrt, square, exp, add, sub, eq;
	};

	public static Map<Op, String> opStrings = new HashMap();

	public Op op;

	public List<String> vars = new ArrayList<>();

	int numVars = 0;

	public String var;

	public List<BufferedImage> varImgs = new ArrayList<>();
	public List<Expr> subExpr = new ArrayList<>();
	BufferedImage im = new BufferedImage(1, 1, 2);

	public Expr() {
		opStrings.put(Op.mult, "*");
		opStrings.put(Op.div, "/");
		opStrings.put(Op.sqrt, "sqrt");
		opStrings.put(Op.square, "^2");
		opStrings.put(Op.exp, "^");
		opStrings.put(Op.add, "+");
		opStrings.put(Op.sub, "-");

	}

	public Expr(String s, Op o) {
		this();
		vars.add(s);
		numVars = 1;
		op = o;
		// im = Utility.expressionIm(this, 25);

	}

	public Expr(Expr e, Op o) {
		this();
		this.op = o;
		numVars = 1;
		subExpr.add(e);
		// im = Utility.expressionIm(this, 25);
	}

	public Expr(Expr e1, Expr e2, Op o) {
		this();
		this.op = o;
		numVars = 2;
		subExpr.add(e1);
		subExpr.add(e2);

	}

	@Override
	public String toString() {
		return opStrings.get(op);
	}

}
