package exercises;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;

import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class HexPicker extends GenericExercise {

	
	private static final long serialVersionUID = 3914460829906892887L;

	VTextPane ansPane = new VTextPane(), pane2 = new VTextPane();
	VTextPane taskPane = new VTextPane();
	VectorsCart vc = new VectorsCart();
	
	
	List<String> vecs = new ArrayList<>();

	LocVektor want = new LocVektor();
	int numAns = 0;
	String currV = "";
	VTextPane message = new VTextPane();
	List<String> verts = Arrays.asList(new String[] {"A","B","C","D","E","F","S"});
	boolean[] gb = new boolean[] {true};
	
	String wantV = "";
	
	Map<String, LocVektor> map = Utility.vertices(100, 6, 0, 200, 100);
	
	boolean good1 = false, good2 = false, good3 = false;
	
	public HexPicker() {

		super();
		scoreFile = "Files/scores/practice/hexpicker.txt";

		vc.setBackground(Color.white);
		next();
		add(taskPane);
		add(ansPane);
		add(pane2);
		ansPane.setBorder(BorderFactory.createLineBorder(Color.black));

		pane2.setEditable(true);
		ansPane.setEditable(true);
		List<String> newV = new ArrayList<>();
		newV.add("");
		vecs.add("");
		List<Integer> gimme = new ArrayList<>();
		boolean waiting = true;
		gimme.add(1);
		
		ansPane.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				//ansPane.readVecText("#veca#/vec = #vecb#/vec");
				//if (1==1) return;
				if (gb[0] == false) {
					return;
				} 
				//System.out.println(vecs + " " + numAns + " " + vecs.size());
				
				char c = e.getKeyChar();
				
				
				
				if (c == ',') {
					currV = "";
//					vecs.set()
				}
				
				if (c>='A' && c<='Z' || c>='a' && c<='z') {
					if (vecs.size() < 3) {
						vecs.add("");
					}
					c = Character.toUpperCase(c);
					if (numAns > 2) {
						render();
						//check();
					}
					currV = vecs.get(numAns);
					if (currV.equals("")) {
						currV = c+"";
						vecs.set(numAns, currV);
					}
					else if (currV.length() == 1) {
						currV += c;
						vecs.set(numAns, currV);
						numAns++;
						if (numAns == 2) {
							render();
							//check();
						}
						else {
							vecs.add("");
						}
					}
					if (numAns <= 2)
						render();
					
				}
				
				if (c == KeyEvent.VK_BACK_SPACE) {
					gb[0] = false;
					newV.set(numAns-1, "");
					numAns--;
					render();
					gb[0] = true;
					
				}
				
				
				if (gb[0]) {
					gb[0] = false;
					ansPane.setText("");
					ansPane.readVecText("#vec"+newV.get(0)+"#/vec");
					gb[0] = true;
				}
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		
		vc.gridLines = false;
		vc.drawAxes = false;
		vc.prePainter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				String s = "ABCDEFA";
				map = Utility.vertices(100, 6, 0, 200, 100);
				LocVektor sv = map.get("S");
				Utility.drawString(g, "S", sv.x1, sv.y1);

				Font f = g.getFont();
				g.setFont(Constants.font1);
				
				for (int i = 0; i<6; i++) {
					LocVektor v1 = map.get(s.charAt(i)+""), v2 = map.get(s.charAt(i+1)+"");
					Utility.drawLocLine(LocVektor.sub(v1, sv), g);
					Utility.drawLocLine(LocVektor.sub(v1, v2), g);
					Utility.drawString(g, s.charAt(i)+"", v1.x1, v1.y1);
				
				}
				
				g.setStroke(Constants.bs4);
				g.setColor(Color.blue);
				Utility.drawLocVector(want,g);
				
				for (int j = 0; j<Math.min(3,numAns); j++) {
					//ansPane.readVecText("#vec"+vecs.get(i)+"#/vec");
					
					String st = vecs.get(j).trim();
					System.out.println(st);
					LocVektor v = LocVektor.sub(map.get(st.charAt(1)+""),map.get(st.charAt(0)+""));
					
					if (want == null) {
						g.setColor(Color.black);
					}
					else if (want.equals(v) && !wantV.equals(st)) {
						g.setColor(Color.green);
					}
					else {
						g.setColor(Color.red);
					}
					
					Utility.drawLocVector(v, g);
					
					
				}
				g.setFont(f);
				
				
			}
		};
		add(message);
		add(vc);
	}
	
	public void render() {
		ansPane.count = 5;
		gb[0] = false;
		//ansPane.setText("");
		pane2.setText("");
		String t = "";
		for (int i = 0; i<Math.min(3,numAns); i++) {
			//ansPane.readVecText("#vec"+vecs.get(i)+"#/vec");
			t += "#vec"+vecs.get(i)+"#/vec";
			if (i < 2) {
				//ansPane.readVecText(" , ");
				t += " , ";
			}
		}
		//ansPane.readVecText(t);
		pane2.readVecText(t);
		gb[0] = true;
		vc.repaint();
	}
	int good = 0;
	@Override public void check() {
		total += 3;
		int thisc = 0;
		for (int j = 0; j<Math.min(3,numAns); j++) {
			//ansPane.readVecText("#vec"+vecs.get(i)+"#/vec");
			
			String st = vecs.get(j).trim();
			LocVektor v = LocVektor.sub(map.get(st.charAt(1)+""),map.get(st.charAt(0)+""));
			
			if (want == null) {
			}
			else if (want.equals(v)) {
				correct++;
				thisc++;
			}
			
			
			
		}
		message.setText(thisc + Constants.corr);

	}
	
	@Override public void next() {
		String let = "ABCDEFA";
		int ran = Utility.randInt(0,5);
		wantV = let.charAt(ran)+"";
		vecs.clear();
		numAns = 0;
		if (Math.random() < 0.3) {
			wantV += "S";
		}
		else wantV += let.charAt(ran+1);
		want = LocVektor.sub(map.get(let.charAt(ran+1)+""), map.get(let.charAt(ran)+""));
		taskPane.setText("");
		taskPane.readVecText("Plavom bojom je nacrtan vektor #vec" + wantV + "#/vec.\nOdredite tri druga vektora jednaka njemu i upišite ih u označeno polje.");
		ansPane.setText("");
		pane2.setText("");
		vc.repaint();
		message.setText("");
	}
	
	
}
