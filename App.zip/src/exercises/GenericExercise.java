package exercises;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import textDisplays.VTextPane;
import vectUtilities.BarChart;
import vectUtilities.Constants;
import vectUtilities.Graph;
import vectUtilities.Utility;

public class GenericExercise extends JPanel {

	boolean timing = false;
	
	String scoreFile = "";
	
	JButton b1, b2, b3, b4, b5, b6, b7;
	public GenericExercise() {
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		b1 = new JButton("Provjeri");
		b2 = new JButton("Sljedeci");
		b3 = new JButton("Resetiraj odgovore");
		b4 = new JButton("Otkrij");
		b5 = new JButton("Preskoci");
		b6 = new JButton("Mjeri");
		b7 = new JButton("Rezultati");
		
		
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				check();
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				next();
			}
		});
		
		b3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				resetAnswers();
			}
		});
		b4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				reveal();
			}
		});
		b5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				skip();
			}
		});
		b6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				time();
			}
		});
		
		b7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String name = JOptionPane.showInputDialog(total + " " + correct + "\nIme:");

				
				String sc = Utility.readFile(scoreFile);
				Map<String, Double> speedScores = new HashMap<>();
				List<Double> myScores = new ArrayList<>();
				String[] lines = sc.split("\n");
				for (String l : lines) {
					String[] ll = l.split(" ");
					if (ll.length < 4) continue;
					if (ll[0].equals(name)) {
						myScores.add(Double.parseDouble(ll[2])*1.0/Double.parseDouble(ll[3]));
					}
					double acc = Double.parseDouble(ll[2])*1.0/Double.parseDouble(ll[3]);
					String sname = ll[0];
					if (!speedScores.containsKey(sname)) {
						speedScores.put(sname, acc);
					}
					double speed = speedScores.get(sname);
					if (acc > speed) {
						speedScores.put(sname, acc);
					}
					
					JPanel p1 = new JPanel();
					//Double[] d = (Double[])speedScores.values().toArray();
					double[] dd = new double[speedScores.size()];
					int id = 0, myid = 0;
					for (String n : speedScores.keySet()) {
						dd[id] = speedScores.get(n)*100;
						if (n.equals(name)) {
							myid = id;
						}
						id++;
						
					}
					p1.add(new VTextPane("Rezultati za sve korisnike (osobni crveno):"));
					p1.setLayout(new BoxLayout(p1, BoxLayout.PAGE_AXIS));
					BarChart scoresChart = new BarChart(200,300,dd);
					scoresChart.customColors = true;
					scoresChart.colors = new Color[dd.length];
					for (int c =0; c<myid; c++) {
						scoresChart.colors[c] = Color.blue;
					}
					scoresChart.colors[myid] = Color.red;

					for (int c =myid+1; c<dd.length; c++) {
						scoresChart.colors[c] = Color.blue;
					}
					p1.add(scoresChart);
					
					double[] my = new double[myScores.size()];
					for (int i = 0; i<myScores.size(); i++) {
						my[i] = myScores.get(i);
					}
					p1.add(new VTextPane("Vasi rezultati po pokusaju:"));
					Graph g = new Graph(200,300,my);
					g.yLSpacing = 0.1;
					p1.add(new Graph(200,300,my));
					Constants.root.replacePanel(p1, true);

					
				}
				
			}
		});
		
		JPanel p = new JPanel();
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.add(b4);
		p.add(b5);
		p.add(b6);
		p.add(b7);
		add(p);
		
	}
	
	int total=0, correct=0;
	Timer timer;
	
	public void startTime() {
		timer = new Timer(t*1000, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				stopTime();
			}
		});
		timer.start();
	}
	
	int tprev = -1;
	int t=-1;
	
	public void time() {
		String tS = JOptionPane.showInputDialog("Broj sekundi: ");
		if (tS == null) return;
		
		try {
			t = Integer.parseInt(tS);
		} catch (NumberFormatException e) {
			return;
		}
		if (t>1) {
			startTime();
		}
	}
	
	public void stopTime() {
		timer.stop();
		tprev = t;
		t = -1;
		String name = JOptionPane.showInputDialog(total + " " + correct + "\nIme:");
		Utility.appendFile(scoreFile, name + " " + total + " " + correct + " " + tprev);
	}
	
	public void check() {
		System.out.println("check");
	}
	

	public void next() {
		
	}
	
	public void resetAnswers() {
		
	}
	
	public void reveal() {
		
	}
	
	public void skip() {
		
	}
	
}
