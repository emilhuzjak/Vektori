package exercises;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import mainpackage.Calculator;
import mainpackage.CoordSystemVectors;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class AngleCalc extends GenericExercise {


	private static final long serialVersionUID = -8368987186443020095L;

	VectorsCart vc = new VectorsCart();
	
	JTextArea message = new JTextArea(), ans = new JTextArea();
	
	public AngleCalc() {
		scoreFile = "Files/scores/practice/kut.txt";
		message.setFont(Constants.font1);
		ans.setFont(Constants.font1);
		ans.setBorder(BorderFactory.createLineBorder(Color.black));
		VTextPane vtp = new VTextPane();
		vtp.readVecText("Izračunajte kut u stupnjevima između dvaju vektora");
		add(vtp);
		next();
		vc.customColors = true;
		vc.colors = Arrays.asList(new Color[] {Color.blue, Color.red, Color.black});
		vc.hoverEnabled = false;
		vc.draggy = true;
		vc.gridLines = vc.drawAxes = false;
		vc.initialize(); vc.setup();
		vc.mh.conserveLength = true;
		add(message);
		vc.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				
			}
			
		};
		add(vc);
		
	}
	
	LocVektor v1, v2, res, vadd;
	
	@Override public void check() {
		total += 1;
		LocVektor v1 = vc.vecList.get(2), v2 = vc.vecList.get(2);
		double ang = v1.angleTo(v2) *180 / Math.PI;
		double angA = Double.parseDouble(ans.getText().trim());
		
		if (Math.abs(ang-angA) < 1) {
			message.setText(Constants.yes);
			correct++;
		}
		else {
			message.setText(Constants.no);
		}
	}
	
	@Override public void next() {
		int x = Utility.randInt(1, (int)(vc.xCoordSpan/5));
		if (Math.random()<0.5) x = -x;
		int y = Utility.randInt(1, (int)(vc.yCoordSpan/5));
		if (Math.random()<0.5) y = -y;
		v1 = new LocVektor(0,0,x,y);
		
		x = Utility.randInt(1, (int)(vc.xCoordSpan/5));
		if (Math.random()<0.5) x = -x;
		y = Utility.randInt(1, (int)(vc.yCoordSpan/5));
		if (Math.random()<0.5) y = -y;
		v2 = new LocVektor(0,0,x,y);
		
		
		
		
		
//		v1 = new LocVektor(0,0,Utility.random((int)(vc.x0)/2, (int)(vc.x0+vc.xCoordSpan)/2), 
//				Utility.random((int)(vc.y0)/2, (int)(vc.y0+vc.yCoordSpan)/2));
//		v2 = new LocVektor(0,0,Utility.random((int)(vc.x0)/2, (int)(vc.x0+vc.xCoordSpan)/2), 
//				Utility.random((int)(vc.y0)/2, (int)(vc.y0+vc.yCoordSpan)/2));
//		vadd = new LocVektor(0,0,Utility.random((int)(vc.x0)/2, (int)(vc.x0+vc.xCoordSpan)/2), 
//				Utility.random((int)(vc.y0)/2, (int)(vc.y0+vc.yCoordSpan)/2));
//		res = LocVektor.add(v1,v2);
		
		vc.vecList.clear();
		
		vc.putVector(v1,0,0,0,0);
		vc.putVector(v2,0,0,0,0);
		//vc.putVector(vadd,1,0,0,0);
		message.setText("");
		ans.setText("");
		vc.repaint();
	}}
