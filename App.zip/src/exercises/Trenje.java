package exercises;

import java.awt.Color;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.JTextArea;

import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import vectUtilities.Constants;
import vectUtilities.Utility;

public class Trenje extends GenericExercise {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6317089721620856113L;

	double mu = 0, m = 0, F = 0;
	
	VectorsCart vc = new VectorsCart();
	
	JTextArea message = new JTextArea(), task = new JTextArea(), ans = new JTextArea();
	
	public Trenje() {
		scoreFile = "Files/scores/practice/trenje.txt";
		message.setFont(Constants.font1);
		task.setFont(Constants.font1);
		ans.setFont(Constants.font1);

		add(new VTextPane("Na ravnoj podlozi horizontalnom silom F vučemo kutiju. Zadan je statički koeficijent trenja "
		+ Constants.mu + " i masa kutije m. Kolika je najmanja sila (u Njutnima) potrebna da se kutija pomakne? (g = 10 N/kg)"));
		next();
		
		add(task);
		add(ans);
		add(message);
		ans.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
	}
	
	LocVektor v1, v2, res, vadd;
	
	@Override public void check() {
		total++;
		double Fans = Double.parseDouble(ans.getText().trim());
		if (Math.abs(F-Fans) < 0.1) {
			message.setText("Da");
			correct++;
		}
		else message.setText("Ne");
	}
	
	@Override public void next() {
		
		
		mu = Utility.roundToDec(Utility.random(0.1, 1),3);
		m = Utility.roundToDec(Utility.random(0.5, 10),1);
		F = mu*m*10;
		message.setText("");
		ans.setText("");
		task.setText("m = " + m + "kg\n" + Constants.mu + " = " + mu);
		
	}
	
	
}
