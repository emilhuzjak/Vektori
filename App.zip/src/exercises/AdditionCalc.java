package exercises;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import vectUtilities.Constants;
import vectUtilities.Utility;

public class AdditionCalc extends GenericExercise {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6317089721620856113L;

	double mu = 0, m = 0, F = 0;

	VectorsCart vc = new VectorsCart();

	VTextPane given = new VTextPane(), ansV = new VTextPane();

	JTextArea message = new JTextArea(), task = new JTextArea(), ans = new JTextArea();

	JTextArea x = new JTextArea(), y = new JTextArea();

	int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
	int xres = 0, yres = 0;
	JPanel ansPanel = new JPanel();

	public AdditionCalc() {
		scoreFile = "Files/scores/practice/zbroj-komp.txt";
		message.setFont(Constants.font1);
		x.setFont(Constants.font1);
		y.setFont(Constants.font1);
		VTextPane vtp = new VTextPane();
		vtp.readVecText("Zadani su vektori #veca#/vec i #vecb#/vec. Izračunajte #veca#/vec + #vecb#/vec.");

		x.setPreferredSize(new Dimension(30,30));
		y.setPreferredSize(new Dimension(30,30));
		x.setBorder(BorderFactory.createLineBorder(Color.black));
		y.setBorder(BorderFactory.createLineBorder(Color.black));

		next();

		// add(ansV);
		ansPanel.add(x);
		ansPanel.add(new JLabel(new ImageIcon(Utility.buffImageText("i", 2, 20, true))));
		ansPanel.add(new JTextArea(" + "));
		ansPanel.add(y);
		ansPanel.add(new JLabel(new ImageIcon(Utility.buffImageText("j", 2, 20, true))));
		add(vtp);
		add(given);
		add(ansPanel);
		add(message);
		ansV.setBorder(BorderFactory.createLineBorder(Color.black));

	}

	LocVektor v1, v2, res, vadd;

	@Override
	public void check() {
		total++;
		double xa = Double.parseDouble(x.getText().trim()), ya = Double.parseDouble(y.getText().trim());
		if (Math.abs(xres-xa) < 0.1 && Math.abs(yres-ya) < 0.1) {
			message.setText("Da");
			correct++;
		} else
			message.setText("Ne");
	}

	@Override
	public void next() {

		
		x1 = Utility.randInt(-10, 10);
		y1 = Utility.randInt(-10, 10);
		x2 = Utility.randInt(-10, 10);
		y2 = Utility.randInt(-10, 10);
		xres = x1+x2;
		yres = y1+y2;
		x.setText("");
		y.setText("");
		given.setText("");
		given.readVecText("#veca#/vec = " + x1 + "#veci#/vec + " + y1 + "#vecj#/vec"
			+ "\n#vecb#/vec = " + x2 + "#veci#/vec + " + y2 + "#vecj#/vec");

	}

}
