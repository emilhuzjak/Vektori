package exercises;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.JTextArea;

import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class LengthBetweenPt extends GenericExercise {


	private static final long serialVersionUID = -1095847664301699058L;

	
	VectorsCart vc = new VectorsCart();
	
	JTextArea message = new JTextArea(), ans = new JTextArea();
	
	public LengthBetweenPt() {
		scoreFile = "Files/scores/practice/duljina-crtez.txt";
		message.setFont(Constants.font1);
		ans.setFont(Constants.font1);
		ans.setBorder(BorderFactory.createLineBorder(Color.black));
		add(new VTextPane("Pronađite duljinu vektora na slici."));
		next();
		vc.customColors = true;
		vc.colors = Arrays.asList(new Color[] {Color.blue, Color.blue, Color.black});
		vc.hoverEnabled = false;
		vc.draggy = true;
		vc.initialize(); vc.setup();
		vc.mh.conserveLength = true;
		add(ans);

		add(message);
		add(vc);
		
//		vc.painter = new VecPainter() {
//			
//			@Override
//			public void paint(Graphics2D g, VectorsCart cart) {
//				cart.mapAllToScreen();
//				LocVektor v1 = cart.screenVecs.get(0), v2 = cart.screenVecs.get(1);
//				v1.mid(); v2.mid();
//				g.setColor(Color.black);
//				Utility.drawFancyString(new String[] {"a"}, new int[] {1}, v1.midx, v1.midy, g);
//				Utility.drawFancyString(new String[] {"b"}, new int[] {1}, v2.midx, v2.midy, g);
//				LocVektor v2c = v2.copy();
//				v2c.scale(-1);
//				g.setColor(Color.yellow);
//				Utility.drawLocVector(v2c, g);
//			}
//		};
		
	}
	
	LocVektor v1, v2, res, vadd;
	
	@Override public void check() {
		v1 = vc.vecList.get(0);
		total++;
		double ansR = Double.parseDouble(ans.getText().trim());
		if (Math.abs(v1.r-ansR) < 0.2) {
			message.setText(Constants.yes);
			correct++;
		}
		else {
			message.setText(Constants.no);

		}
	}
	
	@Override public void next() {
		
		v1 = new LocVektor((int)Utility.random(vc.x0,vc.x0+vc.xCoordSpan),(int)Utility.random(vc.y0,vc.y0+vc.yCoordSpan),
				(int)Utility.random(vc.x0,vc.x0+vc.xCoordSpan),(int)Utility.random(vc.y0,vc.y0+vc.yCoordSpan),true);
		ans.setText("");
		
		
		
		
//		v1 = new LocVektor(0,0,Utility.random((int)(vc.x0)/2, (int)(vc.x0+vc.xCoordSpan)/2), 
//				Utility.random((int)(vc.y0)/2, (int)(vc.y0+vc.yCoordSpan)/2));
//		v2 = new LocVektor(0,0,Utility.random((int)(vc.x0)/2, (int)(vc.x0+vc.xCoordSpan)/2), 
//				Utility.random((int)(vc.y0)/2, (int)(vc.y0+vc.yCoordSpan)/2));
//		vadd = new LocVektor(0,0,Utility.random((int)(vc.x0)/2, (int)(vc.x0+vc.xCoordSpan)/2), 
//				Utility.random((int)(vc.y0)/2, (int)(vc.y0+vc.yCoordSpan)/2));
//		res = LocVektor.add(v1,v2);
		
		vc.vecList.clear();
		
		vc.putVector(v1,0,1,0,0);
		
		message.setText("");
		vc.repaint();
	}

}
