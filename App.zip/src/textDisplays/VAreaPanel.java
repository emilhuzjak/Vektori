package textDisplays;

import java.awt.Graphics;

import javax.swing.JPanel;

public class VAreaPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 982745434667759621L;

	
	VektorTextArea vta = new VektorTextArea();
	
	
	public VAreaPanel() {
		add(vta);
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		vta.repaint();
		setPreferredSize(vta.getPreferredSize());
		
	}
	
	
	
}
