package textDisplays;

import java.awt.FontMetrics;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TextUtilities {

	
	public static FontMetrics fm;
	
	
	public static List<String> splitOnWhitespace(String s) {

		
		
		int len = s.length();

		
		
		List<String> ha = new ArrayList<>();
		if (!s.contains(" ") && !s.contains("\n") && !s.contains("\t")) {
			ha.add(s);
			return ha;
		}
		int i = 0;
		for (i = 0; i < len; i++) {
			char c = s.charAt(i);
			if (c != ' ' && c != '\n' && c != '\t') {
				break;
			}
		}
		if (i > 0) {
			ha.add(s.substring(0, i));
		}
		int iprev = i;
		int j = 0;
		boolean spaces = false;
		for (; i < len; i++) {
			char c = s.charAt(i);
			if (c == ' ' || c == '\n' || c == '\t') {
				if (!spaces)
					spaces = true;
			} else {
				if (spaces) {
					spaces = false;
					String sub = s.substring(iprev, i);
					ha.add(sub);
					iprev = i;
				}
			}

		}
		if (iprev < len - 1) {
			ha.add(s.substring(iprev, len));
		}
		return ha;

	}
	
	
	public static List<Integer> findSpecialPos(String text, String sep, String sep1) {
		
		List<Integer> m = new ArrayList<>();
		
		
		
		return m;
		
	}
	
	static List<Pair> wrappedLocations = new ArrayList<>();
	
	
	
	
	
	static int maxWidth = 0, currW = 0;
	static String line = "";
	
	public static List<String> wrapText(String text, int width, List<Integer> pos) {
		if (fm == null) {
			return null;
		}
		List<String> l = new ArrayList<>();
		int nextPosInd = 0, numPos = pos.size(), nextPos = (numPos > 0 ? pos.get(0) : Integer.MAX_VALUE);
		int totalCharLength = 0;
		wrappedLocations.clear();
		String[] split = text.split("\n");
		for (int i = 0; i<split.length; i++) {
			List<String> paragraph = splitOnWhitespace(split[i]);
			String line = "";
			
			int lineWidth = 0;
			String word = "";
			boolean carry = false;
			String carryWord = "";
			boolean parStart = true;
			int parLen = paragraph.size();
			for (int j = 0; j<parLen; j++) {
				word = paragraph.get(j);
				int wordLen = word.length();
				
				if (carry) {
					carry = false;
					int wordWidth = fm.stringWidth(carryWord);
					if (wordWidth > width && lineWidth == 0) {
						line = carryWord;
						l.add(line);
						lineWidth = 0;
						continue;
					}
					if (totalCharLength + wordLen > nextPos) {
						String sub = word.substring(0, nextPos - totalCharLength);
						wrappedLocations.add(new Pair(l.size(), lineWidth + fm.stringWidth(sub))); // neinnnnn
						nextPosInd++;
						nextPos = (numPos > nextPosInd ? pos.get(nextPosInd) : Integer.MAX_VALUE);

						
					}
					totalCharLength += wordLen;
				}
				
				if (totalCharLength + wordLen > nextPos) {

					String sub = word.substring(0, nextPos - totalCharLength);
					wrappedLocations.add(new Pair(l.size(), lineWidth + fm.stringWidth(sub))); // neinnnnn
					nextPosInd++;
					nextPos = (numPos > nextPosInd ? pos.get(nextPosInd) : Integer.MAX_VALUE);

				}
				totalCharLength += wordLen;
				
				
				
				int wordWidth = fm.stringWidth(word);
				
				if (wordWidth > width && lineWidth == 0) {
					line = word;
					l.add(line);
					lineWidth = 0;
					continue;
				}
				lineWidth += fm.stringWidth(word);
				if (lineWidth < width) {
					line += word;
				}
				else {
					l.add(line);
					line = "";
					lineWidth = 0;
					carry = true;
					carryWord = word;
				}
				parStart = false;
			}
			
			totalCharLength++;
			
			
			
		}
		
		
		
		return l;
	}
	
	
	static class Pair{
		int x, y;
		public Pair(int x, int y) {
			this.x = x; this.y = y;
		}
	}
	
	
}
