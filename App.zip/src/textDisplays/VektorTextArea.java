package textDisplays;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextArea;

import mainpackage.LocVektor;
import vectUtilities.Constants;
import vectUtilities.Utility;

public class VektorTextArea extends JTextArea {

	private static final long serialVersionUID = 2132556772351390786L;

	int fontSize = Constants.fontSize;
	Font f = new Font("Calibri", 0, fontSize);
	int fontHeight = 25;

	int start, end;
	int row;

	int numRows = 1;
	
	List<Integer> starts = new ArrayList<>(), ends = new ArrayList<>(), vecRows = new ArrayList<>();

	List<String> textParts = new ArrayList<>();
	List<Integer> arrowed = new ArrayList<>();

	int currentNumLines = 0;

	private int w = 0, h = 0;

	public VektorTextArea() {
		setEditable(false);
		setLineWrap(true);
		setWrapStyleWord(true);
		setFont(f);
		fontHeight = getRowHeight();
		getCaret().setBlinkRate(0);
	}
	
	

	public void writeVText(String text, boolean arrow) {

		if (arrow) {
			//starts.add(getCaretPosition());
			arrowed.add(1);
		}
		else {
			arrowed.add(0);
		}
		append(text);
		
		textParts.add(text);
	}

	
	
	
	public List<String> splitOnWhitespace(String s) {

		
		
		int len = s.length();

		
		
		List<String> ha = new ArrayList<>();
		if (!s.contains(" ") && !s.contains("\n") && !s.contains("\t")) {
			ha.add(s);
			return ha;
		}
		int i = 0;
		for (i = 0; i < len; i++) {
			char c = s.charAt(i);
			if (c != ' ' && c != '\n' && c != '\t') {
				break;
			}
		}
		if (i > 0) {
			ha.add(s.substring(0, i));
		}
		int iprev = i;
		int j = 0;
		boolean spaces = false;
		for (; i < len; i++) {
			char c = s.charAt(i);
			if (c == ' ' || c == '\n' || c == '\t') {
				if (!spaces)
					spaces = true;
			} else {
				if (spaces) {
					spaces = false;
					String sub = s.substring(iprev, i);
					ha.add(sub);
					iprev = i;
				}
			}

		}
		if (iprev < len - 1) {
			ha.add(s.substring(iprev, len));
		}
		return ha;

	}
	
	public void readVecText(String t) {
		List<String> parts = Utility.splitSections(t, "#vec", "#/vec");
		String f = parts.remove(0);
		int arrowF = 0;
		if (f.equals("1")) {
			arrowF = 1;
		}
		for (String s : parts) {
			writeVText(s, arrowF==1);
			arrowF = 1 - arrowF;
		}
	}

	

	
	FontMetrics metr;

	
	
	
	int totalRows = 1;
	
	
	public void adjustTextWrap() {
		
		
		text = "";
		if (!arrowed.contains(1)) {
			
			for (String part : textParts) {
				text += part;
				
			}
			totalRows = Utility.countMatches(text, "\n")+2;
			return;
		}
		
		text = "";
		w = getWidth();
		if (w <= 0) {
			return;
		}

		int numParts = textParts.size();
		int rowadjust = 0;
		int wNow = 0;
		vecRows.clear();
		starts.clear();
		ends.clear();
		
		
		for (int i = 0; i < numParts; i++) {
			boolean arrow = arrowed.get(i) == 1;
			
			
			if (arrow) {
				starts.add(wNow);
			}
			
			int startRow = rowadjust;
			//int endRow = startRow;
			String part = textParts.get(i);
			List<String> l = splitOnWhitespace(part);
			if (i == numParts-1) {
			}
			String[] partWords = (l.toArray(new String[l.size()])); // treats multiple spaces in a row like a single space

			int wordNum = partWords.length;
			for (int j = 0; j < wordNum; j++) {
				String word = partWords[j];
				int wordLen = metr.stringWidth(word);
				
				if (wNow + wordLen > w) {
					if (wNow == 0) {
						text += word + " \n";
						// endRow++;
						rowadjust++;
					} else {
						rowadjust++;
						// startRow = rowadjust;
						wNow = wordLen;
						text += "\n" + word;
					}
				} else {
					text += word;
					if (j == wordNum-1) {
					}
					if (word.contains("\n")) {
						wNow = 0;
						rowadjust += Utility.countMatches(word, "\n");
					}
					else {
						wNow += wordLen;
					}
					
				}
			}
			

			// int arr = arrowed.get(i);

			if (arrow) {
				ends.add(wNow);
				vecRows.add(rowadjust);
			}
			
		}
		totalRows = rowadjust+1;

		

	}

	String text = "", origText = "";

	boolean drawArrows = true;
	
	@Override
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setStroke(new BasicStroke(2));
		// Utility.drawLocVector(new LocVektor(start, row, start - end, 0), (Graphics2D)
		// g);
		text = getText();
		int wp = getParent().getWidth(), hp = getParent().getHeight();
		
		int wnew = (int)getPreferredSize().getWidth();
		if (wnew != w) {
			w = wnew;
			metr = g.getFontMetrics();
			adjustTextWrap();
			setText(text);
		}
		//System.out.println(text);
		
		
		
		if (wp != 0 && hp != 0) {
			int match = Utility.countMatches(text, "\n");
			setPreferredSize(new Dimension(wnew, (match+2) * fontHeight));
		}
		

		
		int size = starts.size();
		for (int i = 0; i<size; i++) {
			if (!drawArrows) break;
			int y = (vecRows.get(i))*fontHeight;
			if (starts.get(i) <= ends.get(i))
			Utility.drawLocVector(new LocVektor(starts.get(i), y, ends.get(i)+2, y, true), g2);
		}
		


	}

}
