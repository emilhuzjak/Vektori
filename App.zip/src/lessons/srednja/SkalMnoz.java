package lessons.srednja;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class SkalMnoz extends SpecificLessonPanel {

	private static final long serialVersionUID = -6869605401107018250L;

	public SpecificLessonPanel nextPanel() {
		return new Kosina();
	}

	String path = "Files/lessons/srednja/skal_mnoz/";

	// LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3;
	VTextPane vtp1 = new VTextPane();

	public SkalMnoz() {
		

		setTitle(Utility.getLessonTitle("SkalMnoz"));
		
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();

		String dot = Constants.dot, deg = Constants.deg;

		vc1 = new VectorsCart();
		vc1.putVector(LocVektor.polarVec(5, 0.7), 1, 0, 0, 0);
		vc1.putVector(LocVektor.polarVec(2, 1.1), 1, 0, 0, 0);
		vc1.xCoordSpan = 20;
		vc1.yCoordSpan = 20;
		vc1.x0 = -10;
		vc1.y0 = -10;
		vc1.setVert = false;
		vc1.setPreferredSize(new Dimension(20, 500));
		vc1.initialize();
		vc1.setup();
		vc1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v1.scaleToR(5);
				v2.scaleToR(2);
				cart.mapAllToScreen();
				LocVektor v1s = cart.screenVecs.get(0), v2s = cart.screenVecs.get(1);
				cart.map(0, 0);
				double ang = v1.angleFrom(v2);
				double closeAng = v1.closestAngleToward(v2);
				g.setColor(Color.red);
				g.setStroke(Constants.bs2);
				Utility.drawArc(g, v1s.x0, v1s.y0, 50, Utility.roundToDec(v1.angle * 180 / Math.PI, 1),
						Utility.roundToDec(closeAng * 180 / Math.PI, 1));
				double dotD = v1.dot(v2);
				g.setColor(Color.white);
				g.setFont(Constants.font1);
				int w = cart.getWidth(), h = cart.getHeight();

				g.fillRect(10, h - 30, w - 20, 30);
				g.setColor(Color.black);
				g.setStroke(Constants.bs3);
				int marg = 20;
				Utility.drawLine(10 + marg, h - 15, w - 20 - marg, h - 15, g);
				Utility.drawLine(10 + marg, h - 10, 10 + marg, h - 20, g);
				Utility.drawLine(w / 2, h - 10, w / 2, h - 20, g);
				Utility.drawLine(w - 20 - marg, h - 10, w - 20 - marg, h - 20, g);
				g.drawString("-10", 10 + marg, h - 5);
				g.drawString("0", w / 2, h - 5);
				g.drawString("10", w - 10 - marg, h - 5);

				g.setColor(Color.red);
				Utility.fillCircle(g, Utility.map(10 + marg, w - 20 - marg, -10, 10, dotD), h - 15, 5);
				if (cart.held >= 0) {
					vtp1.setText("");

					vtp1.readVecText(Constants.theta + " = " + Utility.roundToDec(ang * 180 / Math.PI, 1) + deg
							+ "\n#veca#/vec " + dot + "#vecb#/vec = 5" + dot + "2 cos"
							+ Utility.roundToDec(ang * 180 / Math.PI, 1) + " = " + Utility.roundToDec(dotD, 1));
				}

				g.setColor(Color.black);
				g.setStroke(Constants.bs1);
			}
		};
		contents.add(vc1);
		contents.add(vtp1);

		addNewText(texts[1]);
		queueText();

		VTextPane vtp2 = new VTextPane();

		vc2 = new VectorsCart();
		// vc2.hoverEnabled = false;
		vc2.xCoordSpan = 20;
		vc2.yCoordSpan = 20;
		vc2.putVector(new LocVektor(0, 0, 1, 2), 1, 0, 0, 0);
		vc2.putVector(new LocVektor(0, 0, -2, -1), 1, 0, 0, 0);
		vc2.initialize();
		vc2.setup();
		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v1.x = Utility.roundInt(v1.x);
				v1.y = Utility.roundInt(v1.y);
				v2.x = Utility.roundInt(v2.x);
				v2.y = Utility.roundInt(v2.y);

			}
		};

		contents.add(vc2);

		vtp2.setPreferredSize(new Dimension(42, 200));

		JPanel jp = new JPanel();
		JButton discB = new JButton("Otkrij");
		jp.add(discB);
		contents.add(jp);
		contents.add(vtp2);

		discB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LocVektor v1 = vc2.vecList.get(0), v2 = vc2.vecList.get(1);

				vtp2.setText("");
				vtp2.readVecText("#veca#/vec = " + v1.VText(0) + "\n#vecb#/vec = " + v2.VText(0));
				vtp2.readVecText("\n#veca#/vec " + dot + " #vecb#/vec = " + v1.dot(v2));

			}
		});

		addNewText(texts[2]);
		queueText();

		BufferedImage ima = Utility.buffImageText("a", 1, 25, true), imb = Utility.buffImageText("b", 1, 25, true),
				dotim = Utility.buffImageText(dot, 1, 25, false),
				imp = Utility.conc(new BufferedImage[] { ima, dotim, imb }, 0, 0);

		BufferedImage denom = Utility.conc(new BufferedImage[] { Utility.drawModulus(ima), Utility.drawModulus(imb) },
				0, 0);

		BufferedImage frac = Utility.frac(imp, denom), form = Utility.conc(
				new BufferedImage[] { Utility.buffImageText("cos" + Constants.theta + " = ", 1, 25, false), frac }, 0,
				0);
		JPanel jpform = new JPanel();
		jpform.add(new JLabel(new ImageIcon(form)));

		BufferedImage form2 = Utility.conc(new BufferedImage[]
				{Utility.buffImageText(Constants.theta + " = cos", 1, 25, false), Utility.exp("-1", 25),frac }, 0,0);

		contents.add(jpform);
		
		JPanel jpform2 = new JPanel();
		jpform2.add(new JLabel(new ImageIcon(form2)));
		contents.add(jpform2);

		addNewText(texts[3]);
		queueText();

		VTextPane vtp3 = new VTextPane();
		
		vc3 = vc2.copy();
		contents.add(vc3);
		JPanel jp2 = new JPanel();
		JButton discB2 = new JButton("Otkrij");
		jp2.add(discB2);
		contents.add(jp2);
		contents.add(vtp3);
		vtp3.setPreferredSize(new Dimension(42, 200));
		discB2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LocVektor v1 = vc3.vecList.get(0), v2 = vc3.vecList.get(1);

				vtp3.setText("");
				vtp3.readVecText("#veca#/vec = " + v1.VText(0) + "\n#vecb#/vec = " + v2.VText(0));
				vtp3.readVecText("\n#veca#/vec " + dot + " #vecb#/vec = " + v1.dot(v2));
				vtp3.readVecText("\n"+Constants.theta + " = " + Utility.roundToDec(v1.angleTo(v2)*180/Math.PI,1)
					+Constants.deg);
				
			}
		});
		
		showQueue();
	}

}
