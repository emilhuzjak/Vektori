package lessons.srednja;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.util.Arrays;

import javax.swing.JPanel;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class KolinUvod extends SpecificLessonPanel {

	private static final long serialVersionUID = -8474780828380878342L;

	public SpecificLessonPanel nextPanel() {
		return new Kolin();
	}

	String path = "Files/lessons/srednja/kolinnez/";

	// LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3, t4, t5;

	boolean moving = false;

	public KolinUvod() {

		setTitle(Utility.getLessonTitle("KolinUvod"));
		
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();

		JPanel jp1 = new JPanel();
		jp1.setLayout(new GridLayout(1, 2));
		jp1.setPreferredSize(new Dimension(1, 200));
		VectorsCart vcp1 = new VectorsCart(), vcp2 = new VectorsCart();
		vcp1.putVector(new LocVektor(0, 0, 2, 4), 0, 0, 0, 0);
		vcp1.putVector(new LocVektor(0, 0, 1, 2), 0, 0, 0, 0);
		vcp1.customColors = true;
		vcp1.colors = Arrays.asList(new Color[] { Color.red, Color.blue });
		vcp2.putVector(new LocVektor(0, 0, 2, 4), 0, 0, 0, 0);
		vcp2.putVector(new LocVektor(0, 0, -1, -2), 0, 0, 0, 0);
		vcp2.customColors = true;
		vcp2.colors = Arrays.asList(new Color[] { Color.red, Color.blue });
		jp1.add(vcp1);
		jp1.add(vcp2);
		JPanel jp2 = new JPanel();
		jp2.setLayout(new GridLayout(1, 2));
		jp1.setPreferredSize(new Dimension(1, 200));
		jp2.add(new VTextPane("Kolinearni vektori, isti smjer"));
		jp2.add(new VTextPane("Kolinearni vektori, antiparalelni (suprotni smjer)"));

		contents.add(jp1);
		contents.add(jp2);

		addNewText(texts[1]);
		queueText();

		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0, 0, 1, 2), 1, 0, 0, 0);
		vc1.putVector(new LocVektor(0, 0, -5, 1), 1, 0, 0, 0);
		vc1.customColors = true;
		vc1.colors = Arrays.asList(new Color[] { Color.red, Color.blue });
		vc1.initialize();
		vc1.setup();
		vc1.prePainter = new VecPainter() {
			boolean colin = false;

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				double angle = v1.angleTo(v2);

				if ((angle < 0.1 || angle > Math.PI - 0.1)) {
					
						if (cart.mh.endHeld == 0)
							v1.setAngle(angle < Math.PI / 2 ? v2.angle : v2.angle + Math.PI);
						else if (cart.mh.endHeld == 1)
							v2.setAngle(angle < Math.PI / 2 ? v1.angle : v1.angle + Math.PI);

						colin = true;
					
				} else {
					colin = false;
				}
				g.setFont(Constants.font1);
				g.drawString(colin ? "Kolinearni" : "Nezavisni", 25, 25);

			}
		};
		contents.add(vc1);

		addNewText(texts[2]);
		queueText();
		vc2 = new VectorsCart();
		vc2.putVector(new LocVektor(0, 0, 5, 0), 1, 0, 0, 0);
		vc2.putVector(new LocVektor(0, 0, 2, 3), 1, 0, 0, 0);
		vc2.initialize();
		vc2.setup();
		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.vecList.get(0).x = 0;

			}
		};
		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				Utility.drawParallelogramRule(g, cart.vecList.get(0), cart.vecList.get(1));
			}
		};
		contents.add(vc2);

		addNewText(texts[3]);
		queueText();

		showQueue();

	}

}
