package lessons.srednja;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Arrays;

import javax.swing.JTextArea;

import gui.PanelLink;
import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Kolin extends SpecificLessonPanel {

	
	private static final long serialVersionUID = -4314860224602494383L;

	String path = "Files/lessons/srednja/kolin/";

	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new Polar();
	}
	
	JTextArea jta1 = new JTextArea(), jta2 = new JTextArea();
	
	boolean moving = false;
	
	public Kolin() {

		setTitle(Utility.getLessonTitle("Kolin"));
		
		
		jta1.setFont(Constants.font40);
		jta2.setFont(Constants.font40);

		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();
		
		
		vc1 = new VectorsCart();
		vc1.setBackground(Color.cyan);
		//vc1.gridLines = false;
		LocVektor lv = new LocVektor(0,0,3,2);
		vc1.putVector(lv, 0,0,0,0);
		//vc1.visible.set(0,0);
		vc1.putVector(new LocVektor(0,0,1,-3), 1,0,0,0);
		vc1.customColors = true;
		vc1.colors = Arrays.asList(new Color[]{Color.red, Color.blue});
		vc1.hoverEnabled = true;
		vc1.draggy = true;
		vc1.mh.r = 500;
		//vc1.xCoordSpan = 40;
		vc1.initialize(); vc1.setup();
		vc1.prePainter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(1);
				v1.y = -3;
				
			}
		};
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				
				cart.mapAllToScreen();
				g.setFont(Constants.font30);

				LocVektor v1 = cart.screenVecs.get(0), v2 = cart.screenVecs.get(1);
				g.setColor(Color.black);
				Utility.drawFancyString(new String[] {"a"}, new int[] {1}, (v1.x0+v1.x1)/2, (v1.y0+v1.y1)/2, g);
				Utility.drawFancyString(new String[] {"b"}, new int[] {1}, (v2.x0+v2.x1)/2, (v2.y0+v2.y1)/2, g);

				g.setColor(Color.red);
				cart.map(-4.5,-3);
				g.drawLine(0,cart.ys,cart.getWidth(),cart.ys);
				if (Math.abs(v2.x1-cart.xs)<10) {
					Utility.fillCircle(g, cart.xs, cart.ys, 7);
					g.drawString("Uspjeh", 30, 30);
				}
				
			}
			
		};
		
		contents.add(vc1);
		
		
		addNewText(texts[1]);
		queueText();
		
//		lastPane.add(new JButton("Podsjeti?"));
		contents.add(new PanelLink("Podsjeti?" , new Svojstva()));
		
		addNewText(texts[2]);
		queueText();
		contents.add(new PanelLink("Podsjeti?" , new KolinUvod()));

		addNewText(texts[3]);
		queueText();
		
		
		

		
		
		
		//---------------------------------------------------------------
		showQueue();




	}
}
