package lessons.srednja;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Expr;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Polar extends SpecificLessonPanel {


	
	private static final long serialVersionUID = -4314860224602494383L;

	String path = "Files/lessons/srednja/polarno/";

	VectorsCart vc1, vc2, vc3, vc4;
	VektorTextArea t1, t2, t3;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new Proj();
	}
	
	JTextArea jta1 = new JTextArea(), jta2 = new JTextArea();
	
	boolean moving = false;
	
	JTextArea text = new JTextArea(),
			text2 = new JTextArea();
	
	public Polar() {
		

		setTitle(Utility.getLessonTitle("Polar"));
		
		
		text.setFont(Constants.font30);
		text.setFont(Constants.font1);

		jta1.setFont(Constants.font40);
		jta2.setFont(Constants.font40);

		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();
		
		VectorsCart example2 = new VectorsCart();
		LocVektor a = new LocVektor(1,2);
		example2.putVector(a,1,0,0,0);
		example2.draggy = true;
		example2.gridLines = false;
		example2.initialize(); example2.setup();
		
		example2.prePainter = new VecPainter() {
			@Override public void paint(Graphics2D g, VectorsCart cart) {
				if (a.r > 5) {  a.scaleToR(5);  } // duljina je ogranicena na 5
			}
		};
		example2.painter = new VecPainter() {
			@Override public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				LocVektor aScreen = cart.screenVecs.get(0);
				g.setColor(Color.red);
				g.setFont(Constants.font1);
				double angleDeg = a.angle * 180/Math.PI;
				
				// nacrtati luk polumjera 50
				Utility.drawArc(g, aScreen.x0, aScreen.y0, 50, 0, angleDeg);
				
				// napisati mjeru kuta na luk
				Utility.drawString(g, Utility.roundToDec(angleDeg, 1)+Constants.deg,
						aScreen.x0+60*Math.cos(a.angle/2), aScreen.y0-60*Math.sin(a.angle/2));
				
				text.setText("Duljina: " + Utility.roundToDec(a.r, 1) +
						"\n" + Constants.theta + " = " + Utility.roundToDec(a.angle*180/Math.PI, 1) + Constants.deg);
			}
		};
		
		
		text.setPreferredSize(new Dimension(200,70));
		contents.add(example2);
		contents.add(text);
		
		addNewText(texts[1]);
		queueText();
		
		JPanel jp4 = new JPanel();
		jp4.setPreferredSize(new Dimension(200, 500));
		jp4.setLayout(new GridLayout(2,2));
		int[] angles = new int[] {0, 90, 180, 270};
		for (int i = 0; i<4; i++) {
			
			int iii = i;
			
			VectorsCart v = new VectorsCart();
			v.putVector(LocVektor.polarVec(2,i*Math.PI/2),0,0);
			// LocVektor.polarVec(2,i*Math.PI/2)
			v.gridLines = false;
			v.painter = new VecPainter() {
				int ii = Integer.valueOf(iii);
				@Override
				public void paint(Graphics2D g, VectorsCart cart) {
					LocVektor lv = cart.vecList.get(0);
					cart.mapAllToScreen();
					LocVektor aScreen = cart.screenVecs.get(0);
					double angleDeg = lv.angle*180/Math.PI;
					g.setColor(Color.red);
					Utility.drawArc(g, aScreen.x0, aScreen.y0, 50, 0, angleDeg);
					
					
					Utility.drawString(g, angles[iii]+Constants.deg,
							aScreen.x0+60*Math.cos(a.angle/2), aScreen.y0-60*Math.sin(a.angle/2));
				}
				
			};
			JPanel vp = new JPanel();
			vp.add(v);
			jp4.add(vp);
			
		}
		
		contents.add(jp4);
		
		addNewText(texts[2]);
		queueText();
		
		VTextPane vtp1 = new VTextPane();
		vtp1.setPreferredSize(new Dimension(200,200));
		
		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0,0,1,3),0,0,1,0);
		vc1.draggy = true;
		vc1.setup();
		vc1.initialize();
		vc1.painter = new VecPainter() {
			@Override public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				LocVektor lv = cart.vecList.get(0);
				LocVektor aScreen = cart.screenVecs.get(0);
				g.setColor(Color.red);
				g.setFont(Constants.font1);
				double angleDeg = lv.angle * 180/Math.PI;
				
				// nacrtati luk polumjera 50
				Utility.drawArc(g, aScreen.x0, aScreen.y0, 50, 0, angleDeg);
				
				// napisati mjeru kuta na luk
				Utility.drawString(g, Utility.roundToDec(angleDeg, 1)+Constants.deg,
						aScreen.x0+60*Math.cos(a.angle/2), aScreen.y0-60*Math.sin(a.angle/2));
				vtp1.setText("");
				vtp1.readVecText("#vecv#/vec = #vec<"+Utility.roundToDec(lv.r,1)+", "+Utility.roundToDec(angleDeg,1)+Constants.deg+">#/vec");
				vtp1.readVecText("\n#vecv#/vec = " + Utility.roundToDec(lv.x,1) + "#veci#/vec + "
						+ Utility.roundToDec(lv.y,1) + "#vecj#/vec\n");
				BufferedImage vim = Utility.buffImageText("v", 3, 30, true);
				vtp1.insertImage(Utility.frac(vim, Utility.drawModulus(vim)));
				vtp1.insertImage(Utility.frac(Utility.buffImageText("1", 20, 20, false), Utility.buffImageText("2", 20, 20, false)));

			}
		};
		
		contents.add(vc1);
		contents.add(vtp1);
		
		addNewText(texts[3]);
		queueText();
		
		vc2 = new VectorsCart();
		vc2.draggy = true; vc2.hoverEnabled = false;
		vc2.mh.r = 500;
		LocVektor v = new LocVektor(0,0,3,4);
		vc2.putVector(v,1,0,0,0);
		vc2.putVector(new LocVektor(0,0,3,0), 0,0,0,0);
		vc2.putVector(new LocVektor(0,0,0,4), 0,0,0,0);
		vc2.visible.set(1,0);		vc2.visible.set(2,0);
		
		
		vc2.customColors = true;
		vc2.colors = Arrays.asList(new Color[] {Color.black, Color.red, Color.red});
		vc2.initialize(); vc2.setup();
		vc2.prePainter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
//				
				LocVektor vc = cart.vecList.get(1), v = cart.vecList.get(0), vcy = cart.vecList.get(2);

				vc = cart.vecList.get(1);
				vc.x = v.x;
				vc.fix();
				
				vcy = cart.vecList.get(2);
				vcy.y = v.y;
				
				vcy.fix();
				vcy.translateTo(vc.x1,vc.y1);
			}
		};
		
		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				
				
				
				cart.mapAllToScreen();
				
				g.setColor(Color.black);
				
				LocVektor vs = cart.screenVecs.get(0);
				Utility.drawArc(g, vs.x0, vs.y0, 50, 0, v.angle*180/Math.PI);
				Utility.drawString(g, Constants.theta, vs.x0+60*Math.cos(v.angle/2), vs.y0-60*Math.sin(v.angle/2));
				
				g.setColor(Color.blue);
				
				LocVektor vc = cart.screenVecs.get(1), v = cart.screenVecs.get(0);
				Utility.drawLocLine(vc, g);
				
				Utility.drawString(g,"Prilezeca", (vc.x0+vc.x1)/2-50, (vc.y0+30));
				
				g.setColor(Color.red);
				
				vc = cart.screenVecs.get(2);
				Utility.drawLocLine(vc, g);
				g.translate(vc.x0,v.y0);
				g.rotate( Math.PI/2);
				Utility.drawString(g,"Nasuprotna", vc.y,-20);
				g.rotate(-Math.PI/2);
				g.translate(-vc.x0,-v.y0);

				
				
				
				
			}
			
		};
		
		contents.add(vc2);
		
		VTextPane vtp2 = new VTextPane(), vtp3 = new VTextPane();
		vtp2.setPreferredSize(new Dimension(100,50));
		vtp3.setPreferredSize(new Dimension(100,300));
		

		addNewText(texts[4]);
		queueText();
		
		boolean hideSol = true;
		
		vc3 = new VectorsCart();
		vc3.putVector(LocVektor.polarVec(3, Math.PI/180*120),1,0,0,0);
		vc3.draggy = true;
		vc3.initialize(); vc3.setup();
		vc3.painter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				
				LocVektor v = cart.vecList.get(0);
				vtp2.setText("");
				vtp2.readVecText("#vecr#/vec = " + Utility.roundToDec(v.r,1));
				vtp2.insertImage(Utility.angleSymbol(20));
				vtp2.readVecText(Utility.roundToDec(v.angle, 1)+Constants.deg);
			}
		};
		
		
		
		contents.add(vc3);
		JButton solB = new JButton("Otkrij");
		solB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				LocVektor v = vc3.vecList.get(0);
				
				vtp3.setText("");
				vtp3.readVecText("r = " + Utility.roundToDec(v.r,1));
				vtp3.readVecText("\n" +Constants.theta + " = " + Utility.roundToDec(v.angle*180/Math.PI,1) + Constants.deg);

				double sin = Math.sin(v.angle), cos = Math.cos(v.angle);
				vtp3.readVecText("\nsin" + Constants.theta + " = " + Utility.roundToDec(sin,3)
						+ "\ncos" + Constants.theta + " = " + Utility.roundToDec(cos,3));
				vtp3.readVecText("\nr sin" + Constants.theta + " = " + Utility.roundToDec(v.r*sin,2)
					+ "\nr cos" + Constants.theta + " = " + Utility.roundToDec(v.r*cos,2));
				vtp3.readVecText("\n#vecv#/vec = " + v.VText(1));
			}
		});
		JPanel jp = new JPanel();
		jp.add(solB);
		contents.add(jp);
		contents.add(vtp2);
		contents.add(vtp3);
		
		
		
		VTextPane vtp4 = new VTextPane(), vtp5 = new VTextPane();
		
		vtp4.setPreferredSize(new Dimension(100,300));
		vtp5.setPreferredSize(new Dimension(100,300));
		
		vc4 = vc3.copy();
		vc4.painter = null;
		contents.add(vc4);
		
		addNewText(texts[5]);
		queueText();
		
		VTextPane vformula = new VTextPane();
		
		
		JButton solB2 = new JButton("Otkrij");
		solB2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				LocVektor v = vc4.vecList.get(0);
				
				vtp5.setText("");
				vtp5.readVecText("x = " + Utility.roundToDec(v.x,1));
				vtp5.readVecText("\ny = " + Utility.roundToDec(v.y,1)+"\n");
				BufferedImage frac = Utility.frac(Utility.buffImageText("y", 1,20,false), Utility.buffImageText("x", 1,20,false));
				vtp5.insertImage(frac);
				vtp5.readVecText(" = " + Utility.roundToDec(v.y/v.x,3)+"\n" + Constants.theta + " = tg");
				
				double sin = Math.sin(v.angle), cos = Math.cos(v.angle);
				double atan = Math.atan(v.y/v.x);
				vtp5.insertImage(Utility.exp("-1", 20));
				vtp5.insertImage(frac);
				vtp5.readVecText(" + 180" + Constants.deg + " = " + Utility.roundToDec(atan*180/Math.PI, 1) + "180"+Constants.deg);
				vtp5.readVecText("\nr = ");
				Expr underrt = new Expr(new Expr("x",Expr.Op.square),new Expr("x",Expr.Op.square),Expr.Op.add);
				//vtp5.insertImage(Utility.expressionIm(underrt, 25));
				vtp5.insertImage(Utility.expressionIm(new Expr(underrt,Expr.Op.sqrt), 25));
				vtp5.readVecText("\n#vecv#/vec = " + v.VText(1));
				vtp5.insertImage(Constants.checkMarkImg);
			}
			
		});
		JPanel jp2 = new JPanel();
		jp2.add(solB2);
		contents.add(jp2);
		
		contents.add(vtp5);
		
		
		
		showQueue();
		

	}

}
