package lessons.srednja;

import java.awt.Color;

import lessons.SpecificLessonPanel;
import mainpackage.Field;
import textDisplays.VektorTextArea;
import vectUtilities.Function;
import vectUtilities.Graph;
import vectUtilities.Utility;

public class ParamPravac extends SpecificLessonPanel {

	private static final long serialVersionUID = -5341630090131003476L;

	VektorTextArea t1, t2;
	
	String path = "Files/lessons/fakultet/polje/";
	
	@Override
	public SpecificLessonPanel nextPanel() {
		return this;
	}
	
	public ParamPravac() {
		Field f = new Field();
		f.setBackground(Color.cyan);
		f.resx = 1;
		f.resy = 1;
		f.f = new Function() {

			@Override
			public double[] calc(double x, double y) {
				return new double[] {2,2};
			}
			
		};
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");
		
//		t1 = new VektorTextArea();
//		t1.readVecText(texts[0]);
		addNewText(texts[0]);
		queueText();
		
//		t2 = new VektorTextArea();
//		t2.readVecText(texts[1]);

		contents.add(f);
		
		addNewText(texts[1]);
		queueText();
		
		
		Graph g = new Graph(300,300, new double[] {1,2,1,2});
		g.randomTerrain(1000, 50, 1);
		contents.add(g);
		showQueue();
		
	}
	
	
}
