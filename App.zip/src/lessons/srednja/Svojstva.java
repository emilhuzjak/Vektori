package lessons.srednja;

import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import lessons.osnovna.Razlika2D;
import mainpackage.VectorsCart;
import sim.LinComb;
import textDisplays.VektorTextArea;
import vectUtilities.Utility;

public class Svojstva extends SpecificLessonPanel {


	private static final long serialVersionUID = -451558731092356257L;

	
	public SpecificLessonPanel nextPanel() {
		return new Comp();
	}

	String path = "Files/lessons/srednja/svojstva/";

	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	boolean moving = false;
	
	public Svojstva() {
		setTitle(Utility.getLessonTitle("Svojstva"));
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();

		
		//---------------------------------------------------------------
		showQueue();

//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				
////				addContent(lc);
////				addContent(t2);
////				addContent(lc2);
////				addContent(t3);
//
//			}
//		});
		

	}
	
	
	
}
