package lessons.osnovna;

import java.awt.Graphics2D;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Duljina extends SpecificLessonPanel {

	
	String path = "Files/lessons/osnovna/Duljina/";

	private static final long serialVersionUID = -1178445092486727144L;

	
	VectorsCart vc1, vc2, vc3, vc4, vc5, vc6;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new Brzina();
	}
	
	JTextArea jta1 = new JTextArea(), jta2 = new JTextArea(), jta3 = new JTextArea(),
			jta4 = new JTextArea(), jta5 = new JTextArea(), jta6 = new JTextArea();
	
	
	public Duljina() {
		
		setTitle(Utility.getLessonTitle("Duljina"));
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");
		
		jta1.setFont(Constants.font1);
		
		addNewText(texts[0]);
		queueText();
		
		JPanel pythP = new JPanel();
		pythP.add(new JLabel(new ImageIcon((Utility.readImage("Files/images/form/pyth.png")))));
		contents.add(pythP);
		
		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0,0,3,2), 1,0,0,0);
		
		vc1.initialize(); vc1.setup();
		
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v = cart.vecList.get(0);
				jta1.setText("x = " + Utility.roundToDec(v.x,1) + "\ny = " + Utility.roundToDec(v.y,1) + "\nr = " + Utility.roundToDec(v.r,1));
			}
			
		};
		contents.add(vc1);
		contents.add(jta1);
		
		showQueue();
		
	}
	
}
