package lessons.osnovna;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Trenje extends SpecificLessonPanel {

	
	String path = "Files/lessons/osnovna/brzina/";

	private static final long serialVersionUID = -1178445092486727144L;

	
	VectorsCart vc1, vc2, vc3, vc4, vc5, vc6;

	@Override
	public SpecificLessonPanel nextPanel() {
		return this;
	}
	
	JTextArea jta1 = new JTextArea(), jta2 = new JTextArea(), jta3 = new JTextArea(),
			jta4 = new JTextArea(), jta5 = new JTextArea(), jta6 = new JTextArea();
	
	
	public Trenje() {
		
		setTitle(Utility.getLessonTitle("Brzina"));
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");
		
		jta1.setFont(Constants.font1);
		
		addNewText(texts[0]);
		queueText();
		
		JPanel pythP = new JPanel();
		pythP.add(new JLabel(new ImageIcon(Utility.conc(new BufferedImage[]
				{Utility.buffImageText("v", 20, 25, true),Utility.buffImageText(" = ", 20, 25, false),
						Utility.frac(Utility.buffImageText("s", 20, 25, true), Utility.buffImageText("t", 20, 25, false))},0,0))));
		contents.add(pythP);
		
		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0,0,3,2), 1,0,0,0);
		
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v = cart.vecList.get(0);
				jta1.setText("x = " + Utility.roundToDec(v.x,1) + "\ny = " + Utility.roundToDec(v.y,1) + "\nr = " + Utility.roundToDec(v.r,1));
			}
			
		};
		contents.add(jta1);
		
		addNewText(texts[0]);
		queueText();
		
		showQueue();
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				remove(controls);
			}
		});

		
	}

}
