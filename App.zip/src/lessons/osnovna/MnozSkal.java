package lessons.osnovna;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;

import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.DoubleSlider;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class MnozSkal extends SpecificLessonPanel {

	private static final long serialVersionUID = 4024205859332768327L;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new Zbroj1D();
	}

	String path = "Files/lessons/osnovna/MnozSkal/";

	VectorsCart vc0, vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;
	
	public MnozSkal() {

		setTitle(Utility.getLessonTitle("MnozSkal"));
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");
		
		addNewText(texts[0]);
		queueText();
		
		VectorsCart vc0 = new VectorsCart();

		
		addNewText(texts[1]);
		queueText();
		
		
		//vc0 = new VectorsCart();
		
		double scalar[] = new double[] {2, 2};

		vc1 = new VectorsCart();
		LocVektor og = new LocVektor(0, 0, 2,1);
		LocVektor scal = og.copy();
		scal.translate(-2,2);
		scal.scale(2);
		vc1.putVector(og, 1, 1, 0, 0);
		vc1.putVector(scal, 0, 1, 0, 0);
//		vc1.x0 = -20;
//		vc1.y0 = -10;
//		vc1.xCoordSpan = 40;
//		vc1.yCoordSpan = 20;
		vc1.drawAxes = false;
		vc1.gridLines = false;
		vc1.initialize();
		vc1.setup();
		vc1.mh.r = 10;
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				// TODO Auto-generated method stub
				double sc = (int) (100 * scalar[0]) / 100.0;

				LocVektor lv = cart.vecList.get(0), lvS = lv.copy(), lvOld = cart.vecList.get(1);
				
				
				lvS.scaleToR(lv.r*sc);
				lvS.translateTo(lvOld.x0, lvOld.y0);
				cart.vecList.set(1, lvS);
				
				cart.mapAllToScreen();

				g.setFont(new Font("Arial", 1, 30));
				g.setColor(Color.black);
				lv = cart.screenVecs.get(0);
				Utility.drawFancyString(new String[] { "v" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2,
						g);
				lv = cart.screenVecs.get(1);
				Utility.drawFancyString(new String[] { sc+" ", "v" }, new int[] { 0, 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				
				

			}

		};
		
		//--------------------------------
		DoubleSlider slid = new DoubleSlider(SwingConstants.HORIZONTAL, -3, 3, scalar[0], 10);
		slid.setPaintLabels(true);
		slid.setPreferredSize(new Dimension(200, 40));
		JPanel slidP = new JPanel();
		slidP.add(slid);
		ChangeListener c = new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				scalar[0] = slid.getDoubleValue();
				vc1.repaint();
			}
		};

		slid.addChangeListener(c);
		contents.add(slidP);
		contents.add(vc1);

		addNewText(texts[2]);
		queueText();
		
		LocVektor v2v1 = new LocVektor(0, 0, 1, 1), v2v2 = new LocVektor(1, -1, 0.707, 0.707);
		vc2 = new VectorsCart();
		vc2.putVector(v2v1, 1, 1, 0, 0);
		vc2.putVector(v2v2, 0, 1, 0, 0);
		vc2.x0 = -10;
		vc2.y0 = -4;
		vc2.xCoordSpan = 20;
		vc2.yCoordSpan = 8;
		vc2.drawAxes = false;
		vc2.gridLines = false;
		vc2.initialize();
		vc2.setup();
		vc2.setBackground(Color.CYAN);
		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {

				// TODO Auto-generated method stub
				double sc = (int) (100 * scalar[1]) / 100.0;

				LocVektor lv = cart.vecList.get(0), lvS = lv.copy(), lvOld = cart.vecList.get(1);
				
				
				lvS.scaleToR(lv.r/sc);
				lvS.translateTo(lvOld.x0, lvOld.y0);
				cart.vecList.set(1, lvS);
				
				cart.mapAllToScreen();

				g.setFont(new Font("Arial", 1, 30));
				g.setColor(Color.black);
				lv = cart.screenVecs.get(0);
				Utility.drawFancyString(new String[] { "v" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2,
						g);
				lv = cart.screenVecs.get(1);
				Utility.drawFancyString(new String[] { "1/(" + sc+") ", "v" }, new int[] { 0, 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				
				

			
			}

		};
		
		DoubleSlider slid2 = new DoubleSlider(SwingConstants.HORIZONTAL, -3, 3, scalar[1], 30);
		slid2.setPaintLabels(true);
		slid2.setPreferredSize(new Dimension(200, 40));
		ChangeListener c2 = new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				scalar[1] = slid2.getDoubleValue();
				vc2.repaint();
			}
		};
		slid2.addChangeListener(c2);
		
		JPanel slidP2 = new JPanel();
		slidP2.add(slid2);
		
//		contents.add(slidP2);
//		contents.add(vc2);
//		addNewText(texts[3]);
//		queueText();
//		
		showQueue();
		
//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				addContent(slid);
//				addContent(vc1);
//				addContent(t2);
//				addContent(slid2);
//				addContent(vc2);
//				addContent(t3);
//
//
////				addContent(vc3);
//			}
//		});
		
		//addContent(vc2);

	}

}
