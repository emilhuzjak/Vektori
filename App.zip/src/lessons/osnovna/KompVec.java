package lessons.osnovna;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class KompVec extends SpecificLessonPanel{

	String path = "Files/lessons/osnovna/KompVec/";

	private static final long serialVersionUID = -1178445092486727144L;

	
	VectorsCart vc1, vc2, vc3, vc4, vc5, vc6;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new Duljina();
	}
	
	JTextArea jta1 = new JTextArea(), jta2 = new JTextArea(), jta3 = new JTextArea(),
			jta4 = new JTextArea(), jta5 = new JTextArea(), jta6 = new JTextArea();
	
	
	public KompVec() {
		
		setTitle(Utility.getLessonTitle("KompVec"));
		
		jta1.setFont(Constants.font1);
		jta2.setFont(Constants.font1);
		jta3.setFont(Constants.font1);
		jta4.setFont(Constants.font1);

		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");
		addNewText(texts[0]);
		queueText();
		
		
		
		
		vc1 = new VectorsCart();
		vc1.setBackground(Color.cyan);
		//vc1.gridLines = false;
		LocVektor lv = new LocVektor(0,0,1,1);
		vc1.putVector(lv, 0,1,1,0);
		vc1.hoverEnabled = true;
		vc1.draggy = true;
		vc1.gridLines = true;
		vc1.drawAxes = true;
		vc1.mh.r = 500;
		vc1.initialize(); vc1.setup();
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				g.setColor(Color.red);
				LocVektor v = cart.screenVecs.get(0);
				//Utility.boundRect(g, cart.screenVecs.get(0));
				Utility.drawLocLine(cart.screenVecs.get(0).xComp(), g);
				Utility.drawLocLine(cart.screenVecs.get(0).yComp(), g);

				g.setColor(Color.blue);
				v = cart.vecList.get(0);
				jta1.setText("x komponenta = " + Utility.roundToDec(v.x, 1) +
						"\ny komponenta = " + Utility.roundToDec(v.y, 1));

			}
			
		};
		
		contents.add(vc1);
		contents.add(jta1);
		
		addNewText(texts[1]);
		queueText();
		
		JPanel jta2P = new JPanel();

		
		vc2 = new VectorsCart();
		vc2.setBackground(Color.cyan);
		//vc1.gridLines = false;
		LocVektor lvnegy = new LocVektor(1,1,-2,-3);
		vc2.putVector(lvnegy, 1,1,0,0);
		//vc2.hoverEnabled = true;
		vc2.draggy = true;
		vc2.gridLines = true;
		vc2.drawAxes = true;
		vc2.mh.r = 5;
		vc2.initialize(); vc2.setup();
		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				
				LocVektor v = cart.screenVecs.get(0), vv = cart.vecList.get(0);
				Utility.drawString(g, "A", v.x0, v.y0);
				Utility.drawString(g, "B", v.x1, v.y1);
				
				jta2.setText("A (" + Utility.roundToDec(vv.x0,1) + ", " + Utility.roundToDec(vv.y0,1)
						+")\nB (" + Utility.roundToDec(vv.x1,1) + ", " + Utility.roundToDec(vv.y1,1)
						+ ")\nx komponenta = " + Utility.roundToDec(vv.x1,1) + " - " + Utility.roundToDec(vv.x0,1) + " = " + Utility.roundToDec(vv.x,1) + 
						"\ny komponenta = " + Utility.roundToDec(vv.x1,1) + " - " + Utility.roundToDec(vv.y0,1) + " = " + Utility.roundToDec(vv.y,1));
				
				
			}
			
		};
		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				g.setColor(Color.black);
				LocVektor v = cart.screenVecs.get(0);
				Utility.drawString(g, "A", v.x0, v.y0);
				Utility.drawString(g, "B", v.x1, v.y1);
			}
			
		};
		jta2.setPreferredSize(new Dimension(500, 200));
		
		contents.add(vc2);
		
		contents.add(jta2);
//		
//		//jta2P.add(jta2);
//		
//		addNewText(texts[2]);
//		queueText();
//		
//		vc3 = vc2.copy();
//		vc3.prePainter = new VecPainter() {
//
//			@Override
//			public void paint(Graphics2D g, VectorsCart cart) {
//				cart.mapAllToScreen();
//				
//				LocVektor v = cart.vecList.get(0);
//				if (v.y < 0) {
//					v.y = 0.1;
//				}
//				jta3.setText("Pozitivna y komponenta:\ny = " + Utility.roundToDec(v.y, 1));
//
//			}
//			
//		};
//		jta3.setPreferredSize(new Dimension(500, 50));
//
//		
//		contents.add(vc3);
//		contents.add(jta3);
//		
//		addNewText(texts[3]);
//		queueText();
//		
//		vc4 = vc3.copy();
//		vc4.prePainter = new VecPainter() {
//
//			@Override
//			public void paint(Graphics2D g, VectorsCart cart) {
//				cart.mapAllToScreen();
//				
//				LocVektor v = cart.vecList.get(0);
//				v.y = 0;
//				jta4.setText("y=0\nx = "+Utility.roundToDec(v.x, 1));
//
//			}
//			
//		};
//		
//		contents.add(vc4);
//		contents.add(jta4);
//		
//		addNewText(texts[4]);
//		queueText();
//		
//		
//		vc5 = vc4.copy();
//		vc5.prePainter = new VecPainter() {
//
//			@Override
//			public void paint(Graphics2D g, VectorsCart cart) {
//				cart.mapAllToScreen();
//				
//				LocVektor v = cart.vecList.get(0);
//				v.y = 0;
//				jta5.setText("Pomak " + (v.x<0 ? "lijevo\nx= " : "desno\nx= ") + Utility.roundToDec(v.x, 1));
//
//			}
//			
//		};
//		contents.add(vc5);
//		contents.add(jta5);
//		
//		addNewText(texts[5]);
//		queueText();
//		
//		vc6 = vc5.copy();
//		vc6.prePainter = new VecPainter() {
//
//			@Override
//			public void paint(Graphics2D g, VectorsCart cart) {
//				cart.mapAllToScreen();
//				
//				LocVektor v = cart.vecList.get(0);
//				if (textPanes.size() < 6) return;
//				
//				lastPane.setText("");
//				continueText("#vecr#/vec = #vec< " + Utility.roundToDec(v.x,1) + ", " + Utility.roundToDec(v.y,1)+
//						" >#/vec\nDuljina vektora:\n|");
//				lastPane.insertImage(Utility.buffImageText("r",30,30, true));
//				continueText("| = ");
//				double xd = Utility.roundToDec(v.x,1), yd = Utility.roundToDec(v.y,1);
//				String xnum = xd + "", ynum = yd+"";
//				if (xd < 0) {
//					xnum = "("+xnum+")";
//				}
//				if (yd < 0) {
//					ynum = "("+ynum+")";
//				}
//				BufferedImage sq1 = Utility.sqImg(Utility.buffImageText(xnum, 30, 20, false)),
//						sq2 = Utility.sqImg(Utility.buffImageText(ynum+"", 30, 20, false));
//
//				lastPane.insertImage(Utility.sqrtIm(
//						Utility.conc(new BufferedImage[]{sq1,Utility.buffImageText("+", 20,  20, false),sq2},0, 0)));
//				continueText(" = ");
//				double r = Utility.roundToDec(xd*xd+yd*yd,2);
//				lastPane.insertImage(Utility.sqrtIm(Utility.buffImageText(""+r, 20,  20, false)));
//				continueText(" = " + Utility.roundToDec(Math.sqrt(r),2));
//				
//			}
//			
//		};
//		
//		vc6.painter = new VecPainter() {
//			
//			@Override
//			public void paint(Graphics2D g, VectorsCart cart) {
//				g.setColor(Color.black);
//				g.setFont(Constants.font40);
//				LocVektor v = cart.vecList.get(0);
//				
//				cart.map(v.x1/2, v.y1/2);
//				Utility.drawFancyString(new String[] {"r"}, new int[] {1}, cart.xs, cart.ys, g);
//			}
//		};
//		
//		contents.add(vc6);
//		
//		LocVektor vt = vc6.vecList.get(0);
//		
//		addNewText("#vecr#/vec = #vec< " + Utility.roundToDec(vt.x,1) + ", " + Utility.roundToDec(vt.x,1)+" >#/vec");
//		queueText();
//		
//		
//		contents.add(Utility.sizePanel(100,100));
//		lastPane.setPreferredSize(new Dimension(200,300));
		
		showQueue();


	}
	
	
}
