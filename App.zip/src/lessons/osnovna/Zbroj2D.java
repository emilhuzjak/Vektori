package lessons.osnovna;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import sim.LinComb;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Zbroj2D extends SpecificLessonPanel {

	private static final long serialVersionUID = -917319952638198644L;

	public SpecificLessonPanel nextPanel() {
		return new Razlika2D();
	}

	String path = "Files/lessons/osnovna/zbroj2D/";

	LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	boolean moving = false;

	public Zbroj2D() {

		setTitle(Utility.getLessonTitle("Zbroj2D"));
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();
		
		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(-3,-2,3,0),1,1,0,0);
		vc1.putVector(new LocVektor(0,0,1,4),1,1,0,0);
		vc1.putVector(new LocVektor(0,0,1,1),0,0,0,0);
		vc1.gridLines = vc1.drawAxes = false;
		vc1.hoverEnabled = false; vc1.draggy = true;
		vc1.visible.set(2,0);

		vc1.initialize(); vc1.setup();
		
		vc1.customColors = true;
		vc1.colors = Arrays.asList(new Color[] {Color.blue, Color.red, Constants.dark_green1});
		
		vc1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x1, v1.y1);
				cart.vecList.set(2,LocVektor.add(v1,v2));
				
				
			}
			
		};
		vc1.painter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				g.setColor(Color.black);
				
				g.setFont(Constants.font1);
				
				cart.mapAllToScreen();

				LocVektor v3 = cart.screenVecs.get(2);
				LocVektor v1 = cart.screenVecs.get(0), v2 = cart.screenVecs.get(1);
				
				Utility.drawString(g, "A", v1.x0, v1.y0);
				Utility.drawString(g, "B", v1.x1, v1.y1);
				Utility.drawString(g, "C", v2.x1, v2.y1);
				
				v1.mid(); v2.mid(); v3.mid();
				Utility.drawFancyString(new String[] {"AB"}, new int[] {1}, v1.midx, v1.midy, g);
				
				Utility.drawFancyString(new String[] {"BC"}, new int[] {1}, v2.midx, v2.midy, g);

				if (cart.visible.get(2)==1) {
					Utility.drawFancyString(new String[] {"AC", "=","AB","+","BC"}, new int[] {1,0,1,0,1}, v3.midx, v3.midy, g);

				}
				
			
			}
		};
		JButton disc = new JButton("Zbroji");
		disc.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				vc1.visible.set(2, 1-vc1.visible.get(2));
				vc1.repaint();
			}
		});
		vc1.add(disc);
		contents.add(vc1);
		
		addNewText(texts[1]);
		queueText();
		
//		lc2 = new LinComb();
//		LocVektor a2 = new LocVektor(-10,3, 3,5), b2 = new LocVektor(-10,-3, 1,-3);
//		lc2.a = a2; lc2.b = b2;
//		lc2.paralellogram = true;
//		lc2.init();
//		lc2.labels = Arrays.asList(new String[] {"u", "v", "u", "v", "w"});
//		JButton animB2 = new JButton("Kreni");
//		animB2.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				lc2.animate();
//			}
//		});
//		lc2.add(animB2);
//		contents.add(lc2);
		
		
		addNewText(texts[2]);
		queueText();
		
		
		vc2 = vc1.copy();
		
		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x0, v1.y0);
				cart.vecList.set(2,LocVektor.add(v1,v2));
				
				cart.mapAllToScreen();
				if (cart.visible.get(2) == 1)
					Utility.drawParallelogramGuides(g, cart.screenVecs.get(0), cart.screenVecs.get(1));
				
			}
			
		};
		JButton disc2 = new JButton("Zbroji (paralelogramom)");
		vc2.add(disc2);
		disc2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				vc2.visible.set(2, 1-vc2.visible.get(2));
				vc2.repaint();
			}
		});
		contents.add(vc2);
		
		
		addNewText(texts[3]);
		queueText();
		
		
		
		
		VectorsCart vcadd = new VectorsCart();
		vcadd.putVector(new LocVektor(-5, 0, 3,0),1,1,0,0);
		vcadd.putVector(new LocVektor(-2, 0, 0,3),1,0,0,0);
		vcadd.putVector(new LocVektor(3,0,3,0),0,0,0,0);
		vcadd.putVector(new LocVektor(3,0,0,3),0,0,0,0);
		vcadd.putVector(new LocVektor(-5, 0, 3,3),0,0,0,0);
		vcadd.putVector(new LocVektor(3, 0, 3,3),0,0,0,0);
		vcadd.gridLines = vcadd.drawAxes = false;
		vcadd.customColors = true;
		vcadd.colors = Arrays.asList(new Color[] {Color.blue, Color.red, Color.blue, Color.red, Color.black});


		vcadd.initialize(); vcadd.setup();
		vcadd.prePainter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				vcadd.vecList.get(1).translateTo(vcadd.vecList.get(0).x1, vcadd.vecList.get(0).y1);
//				vcadd.vecList.get(3).translateTo(vcadd.vecList.get(2).x1, vcadd.vecList.get(2).y1);

				vcadd.vecList.set(4,LocVektor.add(vcadd.vecList.get(0),vcadd.vecList.get(1)));
				vcadd.vecList.get(2).matchComponents(vcadd.vecList.get(0));
				vcadd.vecList.get(3).matchComponents(vcadd.vecList.get(1));
				vcadd.vecList.set(5,LocVektor.add(vcadd.vecList.get(2),vcadd.vecList.get(3)));

				vcadd.mapAllToScreen();
//				Utility.drawParallelogramRule(g, vcadd.screenVecs.get(2), vcadd.screenVecs.get(3));
				LocVektor v1 = vcadd.screenVecs.get(2), v2 = vcadd.screenVecs.get(3), va = vcadd.screenVecs.get(5);
				Utility.drawLine(v1.x1,v1.y1, va.x1, va.y1, g);
				Utility.drawLine(va.x1,va.y1, v2.x1, v2.y1, g);
				v1.mid();
				v2.mid();
				va.mid();
				g.setFont(Constants.font1);
				Utility.drawFancyString(new String[] {"a"}, new int[] {1}, v1.midx, v1.midy, g);
				Utility.drawFancyString(new String[] {"b"}, new int[] {1}, v2.midx, v2.midy, g);
				Utility.drawFancyString(new String[] {"a","+","b"}, new int[] {1,0,1}, va.midx, va.midy, g);
				v1 = vcadd.screenVecs.get(0); v2 = vcadd.screenVecs.get(1); va = vcadd.screenVecs.get(4);
				v1.mid();
				v2.mid();
				va.mid();
				Utility.drawFancyString(new String[] {"a"}, new int[] {1}, v1.midx, v1.midy, g);
				Utility.drawFancyString(new String[] {"b"}, new int[] {1}, v2.midx, v2.midy, g);
				Utility.drawFancyString(new String[] {"a","+","b"}, new int[] {1,0,1}, va.midx, va.midy, g);
				
			}
		};
		contents.add(vcadd);
		
		//---------------------------------------------------------------
		
		showQueue();

//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				
//				addContent(lc);
//				addContent(Zbroj2D.this.t2);
//				addContent(lc2);
//				//addContent(t3);
//
//			}
//		});
//
//
		

		
	}

}
