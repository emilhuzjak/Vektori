package lessons.osnovna;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import sim.LinComb;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Razlika2D extends SpecificLessonPanel{

	private static final long serialVersionUID = -7001119459815694634L;

	public SpecificLessonPanel nextPanel() {
		return new Koord();
	}

	String path = "Files/lessons/osnovna/razlika2D/";

	LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	boolean moving = false;
	
	public Razlika2D() {

		setTitle(Utility.getLessonTitle("Razlika2D"));
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();

		
		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(-3,-2,3,0),1,1,0,0);
		vc1.putVector(new LocVektor(0,0,1,4),1,1,0,0);
		vc1.putVector(new LocVektor(0,0,1,1),0,0,0,0);
		vc1.putVector(new LocVektor(),0,0,0,0);
		vc1.gridLines = vc1.drawAxes = false;
		vc1.hoverEnabled = false; vc1.draggy = true;
		vc1.visible.set(2,0);
		vc1.visible.set(3,0);


		vc1.initialize(); vc1.setup();
		
		vc1.customColors = true;
		vc1.colors = Arrays.asList(new Color[] {Color.blue, Color.red, Constants.dark_green1, Color.orange});
		
		vc1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x1, v1.y1);
				LocVektor vopp = v2.copy();
				vopp.scale(-1);
				cart.vecList.set(3,vopp);
				cart.vecList.set(2,LocVektor.add(v1,vopp));
				
				
			}
			
		};
		vc1.painter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				g.setColor(Color.black);
				
				g.setFont(Constants.font1);
				
				cart.mapAllToScreen();

				LocVektor v3 = cart.screenVecs.get(2);
				LocVektor v1 = cart.screenVecs.get(0), v2 = cart.screenVecs.get(1), vopp = cart.screenVecs.get(3);
				
				
				
				v1.mid(); v2.mid(); v3.mid(); vopp.mid();
				Utility.drawFancyString(new String[] {"A"}, new int[] {1}, v1.midx, v1.midy, g);
				
				Utility.drawFancyString(new String[] {"B"}, new int[] {1}, v2.midx, v2.midy, g);

				if (cart.visible.get(2)==1) {
					Utility.drawFancyString(new String[] {"A", "=","B","-","C"}, new int[] {1,0,1,0,1}, v3.midx, v3.midy, g);
					Utility.drawFancyString(new String[] {"-","B"}, new int[] {0,1}, vopp.midx, vopp.midy, g);

				}
				
			
			}
		};
		JButton disc = new JButton("Zbroji");
		disc.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				vc1.visible.set(2, 1-vc1.visible.get(2));
				vc1.visible.set(3, 1-vc1.visible.get(3));

				vc1.repaint();
			}
		});
		vc1.add(disc);
		contents.add(vc1);

		
		

		addNewText(texts[1]);
		queueText();
		
		
		
		vc2 = vc1.copy();
		
		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x0, v1.y0);
				
				LocVektor vopp = v2.copy();
				vopp.scale(-1);
				cart.vecList.set(3,vopp);
				cart.vecList.set(2,LocVektor.add(v1,vopp));

				cart.mapAllToScreen();
				if (cart.visible.get(2) == 1)
					Utility.drawParallelogramGuides(g, cart.screenVecs.get(0), cart.screenVecs.get(3));
				
			}
			
		};
		JButton disc2 = new JButton("Zbroji (paralelogramom)");
		vc2.add(disc2);
		disc2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				vc2.visible.set(2, 1-vc2.visible.get(2));
				vc2.visible.set(3, 1-vc2.visible.get(3));

				vc2.repaint();
			}
		});
		contents.add(vc2);
		
		
//		vc2.painter = new VecPainter() {
//			
//			@Override
//			public void paint(Graphics2D g, VectorsCart cart) {
//				g.setColor(Color.black);
//				
//				g.setFont(Constants.font1);
//				
//				cart.mapAllToScreen();
//
//				LocVektor v3 = cart.screenVecs.get(2);
//				LocVektor v1 = cart.screenVecs.get(0), v2 = cart.screenVecs.get(1);
//				
//				Utility.drawString(g, "A", v1.x0, v1.y0);
//				Utility.drawString(g, "B", v1.x1, v1.y1);
//				Utility.drawString(g, "C", v2.x1, v2.y1);
//				
//				v1.mid(); v2.mid(); v3.mid();
//				Utility.drawFancyString(new String[] {"AB"}, new int[] {1}, v1.midx, v1.midy, g);
//				
//				Utility.drawFancyString(new String[] {"BC"}, new int[] {1}, v2.midx, v2.midy, g);
//
//				if (cart.visible.get(2)==1) {
//					Utility.drawFancyString(new String[] {"AC", "=","AB","+","BC"}, new int[] {1,0,1,0,1}, v3.midx, v3.midy, g);
//
//				}
//				
//			
//			}
//		};
		
		
		
//		lc2 = new LinComb();
//		LocVektor a2 = new LocVektor(-10,0, 3,0), b2 = new LocVektor(-5,-1, 1,-3);
//		lc2.a = a2; lc2.b = b2;
//		//lc2.a2 = -1;
//		lc2.init();
//		lc2.labels = Arrays.asList(new String[] {"u", "v", "u", "v", "w"});
//		JButton animB2 = new JButton("Kreni");
//		animB2.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				lc2.animate();
//			}
//		});
//		lc2.add(animB2);
//		contents.add(lc2);
		
		addNewText(texts[2]);
		queueText();
		
		showQueue();

//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				
//				addContent(lc);
//				addContent(Razlika2D.this.t2);
//				addContent(lc2);
//				//addContent(t3);
//
//			}
//		});


	}
	
	
}
