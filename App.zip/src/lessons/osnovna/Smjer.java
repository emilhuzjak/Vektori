package lessons.osnovna;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Smjer extends SpecificLessonPanel {


	private static final long serialVersionUID = 1351391286520121345L;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new Pomak();
	}
	
	String path = "Files/lessons/osnovna/smjer/";
	
	boolean lines = false;
	public void toggleLines() {
		lines = !lines;
	}
	
	VektorTextArea text1, text1_1, text2, text3;
	VectorsCart vc1, vc1_1, vc2;
	
	public Smjer() {
		
		setTitle(Utility.getLessonTitle("Smjer"));
		
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");
		text1 = new VektorTextArea();
		text1.readVecText(texts[0]);
		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0,0,1,1), 1, 1, 0, 0);
		//vc1.x0 = -1; vc1.y0 = -0.5; vc1.xCoordSpan = 2; vc1.yCoordSpan = 1;
		vc1.drawAxes = false;
		vc1.gridLines = false;
		vc1.initialize(); vc1.setup();
		vc1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				// TODO Auto-generated method stub
				LocVektor lv = cart.mh.mapper.mapToScreen(cart.vecList.get(0));
				lv.scale(-2);
				g.setFont(new Font("Arial", 1, 20));
				g.rotate(lv.angle, lv.x1, lv.y1);
				g.drawString("Pravac smjera", (int)lv.x1, (int)lv.y1);
				g.rotate(-lv.angle, lv.x1, lv.y1);
				lv.scaleToR(1000);
				g.setStroke(new BasicStroke(1));
				Utility.drawLocLine(lv, g);
				lv.scale(-1);
				Utility.drawLocLine(lv, g);
				
				
			}
			
		};

		
		text1_1 = new VektorTextArea();
		text1_1.readVecText(texts[1]);

		vc1_1 = new VectorsCart();
		vc1_1.setBackground(Color.green);
		vc1_1.putVector(new LocVektor(0,0,3,1), 0, 0, 1, 0);
		vc1_1.putVector(new LocVektor(-2, 2,-0.1,-3), 0,0, 0, 0);
		vc1_1.putVector(new LocVektor(-1,-2,2,0.6), 0,0, 0, 0);
		
		//vc1_1.x0 = -1; vc1_1.y0 = -0.5; vc1_1.xCoordSpan = 2; vc1_1.yCoordSpan = 1;
		vc1_1.drawAxes = false;
		vc1_1.gridLines = false;
		vc1_1.initialize(); vc1_1.setup();
		vc1_1.mh.r = 100;
		vc1_1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				// TODO Auto-generated method stub
				cart.map(0,0);
				double ang = cart.vecList.get(0).angle;
				cart.vecList.get(1).setAngle(ang);
				cart.vecList.get(1).scale(-1);
				cart.vecList.get(2).setAngle(ang);
				if (lines) {
					cart.mapAllToScreen();
					for (LocVektor v : cart.screenVecs) {
						Utility.drawVecLine(v, g, 1000, 1000);
					}
				}
				
				
			}
			
		};
		JButton jb = new JButton("Pravci");
		ActionListener a = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lines = !lines;
				vc1_1.repaint();
			}
		};
		jb.addActionListener(a);
		
		vc1_1.add(jb);
		
		
		
		
		text2 = new VektorTextArea();
		text2.readVecText(texts[2]);
		
		
		
		vc2 = new VectorsCart();
		vc2.putVector(new LocVektor(-3,0,0,1), 0,0, 1, 0);
		vc2.putVector(new LocVektor(3,0,1,0), 0,0, 1, 0);
		//vc2.x0 = -1; vc2.y0 = -0.5; vc2.xCoordSpan = 2; vc2.yCoordSpan = 1;
		vc2.drawAxes = false;
		vc2.gridLines = false;
		vc2.initialize();
		vc2.setup();
		vc2.mh.r = 50;
		vc2.setBackground(Color.CYAN);
		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				
				double cw = cart.getWidth();
				
				cart.mh.r = cw/5;
				
				LocVektor lvv = cart.vecList.get(0), lvh = cart.vecList.get(1);
				
//				lvh.x0 = -cw/4/cart.xunit;
//				lvv.x0 = cw*3/4/cart.xunit;
				
				if (lvh.x*cart.xunit < -cart.getWidth()/5) {
					lvh.x = -cart.getWidth()/5 / cart.xunit;
				}
				lvh.fix();
				lvv.fix();
				
				lvv.x1 = lvv.x0;
				lvh.y1 = lvh.y0;
				lvv.fixLength();
				lvh.fixLength();
				
				g.setFont(new Font("Arial", 1, 25));
				g.setColor(Color.black);
				

				Utility.drawString(g, "Smjer: vertikalan", 20, cart.getHeight()-100);
				Utility.drawString(g, "Orijentacija: " + (lvv.y > 0 ? "gore" : "dolje"), 20, cart.getHeight()-70);
				Utility.drawString(g, "Smjer: horizontalan", cart.getWidth()/2 + 20, cart.getHeight()-100);
				Utility.drawString(g, "Orijentacija: " + (lvh.x > 0 ? "desno" : "lijevo"), cart.getWidth()/2 + 20, cart.getHeight()-70);
				
			}
			
		};
		
		text3 = new VektorTextArea();
		text3.readVecText(texts[3]);
		
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				addContent(title);
				addContent(text1);
				addContent(vc1);
				addContent(text1_1);
				addContent(vc1_1);
				addContent(text2);
				addContent(vc2);
				addContent(text3);
			}
		});
		
	}
	
	
}
