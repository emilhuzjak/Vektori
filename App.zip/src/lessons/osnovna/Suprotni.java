package lessons.osnovna;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

import javax.swing.JLabel;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Suprotni extends SpecificLessonPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2539132140879563095L;


	@Override
	public SpecificLessonPanel nextPanel() {
		return new MnozSkal();
	}

	String path = "Files/lessons/osnovna/suprotni/";

	public Suprotni() {

		setTitle(Utility.getLessonTitle("Suprotni"));
		
		addNewText(Utility.readFile(path + "1.txt"));
		queueText();
		
		VectorsCart vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0, 0, 1, 1), 0, 0, 1, 0);
		vc1.putVector(new LocVektor(0, 0, -1, -1), 0, 0, 0, 0);

		vc1.drawAxes = false;
		vc1.gridLines = false;
		vc1.initialize();
		vc1.setup();
		vc1.mh.r = 500;
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				// TODO Auto-generated method stub

				LocVektor lv = cart.vecList.get(0);
				cart.vecList.set(1, lv.copy());
				cart.vecList.get(1).rotate(Math.PI);
				lv = cart.mh.mapper.mapToScreen(lv);

				g.setFont(new Font("Arial", 1, 40));
				g.setColor(Color.black);
				Utility.drawFancyString(new String[] { "v" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2,
						g);
				Utility.drawFancyString(new String[] { "- ", "v" }, new int[] { 0, 1 }, (3 * lv.x0 - lv.x1) / 2,
						(3 * lv.y0 - lv.y1) / 2, g);
				g.setColor(Color.red);
				Utility.fillCircle(g, lv.x0, lv.y0, 5);

			}

		};
		contents.add(vc1);
		
		addNewText(Utility.readFile(path + "2.txt"));
		queueText();
		
		
		VectorsCart vc2 = new VectorsCart();
		vc2.putVector(new LocVektor(0, 0, 2, 2), 1, 1, 0, 0);
		vc2.putVector(new LocVektor(1, -1, 1.414, 1.414), 0, 0, 0, 0);

		vc2.drawAxes = false;
		vc2.gridLines = false;
		vc2.initialize();
		vc2.setup();
		vc2.setBackground(Color.CYAN);
		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				//LocVektor lv = cart.mh.mapper.mapToScreen(cart.vecList.get(0));
				LocVektor lv = cart.vecList.get(0);
				LocVektor unit = cart.vecList.get(1);
				unit.setAngle(lv.angle);
				unit.scaleToR(1);
				g.setFont(new Font("Arial", 1, 25));
				g.setColor(Color.red);

				lv = cart.mh.mapper.mapToScreen(lv);
				Utility.drawFancyString(new String[] { "V" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				
				lv = cart.mh.mapper.mapToScreen(unit);
				Utility.drawString(g, "V", (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2);
				Utility.drawHat(g, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2-25, 5, 5);
			}

		};

		contents.add(vc2);
		showQueue();
		}

}
