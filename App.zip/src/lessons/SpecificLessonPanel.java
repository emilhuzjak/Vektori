package lessons;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import textDisplays.VTextPane;
import vectUtilities.Constants;

public class SpecificLessonPanel extends JPanel {

	
	
	public JTextArea title;
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 669907713247832192L;

	public SpecificLessonPanel nextPanel() {
		return this;
	}

	public SpecificLessonPanel prevPanel() {
		return this;
	}

	public List<JComponent> contents = new ArrayList<>();

	public List<VTextPane> textPanes = new ArrayList<>();
	public VTextPane lastPane;
	
	public void addNewText(String t) {
		VTextPane vtp = new VTextPane();
		vtp.readVecText(t);
		textPanes.add(vtp);
		lastPane = vtp;
	}
	
	public void continueText(String t) {
		lastPane.readVecText(t);
	}
	
	public void queueText() {
		if (lastPane != null)
			contents.add(lastPane);
	}
	
	
	public void showQueue() {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (JComponent c : contents) {
					view.add(c);
					
				}
				scroll.getViewport().setViewPosition(new Point(0,0));
				repaint();
				
			}
		});
	}
	
	public void addContent(JComponent newComp) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				contents.add(newComp);
				view.add(newComp);
				scroll.getViewport().setViewPosition(new Point(0,0));
				repaint();
			}
		});
		
	}

	public void setTitle(String title) {
		this.title = new JTextArea(title+"\n");
		this.title.setFont(Constants.font30);
		contents.add(this.title);
		this.title.setEditable(false);
		this.title.setWrapStyleWord(true);
		this.title.setLineWrap(true);
	}
	
	JButton next = new JButton("Sljedeci");
	
	JPanel view = new JPanel();
	JScrollPane scroll = new JScrollPane(view);

	public JPanel controls = new JPanel();
	
	public SpecificLessonPanel() {
		
		
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		view.setLayout(new BoxLayout(view, BoxLayout.PAGE_AXIS));

		scroll.setViewportBorder(BorderFactory.createEmptyBorder(10,10,10,10));


		
		ComponentAdapter resizeListener = new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				
				Dimension newD = e.getComponent().getSize();
				int newW = (int) newD.getWidth();
				for (JComponent comp : contents) {
					Dimension d = comp.getPreferredSize();

					d.setSize(newW-40, d.getHeight());
					comp.setPreferredSize(d);
				}
//				Dimension d = view.getPreferredSize();
//
//				d.setSize(newW - 100, d.getHeight());
//				view.setPreferredSize(d);
				
				view.revalidate();
				
				
				view.repaint();
				
			}

			@Override
			public void componentMoved(ComponentEvent e) {
			}

		};

		next.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Constants.root.replacePanel(nextPanel(), true);
			}
		});
		
		addComponentListener(resizeListener);
		scroll.getVerticalScrollBar().setUnitIncrement(16);

		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run()
			{
				controls.setLayout(new FlowLayout());
				controls.add(next);
				add(controls);
				add(scroll);
				//repaint();
			}

		});

	}

}
