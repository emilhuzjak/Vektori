package lessons;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import vectUtilities.Utility;
import vectUtilities.VecTextPanel;

public class LessonBuilder {

	public LessonBuilder() {}
	
	
	List<String> lines = new ArrayList<>();
	String filecontent = "";
	
	public void readFile(String filepath) {
		try {
			lines = Files.readAllLines(Path.of(filepath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File builder threw IOException");
			return;
		}
		
		int siz = lines.size();
		for (int i = 0; i<siz-1; i++) {
			filecontent += lines.get(i) + "\n";
		}
		if (siz > 0) {
			filecontent += lines.get(siz-1);
		}
		
		
	}
	
	
	
	public VecTextPanel process() {
		
		
		//System.out.println(filecontent);
		
		String sep = "#vec#";
		
		List<Integer> indexes = Utility.findWord(filecontent, sep);
		
		if (indexes.size() == 0) {
			return new VecTextPanel(new String[] {filecontent}, new int[] {0}, 20);

		}
		
		List<String> texts = new ArrayList<>();
		List<Integer> arrowed = new ArrayList<>();
		int prev = 0;
		int endindex = 0;
		for (int i = 0; i<indexes.size(); i++) {
			int beginind = indexes.get(i);
			texts.add(filecontent.substring(prev, beginind));
			arrowed.add(0);
			endindex = filecontent.indexOf("#", beginind+sep.length());
			
			//System.out.println(beginind + " " + endindex);

			
			texts.add(filecontent.substring(beginind+sep.length(), endindex));
			arrowed.add(1);
			prev = endindex+1;
		}
		if (endindex+1 < filecontent.length()) {
			texts.add(filecontent.substring(endindex+1));
			arrowed.add(0);
		}
		String[] textsarr = new String[texts.size()];
		int[] arrarr = new int[arrowed.size()];

		//System.out.println(texts);
		
		textsarr = texts.toArray(textsarr);

		for (int i = 0; i<arrowed.size(); i++) {
			arrarr[i] = arrowed.get(i);
		}
		
		return new VecTextPanel(textsarr, arrarr, 20);
		
		
	}
	
	
	
	
	
	
	
}
