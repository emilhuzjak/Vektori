package mainpackage;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

import lessons.SpecificLessonPanel;
import lessons.osnovna.Intro;
import vectUtilities.Function;
import vectUtilities.Utility;

public class Field extends VectorsCart {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5288160450074321937L;

	public SpecificLessonPanel nextPanel() {
		return new Intro();
	}

	Graphics2D g2;

	// double x0 = -5, y0 = -5, w = 20, h = 20;
	public double resx = 5, resy = 5;

	int id = 1;

	double scal = 0.3;

	public Field() {
		setBackground(Color.cyan);
		gridLines = false;
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g2 = (Graphics2D) g;
		int wp = getWidth(), hp = getHeight();

		setPreferredSize(new Dimension(300, 500));
//		x0 = -w / 2;
//		y0 = -h / 2;
		double xor = Utility.map1(0, x0, wp / w), yor = Utility.map1(0, y0, wp / w);
		g2.setStroke(new BasicStroke(3));
		
//		if (drawAxes) {
//			Utility.drawLine(xor, 0, xor, hp, g2);
//			Utility.drawLine(0, yor, wp, yor, g2);
//		}

		g2.setStroke(new BasicStroke(1));
		g2.setColor(Color.red);
		int countx = 0;
		for (double x = x0; x <= x0 + xCoordSpan; x += resx) {
			for (double y = y0; y <= y0 + yCoordSpan; y += resy) {
				LocVektor lv = calc(x, y);

				lv.y = -lv.y;
				lv.fix();
				// System.out.println(lv);
				LocVektor mapped = Utility.map1V(lv, x0, y0, xunit);
				Utility.drawLocVector(mapped, g2);
			}
			countx++;
		}

	}

	public LocVektor calc(double x, double y) {
		double[] v = f.calc(x, y);
		return new LocVektor(x, y, v[0], v[1]).scaled(scal);
	}

	public Function f = new Function() {

		@Override
		public double[] calc(double x, double y) {
			// TODO Auto-generated method stub
			return new double[] { -y, x };
		}

	};

	ActionListener l;

	MouseListener m = new MouseListener() {

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			if (l != null)
				l.actionPerformed(new ActionEvent(this, id, "name"));
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}

	};

}
