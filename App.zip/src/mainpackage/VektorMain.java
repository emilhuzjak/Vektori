package mainpackage;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.SwingUtilities;
import javax.swing.Timer;

import exercises.Quiz;
import vectUtilities.Constants;
import vectUtilities.Utility;

public class VektorMain {

	static boolean triangles = false;
	static int id = 0;
	
	static  boolean isTp = false;

	static VektorFrame vf;
	static ActionListener listener;
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Utility.initTitles();
		
		int w = 700, h = 600;
		
		Quiz.loadQuestions();
		
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				
				//sp.l = listener;
				
				vf = new VektorFrame(w,h);
				vf.setLocationRelativeTo(null);
				vf.setLocation(500, 100);
				vf.addWindowListener(new WindowListener() {
					
					@Override
					public void windowOpened(WindowEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void windowIconified(WindowEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void windowDeiconified(WindowEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void windowDeactivated(WindowEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void windowClosing(WindowEvent e) {
						for (Timer t : Constants.timers) {
							t.stop();
						}
					}
					
					@Override
					public void windowClosed(WindowEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void windowActivated(WindowEvent e) {
						// TODO Auto-generated method stub
						
					}
				});
				MainPanel mp = new MainPanel();
				Constants.root = mp;
				mp.initGUI();
				
//				JTextArea jta = new JTextArea(Utility.readFile("Files/longtestfile.txt"));
//				jta.setLineWrap(true);
//				jta.setWrapStyleWord(true);
//				jta.setFont(new Font("Arial", 0, 20));
//				jta.setPreferredSize(new Dimension(100,100));
//				JPanel jp = new JPanel();
//				jp.setLayout(new BoxLayout(jp, BoxLayout.PAGE_AXIS));
//				jp.add(new VektorTextArea());
//				VectorsCart vc = new VectorsCart();
//				vc.painter = g -> {g.fillOval(0,0,200,200);};
//				vc.draggy = true;
//				vc.hoverEnabled = true;
//				vc.whichHoverTip = new int[]{1,1};
//				vc.whichHoverBase = new int[]{1,1};
//
//				jp.add(vc);
//				JPanel root = new JPanel();
//				root.add(new JScrollPane(jp, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));
				vf.add(mp);
				//				vf.add(new MainPanel());
				vf.revalidate();
				
				
			}
		});
		
		
		

	}

}
