package mainpackage;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import vectUtilities.Constants;

public class Question extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2917139965458928214L;

	int w = 300, h = 300;

	public int id;

	String q = "Pitanje";
	String[] options = { "Odgovor 1", "Odgovor 2", "Odgovor 3" };
	public int correct = 0;
	
	public int numopt = 3;

	public int clicked = -1;
	public boolean checked = false;

	String expl = "";

	public Question() {
		super();
		// setBackground(Color.white);
		setPreferredSize(new Dimension(w, h));
		repaint();
	}

	int buttonThickness = 30;
	int buttonTop;
	public JButton check;
	public Question(String ques, String[] opts, int correctone) {
		this();
		q = ques;
		options = opts;
		numopt = opts.length;
		buttonTop = qy + sizeFont * (1 + numopt) + optSpacing * (numopt + 1);
		check = new JButton("Provjeri");
		check.setBounds(150, buttonTop, 100, buttonThickness);

		setPreferredSize(new Dimension(500, buttonTop + buttonThickness + optSpacing));
		correct = correctone;
		addMouseListener(new Clicker());
		check.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				evaluate();

			}

		});
		setLayout(null);
		add(check);

	}
	
	public void evaluate() {
		if (clicked >= 0) {
			checked = true;
			repaint();
		}
	}

	int sizeFont = 20;
	int qy = 40;
	int optSpacing = sizeFont / 2;
	int r = sizeFont / 2;

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setFont(Constants.font2);
		sizeFont = Constants.font2.getSize();
		r = sizeFont/2;
		g.drawString(q, 50, qy + sizeFont);
		for (int i = 0; i < numopt; i++) {
			g.setColor(Color.black);
			int optTop = qy + sizeFont + optSpacing * (i + 1) + sizeFont * i;
			g.drawString(options[i], 90, optTop + sizeFont);
			if (clicked == i) {
				g.setColor(Color.blue);
				g.fillOval(50, optTop + (sizeFont / 2 - r), 2 * r, 2 * r);
			}
			((Graphics2D) g).setStroke(new BasicStroke(2));
			g.setColor(new Color(200, 200, 250));
			g.drawOval(48, optTop + (sizeFont / 2 - r) - 2, 2 * r + 4, 2 * r + 4);
			g.setColor(new Color(150, 150, 200));
			g.drawOval(49, optTop + (sizeFont / 2 - r) - 1, 2 * r + 2, 2 * r + 2);
			g.setColor(Color.blue);
			g.drawOval(50, optTop + (sizeFont / 2 - r), 2 * r, 2 * r);
		}
		if (checked && clicked == correct) {
			g.setColor(new Color(50, 150, 100));
			g.drawString("Točno", 300, buttonTop + sizeFont);
		} else if (checked && clicked != correct) {
			g.setColor(Color.red);
			g.drawString("Nije točno", 300, buttonTop + sizeFont);
		}

	}

	class Clicker implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub

			// TODO Auto-generated method stub
			int x = e.getX(), y = e.getY();
			for (int i = 0; i < numopt; i++) {
				int xp = 50 + r, yp = qy + sizeFont + (sizeFont / 2 - r) + optSpacing * (i + 1) + sizeFont * i + r;
				if (Math.sqrt((xp - x) * (xp - x) + (yp - y) * (yp - y)) < r) {
					// System.out.println(i);
					clicked = i;
					checked = false;
					SwingUtilities.invokeLater(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							repaint();
						}

					});
					return;
				}
			}

		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}

	}

	public static QuestionGroup buildQuestionGroup(String s) {

		QuestionGroup qg = new QuestionGroup();

		String[] qs = s.split("\\?_\\?");

		int num = qs.length;

		for (int i = 0; i < num; i++) {
			String[] parts = qs[i].split("\\$");
			if (parts.length < 2) {
				continue;
			}
			int idq=100, corr = 0;
			try {
				idq = Integer.parseInt(parts[0].trim());
			} catch (NumberFormatException e) {
				
			}
			try {
				corr = Integer.parseInt(parts[parts.length-1].trim())-1;
			} catch (NumberFormatException e) {
				
			}
			String[] ans = new String[parts.length-3];
			for (int an = 0; an<parts.length-3; an++) {
				ans[an] = parts[an+2].trim();
			}
			
			Question q = new Question(parts[1].trim(), ans, corr);
			q.id = idq;
			qg.add(q);

		}

		return qg;
	}

	public static class QuestionGroup {

		int num;

		public List<Question> questions = new ArrayList<>();

		public void add(Question q) {
			questions.add(q);
			num++;
		}
		
	}

}
