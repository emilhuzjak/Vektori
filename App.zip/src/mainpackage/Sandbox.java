package mainpackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Sandbox extends JPanel {

	private static final long serialVersionUID = -6932000854097428976L;

	JMenuBar navig = new JMenuBar();

	JMenu add = new JMenu("Zbrajanje");
	JMenu sub = new JMenu("Oduzimanje");

	JMenuItem i1 = new JMenuItem("Pravilo trokuta"), i2 = new JMenuItem("Pravilo paralelograma"),
			i3 = new JMenuItem("Pravilo trokuta"), i4 = new JMenuItem("Pravilo paralelograma");

	public Sandbox(int level) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				initMenu();
				addAddTriangle();
			}

		});

	}

	private void initMenu() {
		navig.add(add);
		navig.add(sub);
		add(navig);

		add.add(i1);
		add.add(i2);

		sub.add(i3);
		sub.add(i4);

		i1.addActionListener(l);
		i2.addActionListener(l);
		i3.addActionListener(l);
		i4.addActionListener(l);
	}

	ActionListener l = new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == i1) {
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						addAddTriangle();
					}
				});
				return;

			}
			if (e.getSource() == i2) {
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						addAddParall();

					}
				});
				return;
			}

			if (e.getSource() == i3) {
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						addSubTriangle();

					}
				});
				return;
			}
			if (e.getSource() == i3) {
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						addSubParall();

					}
				});
				return;
			}

		}
	};

	JPanel jp = new JPanel();

	public void addAddTriangle() {

		remove(jp);
		VectorsCart vc1 = new VectorsCart();
		vc1.setPreferredSize(new Dimension(2000, 2000));
		vc1.putVector(new LocVektor(-3, -2, 3, 0), 1, 1, 0, 0);
		vc1.putVector(new LocVektor(0, 0, 1, 4), 1, 1, 0, 0);
		vc1.putVector(new LocVektor(0, 0, 1, 1), 0, 0, 0, 0);
		vc1.gridLines = vc1.drawAxes = false;
		vc1.hoverEnabled = false;
		vc1.draggy = true;
		vc1.visible.set(2, 0);

		vc1.initialize();
		vc1.setup();

		vc1.customColors = true;
		vc1.colors = Arrays.asList(new Color[] { Color.blue, Color.red, Constants.dark_green1 });

		vc1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x1, v1.y1);
				cart.vecList.set(2, LocVektor.add(v1, v2));

			}

		};
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				g.setColor(Color.black);

				g.setFont(Constants.font1);

				cart.mapAllToScreen();

				LocVektor v3 = cart.screenVecs.get(2);
				LocVektor v1 = cart.screenVecs.get(0), v2 = cart.screenVecs.get(1);

				Utility.drawString(g, "A", v1.x0, v1.y0);
				Utility.drawString(g, "B", v1.x1, v1.y1);
				Utility.drawString(g, "C", v2.x1, v2.y1);

				v1.mid();
				v2.mid();
				v3.mid();
				Utility.drawFancyString(new String[] { "AB" }, new int[] { 1 }, v1.midx, v1.midy, g);

				Utility.drawFancyString(new String[] { "BC" }, new int[] { 1 }, v2.midx, v2.midy, g);

				if (cart.visible.get(2) == 1) {
					Utility.drawFancyString(new String[] { "AC", "=", "AB", "+", "BC" }, new int[] { 1, 0, 1, 0, 1 },
							v3.midx, v3.midy, g);

				}

			}
		};
		JButton disc = new JButton("Zbroji");
		disc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				vc1.visible.set(2, 1 - vc1.visible.get(2));
				vc1.repaint();
			}
		});
		vc1.add(disc);
		add(vc1);
		jp = vc1;
		vc1.repaint();

	}

	public void addAddParall() {

		remove(jp);
		VectorsCart vc2 = new VectorsCart();
		vc2.setPreferredSize(new Dimension(2000, 2000));
		vc2.putVector(new LocVektor(-3, -2, 3, 0), 1, 1, 0, 0);
		vc2.putVector(new LocVektor(0, 0, 1, 4), 1, 1, 0, 0);
		vc2.putVector(new LocVektor(0, 0, 1, 1), 0, 0, 0, 0);
		vc2.gridLines = vc2.drawAxes = false;
		vc2.hoverEnabled = false;
		vc2.draggy = true;
		vc2.visible.set(2, 0);

		vc2.initialize();
		vc2.setup();

		vc2.customColors = true;
		vc2.colors = Arrays.asList(new Color[] { Color.blue, Color.red, Constants.dark_green1 });

		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x0, v1.y0);
				cart.vecList.set(2, LocVektor.add(v1, v2));

				cart.mapAllToScreen();
				if (cart.visible.get(2) == 1)
					Utility.drawParallelogramGuides(g, cart.screenVecs.get(0), cart.screenVecs.get(1));

			}

		};
		JButton disc2 = new JButton("Zbroji (paralelogramom)");
		vc2.add(disc2);
		disc2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				vc2.visible.set(2, 1 - vc2.visible.get(2));
				vc2.repaint();
			}
		});
		add(vc2);
		jp = vc2;
		vc2.repaint();
	}

	public void addSubTriangle() {
		remove(jp);
		VectorsCart vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(-3, -2, 3, 0), 1, 1, 0, 0);
		vc1.putVector(new LocVektor(0, 0, 1, 4), 1, 1, 0, 0);
		vc1.putVector(new LocVektor(0, 0, 1, 1), 0, 0, 0, 0);
		vc1.putVector(new LocVektor(), 0, 0, 0, 0);
		vc1.gridLines = vc1.drawAxes = false;
		vc1.hoverEnabled = false;
		vc1.draggy = true;
		vc1.visible.set(2, 0);
		vc1.visible.set(3, 0);

		vc1.initialize();
		vc1.setup();

		vc1.customColors = true;
		vc1.colors = Arrays.asList(new Color[] { Color.blue, Color.red, Constants.dark_green1, Color.orange });

		vc1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x1, v1.y1);
				LocVektor vopp = v2.copy();
				vopp.scale(-1);
				cart.vecList.set(3, vopp);
				cart.vecList.set(2, LocVektor.add(v1, vopp));

			}

		};
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				g.setColor(Color.black);

				g.setFont(Constants.font1);

				cart.mapAllToScreen();

				LocVektor v3 = cart.screenVecs.get(2);
				LocVektor v1 = cart.screenVecs.get(0), v2 = cart.screenVecs.get(1), vopp = cart.screenVecs.get(3);

				v1.mid();
				v2.mid();
				v3.mid();
				vopp.mid();
				Utility.drawFancyString(new String[] { "A" }, new int[] { 1 }, v1.midx, v1.midy, g);

				Utility.drawFancyString(new String[] { "B" }, new int[] { 1 }, v2.midx, v2.midy, g);

				if (cart.visible.get(2) == 1) {
					Utility.drawFancyString(new String[] { "A", "=", "B", "-", "C" }, new int[] { 1, 0, 1, 0, 1 },
							v3.midx, v3.midy, g);
					Utility.drawFancyString(new String[] { "-", "B" }, new int[] { 0, 1 }, vopp.midx, vopp.midy, g);

				}

			}
		};
		JButton disc = new JButton("Zbroji");
		disc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				vc1.visible.set(2, 1 - vc1.visible.get(2));
				vc1.visible.set(3, 1 - vc1.visible.get(3));

				vc1.repaint();
			}
		});
		vc1.add(disc);
		add(vc1);
		jp = vc1;
	}

	public void addSubParall() {
		remove(jp);
		VectorsCart vc2 = new VectorsCart();
		vc2.putVector(new LocVektor(-3, -2, 3, 0), 1, 1, 0, 0);
		vc2.putVector(new LocVektor(0, 0, 1, 4), 1, 1, 0, 0);
		vc2.putVector(new LocVektor(0, 0, 1, 1), 0, 0, 0, 0);
		vc2.putVector(new LocVektor(), 0, 0, 0, 0);
		vc2.gridLines = vc2.drawAxes = false;
		vc2.hoverEnabled = false;
		vc2.draggy = true;
		vc2.visible.set(2, 0);
		vc2.visible.set(3, 0);

		vc2.initialize();
		vc2.setup();

		vc2.customColors = true;
		vc2.colors = Arrays.asList(new Color[] { Color.blue, Color.red, Constants.dark_green1, Color.orange });

		vc2.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v1 = cart.vecList.get(0), v2 = cart.vecList.get(1);
				v2.setStartAt(v1.x0, v1.y0);

				LocVektor vopp = v2.copy();
				vopp.scale(-1);
				cart.vecList.set(3, vopp);
				cart.vecList.set(2, LocVektor.add(v1, vopp));

				cart.mapAllToScreen();
				if (cart.visible.get(2) == 1)
					Utility.drawParallelogramGuides(g, cart.screenVecs.get(0), cart.screenVecs.get(3));

			}

		};
		JButton disc2 = new JButton("Zbroji (paralelogramom)");
		vc2.add(disc2);
		disc2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				vc2.visible.set(2, 1 - vc2.visible.get(2));
				vc2.visible.set(3, 1 - vc2.visible.get(3));

				vc2.repaint();
			}
		});
		add(vc2);
		jp = vc2;
	}
}
