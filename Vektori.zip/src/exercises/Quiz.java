package exercises;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

import mainpackage.Question;
import vectUtilities.BarChart;
import vectUtilities.Constants;
import vectUtilities.Utility;

public class Quiz extends JPanel {

	private static final long serialVersionUID = -2862433524068847037L;

	Question.QuestionGroup group;

	int numCorrect = 0;
	int numTotal = 1;

	public Quiz(int level) {
		if (level >= 0 && level < groups.size()) {
			group = groups.get(level);
			initGUI();
		}

		save.setEnabled(false);

		startTest.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!quizrun) {
					quizrun = true;
					startTest.setText("Zaustavi kviz");
					for (Question q : group.questions) {
						q.remove(q.check);
					}
					repaint();
				} else if (quizrun) {
					quizrun = false;
					startTest.setText("Isprobaj kviz");
					for (Question q : group.questions) {
						q.add(q.check);
					}
					repaint();
				}
			}
		});

		checkB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				numCorrect = 0;
				for (Question q : group.questions) {
					if (q.clicked == q.correct) {
						numCorrect++;
					}
				}
				numTotal = group.questions.size();
				// checkB.setEnabled(false);
				scoreL.setText(numCorrect + "/" + numTotal + " (" + numCorrect * 1.0 / numTotal + "%)");
				save.setEnabled(true);
			}

		});
		save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog("Ime: ");
				Utility.appendFile(files.get(level), name+" " + numCorrect * 1.0 / numTotal + " " + numCorrect + " " + numTotal);
			}

		});
		scores.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String scoreStr = Utility.readFile(files.get(level));
				boolean empty = false;
				if (scoreStr.trim().equals("")) {
					empty = true;
					scoreStr = "Zasad nema rezultata. Rijesite kviz da provjerite nauceno";
				}
				JTextArea jta = new JTextArea(scoreStr);
				jta.setFont(new Font("Arial", 0, 20));
				JPanel scP = new JPanel();
				
				scP.add(jta);
				scP.setLayout(new BoxLayout(scP,BoxLayout.Y_AXIS));
				if (!empty) {
					
					String[] s = scoreStr.split("\n");
					double[] l = new double[s.length];
					for (int i = 0; i<s.length; i++) {
						String st = s[i];
						l[i] = (Double.parseDouble(st.split(" ")[1].trim()));
					}
					scP.add(new BarChart(300, 400, l));
				}
				
				Constants.root.replacePanel(scP,true);
			}
		});

	}

	JLabel scoreL = new JLabel();

	JScrollPane scroll;

	boolean quizrun = false;

	JButton startTest = new JButton("Isprobajte kviz");
	JButton checkB = new JButton("Provjeri odgovore");
	JButton save = new JButton("Spremi rezultate");
	JButton scores = new JButton("Napredak");
	public void initGUI() {

		JPanel qs = new JPanel();

		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		qs.setLayout(new BoxLayout(qs, BoxLayout.PAGE_AXIS));
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				qs.add(startTest);
				if (group != null) {
					for (Question q : group.questions) {
						Border blackline = BorderFactory.createTitledBorder(q.id + "");
						q.setBorder(blackline);
						// q.remove(q.check);
						qs.add(q);
					}
				}
				qs.add(checkB);
				qs.add(scoreL);
				qs.add(save);
				qs.add(scores);
				qs.revalidate();
				scroll = new JScrollPane(qs, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
						JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scroll.getVerticalScrollBar().setUnitIncrement(16);
				add(scroll);

			}
		});
	}

	static List<Question.QuestionGroup> groups = new ArrayList<>();

	List<String> files = Arrays.asList(new String[] {"Files/scores/kvizovi/os.txt", 
			"Files/scores/kvizovi/sr.txt", "Files/scores/kvizovi/f.txt"
	});

	public static void loadQuestions() {
		groups.add(Question.buildQuestionGroup(Utility.readFile("Files/pitanja/osnovna/q.txt")));
		groups.add(Question.buildQuestionGroup(Utility.readFile("Files/pitanja/srednja/q.txt")));
		groups.add(Question.buildQuestionGroup(Utility.readFile("Files/pitanja/fakultet/q.txt")));

	}

}
