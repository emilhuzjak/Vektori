package exercises;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import mainpackage.Field;
import vectUtilities.Function;
import vectUtilities.Utility;

public class FieldPicker extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	int index = (int)Utility.random(0,5);
	double xcomp, ycomp;
	
	public FieldPicker() {

		super();
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				setLayout(new GridLayout(3,2, 50, 50));
				// TODO Auto-generated method stub
				
				add(new JLabel("Odaberi sliku koja prikazuje polje "));
				add(new JLabel());
				for (int i = 0; i<4; i++) {
					double xf = Utility.random(-4, 4), yf = Utility.random(-4, 4);
					Field field = new Field();
					
					if (i == index) {
						xcomp = xf; ycomp = yf;
					}
					
					field.f = new Function() {

						@Override
						public double[] calc(double x, double y) {
							// TODO Auto-generated method stub
							return new double[] {xf*x, yf*y};
						}
						
					};
					
					field.resx = field.resy = 1;
					add(field);
				}
				
				
				revalidate();
				repaint();
				
				
			}
		});

	
	}
	
//	@Override
//	public void paintComponent(Graphics g) {
//		super.paintComponent(g);
//		g.setColor(Color.black);
//		g.setFont(new Font("Arial", 2, 20));
//		g.drawString("Odaberi sliku koja prikazuje polje", 10, 50);
//		
//	}
	
	
	
	
	
	
	
	
}
