package exercises;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import mainpackage.StartPanel;
//import mainpackage.TaskPanel;
import mainpackage.VektorFrame;

public class ExerciseSelection extends JPanel {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 603071453360242650L;
	
	JMenuBar bar = new JMenuBar();
	JMenu menu1, menu2, menu3, menu4, menu5;
	
	JMenuItem i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14;
	
	JPanel jp;
	
	public void initializeMenu() {
		JPanel p = new JPanel();
		menu1 = new JMenu("Zbrajanje");
		menu2 = new JMenu("Oduzimanje");
		menu3 = new JMenu("Skalarni produkt");
		menu4 = new JMenu("Uvod");
		menu5 = new JMenu("Polja");
		
		
		i1 = new JMenuItem("Izračunaj zbroj");
		i2 = new JMenuItem("Zbrajanje 2");
		i3 = new JMenuItem("Izračunaj nepoznanicu");
		i4 = new JMenuItem("Izračunaj razliku");
		i5 = new JMenuItem("Oduzimanje 3");
		i6 = new JMenuItem("Izračunaj umnožak");
		i7 = new JMenuItem("Ortogonalnost");
		i8 = new JMenuItem("Pronađi vektor");
		i9 = new JMenuItem("Izračunaj kut");
		i10 = new JMenuItem("Linearna kombinacija");
		i11 = new JMenuItem("Jedinični vektori");
		i12 = new JMenuItem("Vektor zadanog kuta");
		i13 = new JMenuItem("Odredi funkciju polja");
		i14 = new JMenuItem("Nadi jednake vektore");
		i1.addActionListener(l);
		i3.addActionListener(l);
		i4.addActionListener(l);
		i6.addActionListener(l);
		i7.addActionListener(l);
		i8.addActionListener(l);
		i9.addActionListener(l);
		i10.addActionListener(l);
		i11.addActionListener(l);
		i12.addActionListener(l);
		i13.addActionListener(l);
		i14.addActionListener(l);
		menu1.add(i1);
		menu1.add(i2);
		menu1.add(new JMenuItem("Sile"));
		menu1.add(new JMenuItem("Zbrajanje 3D"));
		
		menu2.add(i3);
		menu2.add(i4);
		menu2.add(new JMenuItem("Oduzimanje 3D"));
		menu2.add(new JMenuItem("Paralelogram"));
		menu2.add(new JMenuItem("Ponistavanje"));
		//menu2.add(i5);
		menu3.add(i6);
		menu3.add(i7);
		menu3.add(new JMenuItem("Rad"));
		menu4.add(i8);
		menu3.add(i9);
		
		menu4.add(new JMenuItem("Orijentacija"));
		menu4.add(new JMenuItem("Omjer"));

		menu4.add(i10);
		menu4.add(i11);
		menu3.add(new JMenuItem("Izracunaj okomiti"));
		menu4.add(i12);
		menu5.add(i13);
		menu3.add(i14);
		menu5.add(new JMenuItem("Divergencija 1"));
		menu5.add(new JMenuItem("Divergencija 2"));
		menu5.add(new JMenuItem("Naboji"));
		
		bar.add(menu1);
		bar.add(menu2);
		bar.add(menu3);
		bar.add(menu4);
		bar.add(menu5);
		
		p.add(bar);
		add(p);

	}
	
	
	DotProductCalc dpc = new DotProductCalc();
	
	public ExerciseSelection() {
		super();
		
		
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				setLayout(new BoxLayout(ExerciseSelection.this, BoxLayout.PAGE_AXIS));
				initializeMenu();
				add(dpc);
				jp = dpc;
				revalidate();
				repaint();
			}
		});
	}
	
	ActionListener backListener;
	
	
	public void replaceExercise(JPanel newp) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				
				if (jp == newp)
					return;
				remove(jp);
				jp = newp;
				add(jp);
				
				revalidate();
				repaint();
				
			}
		});
	}
	
	
	
	ActionListener l = new ActionListener() {



		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource().equals(i1)) {
				if (jp instanceof AdditionCalc)
					return;
				replaceExercise(new AdditionCalc());
				return;
			}
			if (e.getSource().equals(i3)) {
				if (jp instanceof SubCalc1)
					return;
				replaceExercise(new SubCalc1());
				return;
			}
			if (e.getSource().equals(i4)) {
				if (jp instanceof SubCalc)
					return;
				replaceExercise(new SubCalc());
				return;
			}
			if (e.getSource().equals(i6)) {
				if (jp instanceof DotProductCalc)
					return;
				replaceExercise(new DotProductCalc());
				return;
			}
			if (e.getSource().equals(i7)) {
				if (jp instanceof DotProd0)
					return;
				replaceExercise(new DotProd0());
				return;
			}
			if (e.getSource().equals(i8)) {
				if (jp instanceof TaskPanel)
					return;
				TaskPanel tp = new TaskPanel();
				tp.setPreferredSize(new Dimension(2000,1000));
				replaceExercise(tp);
				return;
			}
			if (e.getSource().equals(i9)) {
				if (jp instanceof AngleCalc)
					return;
				replaceExercise(new AngleCalc());
				return;
			}
			if (e.getSource().equals(i10)) {
				if (jp instanceof LinearComb)
					return;
				replaceExercise(new LinearComb());
				return;
			}
			if (e.getSource().equals(i11)) {
				if (jp instanceof UnitVectorCalc)
					return;
				replaceExercise(new UnitVectorCalc());
				return;
			}
			if (e.getSource().equals(i12)) {
				if (jp instanceof AngleGiven)
					return;
				replaceExercise(new AngleGiven());
				return;
			}
			if (e.getSource().equals(i13)) {
				if (jp instanceof FieldPicker)
					return;
				replaceExercise(new FieldPicker());
				return;
			}
			if (e.getSource().equals(i14)) {
				if (jp instanceof HexPicker)
					return;
				replaceExercise(new HexPicker());
				return;
			}
		}
		
	};

	public VektorFrame vf;
	
	
	
}
