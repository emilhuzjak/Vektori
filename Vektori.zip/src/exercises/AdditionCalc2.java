package exercises;

import javax.swing.JPanel;

public class AdditionCalc2 extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2246556848890958142L;

}
