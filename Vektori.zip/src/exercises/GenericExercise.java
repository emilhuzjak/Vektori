package exercises;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

public class GenericExercise extends JPanel {

	JButton b1, b2, b3, b4, b5;
	public GenericExercise() {
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		b1 = new JButton("Provjeri");
		b2 = new JButton("Sljedeci");
		b3 = new JButton("Resetiraj odgovore");
		b4 = new JButton("Otkrij");
		b5 = new JButton("Preskoci");
		
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				check();
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				next();
			}
		});
		
		b3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				resetAnswers();
			}
		});
		b4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				reveal();
			}
		});
		b5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				skip();
			}
		});
		
		
		JPanel p = new JPanel();
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.add(b4);
		p.add(b5);
		add(p);
		
	}
	
	
	public void check() {
		
	}
	

	public void next() {
		
	}
	
	public void resetAnswers() {
		
	}
	
	public void reveal() {
		
	}
	
	public void skip() {
		
	}
	
}
