package sim;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.Timer;

import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class LinComb extends VectorsCart {

	
	public LocVektor a, b, acopy, bcopy, add;
	public LocVektor aline, bline;
	
	public double a1 = 1, a2 = 1;
	
	public double xstart, ystart;
	
	public boolean paralellogram = false;
	
	public LocVektor adiff, bdiff, adiffC, bdiffC;
	public int tms = 50, n=30, step = 0;
	public int stage = 0;
	
	public LinComb() {
		setBackground(Color.cyan);
		prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				map(xstart, ystart);
				Utility.fillCircle(g, xs, ys, 2);
				if (paralellogram && parLines) {
					Utility.drawVecLine(mapper.mapToScreen(aline), g, 1000, 1000);
					Utility.drawVecLine(mapper.mapToScreen(bline), g, 1000, 1000);
				}
			}
			
		};
	}
	
	boolean parLines = false;
	
	ActionListener act = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			step++;
			
			adiffC = adiff.copy();
			adiffC.scale(step*1.0/n);
			acopy = a.copy();
			acopy.translate(adiffC);
			
			bdiffC = bdiff.copy();
			bdiffC.scale(step*1.0/n);
			bcopy = b.copy();
			bcopy.translate(bdiffC);
			
			vecList.set(2, acopy);
			vecList.set(3, bcopy);
			
			if (step >= n) {
				t.stop();
				stage = 2;
				visible.set(numVectors-1, 1);
				anim = false;
				step = 0;
				parLines = true;
				if (a1 != 1 || a2 != 1) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					acopy.scale(a1);
					bcopy.scale(a2);
					repaint();
				}
				System.out.println("done");

			}
			repaint();
		}
	};
	public Timer t = new Timer(tms, act);
	
	public boolean anim = false;
	
	public void init() {
		if (a!=null && b!=null) {
			putVector(a, 1,1,0,0);
			putVector(b, 1,1,0,0);
			acopy = a.copy();
			bcopy = b.copy();
			putVector(acopy, 0,0,0,0);
			putVector(bcopy, 0,0,0,0);
			
			add = LocVektor.add(a.scaled(a1), b.scaled(a2));
			add.translateTo(xstart, ystart);
			putVector(add, 0,0,0,0);
			visible.set(2,0);
			visible.set(3,0);
			visible.set(numVectors-1, 0);
			acopy.translateTo(xstart, ystart);
			if (paralellogram) {
				bcopy.translateTo(a.x0, a.x0);
				
			} else {
				bcopy.translateTo(a.x1, a.x1);
			}
			
			customColors = true;
			colors = Arrays.asList(new Color[] {Color.red, Color.blue, Color.red, Color.blue, Color.black});
			
			x0 = -20;
			y0 = -10;
			xCoordSpan = 40;
			yCoordSpan = 20;
			drawAxes = false;
			gridLines = false;
			initialize();
			setup();
			drawLabels = true;
			labels = Arrays.asList(new String[] {"AB", "BC", "AB", "BC", "AC"});
			
		}
	}
	

	public void animate() {
		
		parLines = false;
		visible.set(2,1);
		visible.set(3,1);
		acopy = a.copy();
		bcopy = b.copy();
		
		vecList.set(2, acopy);
		vecList.set(3, bcopy);
		
		add = LocVektor.add(a.scaled(a1), b.scaled(a2));
		add.translateTo(xstart, ystart);
		visible.set(4, 0);
		vecList.set(4, add);
		stage = 1;
		
		adiff = new LocVektor(a.x0, a.y0, xstart, ystart, true);
		adiffC = adiff.copy();
		
		double xs2 = xstart, ys2 = ystart;
		if (!paralellogram) {
			xs2 += a.x;
			ys2 += a.y;
		}
		
		bdiff = new LocVektor(b.x0, b.y0, xs2, ys2, true);
		bdiffC = bdiff.copy();
		anim = true;
		t.start();
		aline = a.copy();
		aline.translateTo(xstart+b.x*a2, ystart + b.y*a2);
		bline = b.copy();
		bline.translateTo(xstart+a.x*a1, ystart + a.y*a1);
	}
	
}
