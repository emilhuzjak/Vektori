package textDisplays;

import java.awt.Font;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import vectUtilities.Constants;
import vectUtilities.Utility;

public class VTextPane extends JTextPane {

	private static final long serialVersionUID = -1633765405353585087L;

	SimpleAttributeSet plainText = new SimpleAttributeSet();
	SimpleAttributeSet boldText = new SimpleAttributeSet();
	StyledDocument doc;
	Style styleImg;

	public Map<String, ImageIcon> vecImages = new HashMap<>();
	
	Font font = Constants.font1;
	int fontSize = Constants.fontSize;
	
	public VTextPane() {
		setEditable(false);
		setFont(font);
		StyleConstants.setBold(boldText, true);
		doc = (StyledDocument) getStyledDocument();
		styleImg = doc.addStyle("StyleName", null);
		
		
		
		
		
		
	}
	
	public VTextPane(String s) {
		this();
		setText(s);
	}
	
	public int count = 0;
	public void insertVec(String v) throws BadLocationException {
		//if (count > 1) return;
		ImageIcon ic;
		if (count==5)System.out.print(v+" ");
		if (!vecImages.containsKey(v)) {
			ic = Utility.imageText(v, 10, fontSize);
			vecImages.put(v, ic);
		}
		else {
			ic = vecImages.get(v);
		}
		StyleConstants.setIcon(styleImg, ic);
		doc.insertString(doc.getLength(), "a", styleImg);
		count++;
	}
	
	public void readVecText(String t) {
		try {
			readVText(t);
		}catch (BadLocationException e) {
			System.out.println(e.getMessage());
		}
		revalidate();
	}
	
	public void readVText(String t) throws BadLocationException {
		List<String> parts = Utility.splitSections(t, "#vec", "#/vec");
		String f = parts.remove(0);
		int arrowF = 0;
		if (f.equals("1")) {
			arrowF = 1;
		}
		for (String s : parts) {
			if (arrowF == 1) {
				insertVec(s);
			} else {
				doc.insertString(doc.getLength(), s, plainText);
			}
			arrowF = 1 - arrowF;
		}
		revalidate();
	}
	
	public void clear() {
		removeStyle("StyleName");
		setText("");
	}
	
	
	
	public void insertImage(BufferedImage im)  {
		ImageIcon ic = new ImageIcon(im);
//		JLabel jl = new JLabel(ic);
//		jl.setVerticalAlignment(JLabel.CENTER);
//		JPanel jp = new JPanel();
//		jp.add(jl);
	    //StyleConstants.setComponent(styleImg, jp);
		StyleConstants.setIcon(styleImg, ic);
		try {
			doc.insertString(doc.getLength(), " ", styleImg);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}

	}
	
	
}
