package vectUtilities;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

import mainpackage.LocVektor;

public class Utility {

	
	public static ImageIcon imageText(String text, int w, int h) {

		BufferedImage im = new BufferedImage(w,h,2);
		Graphics g = im.createGraphics();
		g.setFont(new Font("Arial", 1, h-4));
		int width = g.getFontMetrics().stringWidth(text);
		
		im = new BufferedImage(width+6,h,2);
		
		g = im.createGraphics();
		
		g.setColor(Color.black);
		g.setFont(new Font("Arial", 1, h-4));
		g.drawLine(1, 3, width+3, 3);
		
		((Graphics2D) g).setStroke(new BasicStroke(1));
		g.fillOval(width-2,1,4,4);
		g.drawLine(width+3, 3, width-2, 1);
		g.drawLine(width+3, 3, width-2, 5);
		g.drawString(text, 3, h-3);
		
		
		
		
		return new ImageIcon(im);
		
	}
	
	public static BufferedImage conc(BufferedImage[] imgs, int space, int vertAlign) {
		int len = imgs.length;
		int[] ws = new int[len];
		int totalW = 0;
		int maxH = -1;
		for (int i = 0; i<len; i++) {
			ws[i] = imgs[i].getWidth();
			totalW += ws[i];
			int h = imgs[i].getHeight();
			if (h>maxH) {
				maxH = h;
			}
		}
		
		BufferedImage res = new BufferedImage(totalW + space*(len-1), maxH, 2);
		Graphics2D g = (Graphics2D)res.getGraphics();
		
		
		int xTot = 0;
		
		for (int i = 0; i<len; i++) {
			int h = imgs[i].getHeight();

			int y = 0;
			if (vertAlign == 0) {
				y = (maxH - h)/2;
			}
			else if (vertAlign < 0) {
				y = maxH - h;
			}
			
			
			drawOver(res, imgs[i], xTot,y);
			xTot += ws[i]+space;
		}
		
		
		
		return res;
		
	}
	
	public static BufferedImage buffImageText(String text, int w, int h, boolean vec) {

		BufferedImage im = new BufferedImage(w,h,2);
		Graphics g = im.createGraphics();
		g.setFont(new Font("Arial", 1, h-4));
		int width = g.getFontMetrics().stringWidth(text);
		
		im = new BufferedImage(width+6,h,2);
		
		g = im.createGraphics();
		

		g.setColor(Color.black);
		g.setFont(new Font("Arial", 1, h-4));
		if (vec)g.drawLine(1, 3, width+3, 3);
		
		((Graphics2D) g).setStroke(new BasicStroke(1));
		if (vec) {
			g.fillOval(width-2,1,4,4);
			g.drawLine(width+3, 3, width-2, 1);
			g.drawLine(width+3, 3, width-2, 5);
		}
		
		g.drawString(text, 3, h-3);
		
		
		
		
		return im;
		
	}
	
	public static BufferedImage sqImg(BufferedImage im) {
		int w = im.getWidth(), h = im.getHeight();
		int margL = 0, margR = h/2,margT = h/5, margB = 0;
		BufferedImage res = new BufferedImage(w+margL+margR, h+margT+margB,2);
		
		Graphics2D g = (Graphics2D) res.getGraphics();
		drawOver(res, im, margL, margT);
		g.setColor(Color.black);
		g.setFont(new Font("Arial", 0, 2*h/3));
		g.setStroke(Constants.bs2);
		Utility.drawString(g, "2", margL + w, 2*h/3);
//		Utility.drawLine(margL/2, margT+h, margL, 1, g);
//		Utility.drawLine(w+margR + margL,1, margL-1, 1, g);

		return res;
	}
	
	public static BufferedImage sqrtIm(BufferedImage im) {
		
		
		int w = im.getWidth(), h = im.getHeight();
		int margL = 7, margR = 1,margT = 3, margB = 0;
		BufferedImage res = new BufferedImage(w+margL+margR, h+margT+margB,2);
		
		Graphics2D g = (Graphics2D) res.getGraphics();
		
		drawOver(res, im, margL, margT);
		g.setColor(Color.black);
		g.setStroke(Constants.bs2);
		Utility.drawLine(0, margT+h/2, margL/2, h+margT, g);
		Utility.drawLine(margL/2, margT+h, margL, 1, g);
		Utility.drawLine(w+margR + margL,1, margL-1, 1, g);

		return res;
	}
	
	public static BufferedImage exp(String exp, int h) {
		BufferedImage res = new BufferedImage(1,1,2);
		
		Graphics2D g = (Graphics2D) res.getGraphics();
		
		g.setColor(Color.black);
		g.setFont(new Font("Arial", 0, h/2));
		FontMetrics fm = g.getFontMetrics();
		int stw = fm.stringWidth(exp);
		
		res = new BufferedImage(stw+2, h, 2);
		g = (Graphics2D)res.getGraphics();
		g.setColor(Color.black);
		g.setFont(new Font("Arial", 0, h/2));

		g.drawString(exp, 1, h/2);
		
		return res;
	}
	
	public static BufferedImage exp(BufferedImage im, String ex) {

		int w = im.getWidth(), h = im.getHeight();
		int margL = 0, margR = 2,margT = h/5, margB = 0;
		BufferedImage res = new BufferedImage(1,1,2);
		
		Graphics2D g = (Graphics2D) res.getGraphics();
		g.setFont(new Font("Arial", 0, 2*h/3));
		
		FontMetrics fm = g.getFontMetrics();
		int stw = fm.stringWidth(ex);
		res = new BufferedImage(w+stw+2, h+margT+margB, 2);
		
		drawOver(res, im, margL, margT);
		g.setColor(Color.black);
		g.setFont(new Font("Arial", 0, 2*h/3));
		g.setStroke(Constants.bs2);
		Utility.drawString(g, ex, margL + w, 2*h/3);
//		Utility.drawLine(margL/2, margT+h, margL, 1, g);
//		Utility.drawLine(w+margR + margL,1, margL-1, 1, g);

		return res;
	
	}
	
	public static BufferedImage frac(BufferedImage top, BufferedImage bottom) {
		
		
		int w1 = top.getWidth(), h1 = top.getHeight(),
				w2 = bottom.getWidth(), h2 = bottom.getHeight();
		
		int middle = 6;
		
		int w = Math.max(w1, w2);
		
		int margL = 7, margR = 1,margT = 3, margB = 0;
		BufferedImage res = new BufferedImage(w, h1+h2+middle,2);
		
		Graphics2D g = (Graphics2D) res.getGraphics();
		
		drawOver(res, top, w/2-w1/2, 0);
		drawOver(res, bottom, w/2-w2/2, h1+middle);

		
		
		g.setColor(Color.black);
		g.setStroke(Constants.bs1);
		Utility.drawLine(0, h1+middle/2, w, h1+middle/2, g);
		

		return res;
	}
	
	public static BufferedImage angleSymbol(int h) {
		
		
		
		BufferedImage res = new BufferedImage(h, h,2);
		
		Graphics2D g = (Graphics2D) res.getGraphics();
		
		
		g.setStroke(Constants.bs2);
		g.setColor(Color.black);
		Utility.drawLine(0, h-2, h/2, 1, g);
		Utility.drawLine(0, h-2, h, h-2, g);


		return res;
	}
	
	public static void drawOver(BufferedImage background, BufferedImage drawing, int x, int y) {
		Graphics2D g = (Graphics2D) background.getGraphics();
		g.drawImage(drawing, x, y, null);

	}
	
	public static void fillImg(BufferedImage im, Graphics g, Color c) {
		Color c0 = g.getColor();
		g.setColor(c);
		g.fillRect(0, 0, im.getWidth(), im.getHeight());
		g.setColor(c0);
	}
	
	
	public static JPanel sizePanel(int w, int h) {
		JPanel p = new JPanel();
		p.setPreferredSize(new Dimension(w,h));
		return p;
	}
	
	
	public static BufferedImage drawModulus(BufferedImage im) {

		
		
		BufferedImage b = new BufferedImage(im.getWidth(), im.getHeight(), im.getType());
	    Graphics gic = b.getGraphics();
	    gic.drawImage(im, 0, 0, null);
	    //
		
		
		((Graphics2D) gic).setStroke(new BasicStroke(2));
		gic.setColor(Color.black);
		gic.drawLine(1, 2, 1, im.getHeight()-3);
		gic.drawLine(im.getWidth()-1, 2, im.getWidth()-1, im.getHeight()-3);
		gic.dispose();
		return b;
		
	
		
	}
	
	public static ImageIcon drawModulus(ImageIcon ic) {
		
		BufferedImage im = (BufferedImage)ic.getImage();
		BufferedImage b = new BufferedImage(im.getWidth(), im.getHeight(), im.getType());
	    Graphics gic = b.getGraphics();
	    gic.drawImage(im, 0, 0, null);
	    //
		
		
		((Graphics2D) gic).setStroke(new BasicStroke(2));
		gic.setColor(Color.black);
		gic.drawLine(1, 2, 1, im.getHeight()-3);
		gic.drawLine(im.getWidth()-1, 2, im.getWidth()-1, im.getHeight()-3);
		gic.dispose();
		ImageIcon ic2 = new ImageIcon(b);
		return ic2;
		
	}
	
	public static void drawString(Graphics g, String s, double x, double y) {
		g.drawString(s, (int)x, (int)y);
	}
	
	
	public static BufferedImage expressionIm(Expr e, int h) {
		
		if (e.op == Expr.Op.div) {

			BufferedImage top = expressionIm(e.subExpr.get(0),h),
					bottom = expressionIm(e.subExpr.get(1),h);
			
			int w1 = top.getWidth(), h1 = top.getHeight(),
					w2 = bottom.getWidth(), h2 = bottom.getHeight();
						
			int w = Math.max(w1, w2);
			
			BufferedImage result = new BufferedImage(w, h1+h2,2);
			
			Graphics2D g = (Graphics2D) result.getGraphics();
			
			drawOver(result, top, w/2-w1/2, 0);
			drawOver(result, bottom, w/2-w2/2, h1);
			
			Utility.drawLine(0, h1, w, h1, g);

			return result;
		
		}
		
		
		
		boolean stringy = e.vars.size() > 0;
		
		if (e.op == Expr.Op.square && stringy) {
			return sqImg(Utility.buffImageText(e.vars.get(0), 1, h, false));
		}
		
		if (e.op == Expr.Op.sqrt) {
			if (stringy) 
				return sqrtIm(buffImageText(e.vars.get(0), 42, h, false));
			return sqrtIm(expressionIm(e.subExpr.get(0),h));
		}
		
		if (e.op == Expr.Op.add) {
			
			BufferedImage im1 = e.varImgs.size()>=1 ? e.varImgs.get(0) : expressionIm(e.subExpr.get(0), h);
			BufferedImage im2 = e.varImgs.size()>=2 ? e.varImgs.get(1) : expressionIm(e.subExpr.get(1), h);
			return conc(new BufferedImage[] {im1,Utility.buffImageText("+", 1, h, false),im2},0,0);
		}
		
		
		
		return null;
	}
	
	
	
	public static void drawLocLine(LocVektor lv1, Graphics2D g2) {
		LocVektor lv = lv1.copy();

		drawLine(lv.x0, lv.y0, lv.x1, lv.y1, g2);
	}
	
	public static void drawHugeLine(LocVektor lv1, Graphics2D g2) {
		LocVektor lv = lv1.copy();
		lv.scaleToR(2000);
		drawLine(lv.x0, lv.y0, lv.x1, lv.y1, g2);
		lv.scale(-1);
		drawLine(lv.x0, lv.y0, lv.x1, lv.y1, g2);

	}
	
	public static void drawDottedLine(LocVektor lv1, Graphics2D g2, double spacing) {
		LocVektor lv = lv1.copy();
		if (lv.r < spacing)
			drawLine(lv.x0, lv.y0, lv.x1, lv.y1, g2);
		LocVektor lvsmall = lv.copy();
		lvsmall.scaleToR(spacing);
		LocVektor lvsmall2 = lvsmall.scaled(2);
		int amt = (int)(lv1.r/2/spacing);
		for (int i = 0; i<amt; i++) {
			drawLine(lvsmall.x0, lvsmall.y0, lvsmall.x1, lvsmall.y1, g2);
			lvsmall.translate(lvsmall2);
		}
		
	}
	
	public static void drawLine(double x0, double y0, double x1, double y1, Graphics2D g) {
		g.drawLine((int)x0, (int)y0, (int)x1, (int)y1);
	}
	
	
	public static double map(double a, double b, double x0, double x1, double x) {
		return a + (x-x0)/(x1-x0)*(b-a);
	}
	
	public static double map1(double a, double a0, double s) {
		return (a-a0)*s;
	}
	
	public static double map2(double a, double a0, double s) {
		return a/s + a0;
	}
	
	public static LocVektor map1V(LocVektor lv, double x0, double y0, double s) {
		return new LocVektor(map1(lv.x0, x0, s), map1(-lv.y0, y0, s), lv.x*s, lv.y*s);
	}
	
	
	public static double arrowLengthFactor = 1.0/10;
	public static double arrowLengthMax = 10, arrowLengthMin = 4;
	public static double arrowHalfAngle = Math.PI/6;
	public static LocVektor locArrow;
	
	
	public static void drawLocVector(LocVektor lv1, Graphics2D g) {
		if (lv1 == null) {
			return;
		}
		LocVektor lv = lv1.copy();
		lv.fix();
		drawLocLine(lv, g);
		
		if (lv.mag()<1) {
			return;
		}
		
		
		double arrowL = Math.min(arrowLengthMax, lv.mag()*arrowLengthFactor);
		arrowL = Math.max(arrowLengthMin, arrowL);
		locArrow = lv.copy();
		locArrow.translate(lv);
		locArrow.scaleToR(-arrowL);
		locArrow.rotate(-arrowHalfAngle);
		drawLocLine(locArrow, g);
		locArrow.rotate(2*arrowHalfAngle);
		drawLocLine(locArrow, g);
	}
	
	public static void drawLabelVector(LocVektor lv1, Graphics2D g) {
		// TODO Auto-generated method stub
		double oalf = arrowLengthFactor;
		arrowLengthFactor = 4.0/lv1.mag();
		LocVektor lv = lv1.copy();
		drawLocLine(lv, g);
		lv.fix();
		
		locArrow = lv.copy();
		locArrow.translate(lv);
		locArrow.scale(-arrowLengthFactor);
		locArrow.rotate(-arrowHalfAngle);
		drawLocLine(locArrow, g);
		locArrow.rotate(2*arrowHalfAngle);
		drawLocLine(locArrow, g);
		arrowLengthFactor = oalf;
	}
	
	public static void drawVecLine(LocVektor lv, Graphics2D g, double maxF, double maxB) {
		LocVektor lv2 = lv.copy();
		lv2.scaleToR(maxF);
		drawLocLine(lv2, g);
		lv2.scale(-maxB / maxF);
		drawLocLine(lv2, g);
	}
	
	static int xPos = 0;
	static int yPosTop;
	static int strW;
	static int fontsize = 0;
	public static void drawFancyString(String[] strings, int[] arrowed, double x, double y, Graphics2D g) {
		fontsize = g.getFont().getSize();
		xPos = (int)x;
		yPosTop = (int)y;
		Stroke stroke = g.getStroke();
		for (int i = 0; i<strings.length; i++) {
			String s = strings[i];
			String[] ssplit = s.split("\n");
			
			g.drawString(ssplit[0], xPos, yPosTop);
			
			for (int j = 1; j < ssplit.length; j++) {
				String line = ssplit[j];
			
				yPosTop += fontsize*5/4;
				
				xPos = (int)x;
				
				g.drawString(line, xPos, yPosTop);

			}
			strW = g.getFontMetrics().stringWidth(s);
			if (arrowed[i] == 1) {
				g.setStroke(new BasicStroke(1));
				drawLabelVector(new LocVektor(xPos, yPosTop-fontsize, strW, 0), g);
				g.setStroke(stroke);
			}
			xPos += strW;
		}
		
	}
	
	public static void drawHat(Graphics2D g, double x0, double y0, double w, double h) {
		drawLine(x0, y0, x0+w/2, y0-h, g);
		drawLine(x0+w, y0, x0+w/2, y0-h, g);

	}
	
	public static BufferedImage drawHat(BufferedImage im) {
		int top = 4;
		int w = im.getWidth();
		BufferedImage im2 = new BufferedImage(w,im.getHeight(),2);
		drawOver(im2, im, 0, top);
		Graphics2D g = (Graphics2D)im2.getGraphics();
		g.setColor(Color.black);
		g.setStroke(Constants.bs2);
		drawLine(w/2-3, top, w/2,0,g);
		drawLine(w/2+3, top, w/2,0,g);
		return im2;


	}
	
	public static BufferedImage unitVec(String v, int h) {
		return drawHat(Utility.buffImageText(v, 1,h,false));
	}

	
	public static Color randomColor() {
		return new Color((int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255));
	}
	
	public static Color randomColorDark() {
		return new Color((int)(Math.random()*255)/2, (int)(Math.random()*255/2), (int)(Math.random()*255/2));
	}
	
    public static List<Integer> findWord(String textString, String word) {
        List<Integer> indexes = new ArrayList<Integer>();
        String lowerCaseTextString = textString.toLowerCase();
        String lowerCaseWord = word.toLowerCase();

        int index = 0;
        while(index != -1){
            index = textString.indexOf(word, index);
            if (index != -1) {
                indexes.add(index);
                index++;
            }
        }
        return indexes;
    }

	
	public static double random(double a, double b) {
		return Math.random()*(b-a)+a;
	}
	
	public static int randInt(int a, int b) {
		return a + (int)random(0,b-a);
	}
	
	
	public static BufferedImage readImage(String file) {
		try {
			return ImageIO.read(new File(file));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	
	public static String readFile(String file) {
		try {
			List<String> l = Files.readAllLines(Path.of(file));
			String s = "";
			int size = l.size();
			for (int i = 0; i<size-1; i++) {
				s += l.get(i) + "\n";
			}
			if (size > 0)
			s += l.get(size-1);
			
			return s;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			return null;
		}
		
	}
	
	public static void appendFile(String file, String text) {
		try {
			FileWriter fw = new FileWriter(file, true);
		    BufferedWriter bw = new BufferedWriter(fw);
		    bw.write(text);
		    bw.newLine();
		    bw.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
	
	}
	
	public static List<String> splitSections(String text, String start, String end) {
		List<String> res = new ArrayList<>();
		int ind = text.indexOf(start);
		
		int startLen = start.length(), endLen = end.length();
		
		if (ind < 0) {
			res.add("0");
			res.add(text);
			return res;
		}
		if (ind == 0) {
			res.add("1");
			
		}
		else {
			res.add("0");
			res.add(text.substring(0, ind));
		}
		int ind2 = 0;
		while (ind >= 0) {
			ind2 = text.indexOf(end, ind+startLen);
			if (ind2 > 0) {
				res.add(text.substring(ind+startLen, ind2));
				ind = text.indexOf(start, ind2+endLen);
				if (ind > 0) {
					res.add(text.substring(ind2+endLen,ind));
				}
			}
			else {
				res.add(text.substring(ind+startLen, text.length()));
				return res;
			}
		}
		
		res.add(text.substring(ind2+endLen, text.length()));
		return res;
	}
	
	
	public static int countMatches(String s, String sub) {
		int count = 0;
		int ind = 0;
		do {
			ind = s.indexOf(sub, ind+sub.length());
			count++;
		} while (ind >= 0);
		return count;
	}
	
	public static void fillCircle(Graphics2D g, double xc, double yc, double r) {
		g.fillOval((int)(xc-r), (int)(yc-r), (int)(2*r), (int)(2*r));
	}
	
	
	public static void drawArc(Graphics2D g, double xc, double yc, double r, double a1, double a2) {
		g.drawArc((int)(xc-r), (int)(yc-r), (int)(2*r),(int)(2*r),(int)a1,(int)a2);
	}
	
	public static void regPoly(Graphics2D g, double xcent, double ycent, double rCirc, int n) {
		
	}
	
	public static void fillRect(Graphics2D g, double x0, double y0, double w, double h) {
		g.fillRect((int)(x0), (int)(y0), (int)(w), (int)(h));
	}
	
	public static void drawRect(Graphics2D g, double x0, double y0, double w, double h) {
		g.drawRect((int)(x0), (int)(y0), (int)(w), (int)(h));
	}

	
	public static void boundRect(Graphics2D g, LocVektor v) {
		double x0 = Math.min(v.x0, v.x1), y0 = Math.min(v.y0, v.y1);
		Utility.drawRect(g, x0, y0, Math.abs(v.x), Math.abs(v.y));
	}
	
	
	public static double[] calcField(double [][] chargeCoords, double[] charges, double xp, double yp) {
		int numC = Math.min(chargeCoords.length, charges.length);
		double[] res = new double[2];
		LocVektor lv = new LocVektor();
		for (int i = 0; i<numC; i++) {
			double[] ch = chargeCoords[i];
			if (ch.length < 2) continue;
			double dx = ch[0]-xp, dy = ch[1]-yp;
			if (dx == 0 && dy == 0) {
				return new double[] {0,0};
			}
			LocVektor cv = new LocVektor(xp, yp, dx, dy);
			cv.scaleToR(-charges[i] * 1/Math.sqrt(dx*dx + dy*dy));
			lv.add(cv);
		}
		
		return new double[] {lv.x, lv.y};
		
	}
	
	public static double[] maxmin(double[] vals) {
		double[] mm = new double[2];
		double max = vals[0], min = vals[0];
		
		for (int i = 0; i<vals.length; i++) {
			if (vals[i] < min) 
				min = vals[i];
			if (vals[i] > max) 
				max = vals[i];
		}
		
		mm[0] = min; mm[1] = max;
		return mm;
	}
	
	/*
	 * ax + by + c = 0
	 * returns [a, b, c] for line between points (x0, y0) and (x1, y2)
	 */
	public static double[] lineImplicit(double x0, double y0, double x1, double y1) {
		
		double[] coefficients = new double[3];
		double dx = x1-x0, dy = y1-y0;
		coefficients[0] = dy;
		coefficients[1] = -dx;
		coefficients[2] = y0*dx - x0*dy;
		return coefficients;
	}
	
	public static double distPointLine(double x, double y, double a, double b, double c) {
		return Math.abs(a*x + b*y + c) / Math.sqrt(a*a+b*b);
	}
	
	public static double[] projToLine(double x, double y, double a, double b, double c) {
		double[] point = new double[2];
		
		
		double par = b*x - a*y;
		point[0] = b*par - a*c;
		point[1] = -a*par - b*c;
		double sq = (a*a + b*b);
		point[0] /= sq;
		point[1] /= sq;
		
		return point;
	}
	
	public static double segmentRatio(double x0, double y0, double x1, double y1, double px, double py) {
		
		double dxl = x1-x0, dyl = y1-y0;
		double dxp = px - x0, dyp = py - y0;
		
		double ratio = Math.sqrt((dxp*dxp + dyp*dyp) / (dxl*dxl + dyl*dyl));
		if (dxl*dxp + dyl*dyp < 0) {
			return -ratio;
		}
		
		return ratio;
	}
	
	public static double[] proj;
	
	public static double distPointSegment(double x0, double y0, double x1, double y1, double x, double y) {
		double[] param = lineImplicit( x0,  y0,  x1,  y1);
		proj = projToLine( x,  y,  param[0],  param[1],  param[2] );
		double rat = segmentRatio(x0, y0, x1, y1, proj[0],proj[1]);
		if (rat < 0) {
			double dxp = x-x0, dyp=y-y0;
			return Math.sqrt(dxp*dxp + dyp*dyp);
		}
		if (rat > 1) {
			double dxp = x-x1, dyp=y-y1;
			return Math.sqrt(dxp*dxp + dyp*dyp);
		}
		
		return distPointLine(x, y, param[0], param[1], param[2]);
		
	}
	
	
	
	public static double distPointVec(LocVektor v, double x, double y) {
		return distPointSegment(v.x0, v.y0, v.x1, v.y1, x, y);
	}
	
	public static double roundInt(double a){ 
		double aabs = Math.abs(a);
		if (aabs - (int)aabs > 0.5) {
			aabs++;
		}
		if (a<0) {
			return -(int)aabs;
		}
		return (int)aabs;
	}
	
	public static double roundToDec(double a, double places) {
		double pow = Math.pow(10, places);
		return (int)(a*pow) / pow;
	}


	public static double tStartSec = System.nanoTime()/1e9;
	public static double t = tStartSec, tEl = 0;
	
	public static double tElapsedSec() {
		t = System.nanoTime() /1e9;
		tEl = t-tStartSec;
		return tEl;
	}
	
	
	public static void drawParallelogramRule(Graphics2D g, LocVektor v1, LocVektor v2) {
		g.setColor(Color.black);
		g.setStroke(Constants.bs1);
		LocVektor v1c = v1.copy(), v2c = v2.copy();
		v1c.translate(v2);
		v2c.translate(v1);
		Utility.drawLocLine(v1, g);
		Utility.drawLocLine(v2, g);
		g.setStroke(Constants.bs2);
		Utility.drawLocVector(LocVektor.add(v1,v2), g);
		
	}
	
	public static Map<String ,LocVektor> vertices(double r, int n, double a, double x0, double y0) {
		
		String al = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		
		Map<String, LocVektor> ver = new HashMap<>();
		ver.put("S", new LocVektor(0,0,x0,y0,true));
		for (int i = 0; i<n; i++) {
			ver.put(al.charAt(i)+"", LocVektor.add(LocVektor.polarVec(0,0,r, a + Math.PI*2/n*i),new LocVektor(0,0,x0,y0,true)));
		}
		
		
		
		return ver;
		
		
	}
	
	
}
