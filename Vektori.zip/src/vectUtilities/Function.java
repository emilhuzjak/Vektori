package vectUtilities;

public interface Function {

	
	double[] calc(double x, double y);
	
	
	
}
