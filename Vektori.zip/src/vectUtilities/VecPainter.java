package vectUtilities;

import java.awt.Graphics2D;

import mainpackage.VectorsCart;

public interface VecPainter {

	
	
	
	public void paint(Graphics2D g, VectorsCart cart);
	
	
}
