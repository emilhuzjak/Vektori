package mainpackage;

import javax.swing.JPanel;

public class ContentHolder extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6376144611743661034L;

	
	
	public ContentHolder previousContent() {
		return null;
	}
	
	
	
	
	
	
}
