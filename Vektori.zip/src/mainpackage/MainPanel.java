package mainpackage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import lessons.srednja.NewLesson;
import vectUtilities.Constants;
import vectUtilities.Utility;

public class MainPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7022884784293505441L;

	JPanel contentPanel = new JPanel();

	StartPanel sp = new StartPanel();
	NavPanel np = new NavPanel();

	JMenuBar navig = new JMenuBar();

	JButton backButton = new JButton("");
	JButton homepage = new JButton("Naslovna stranica");

	JPanel previousPanel;
	List<JPanel> previousPanels = new LinkedList<>();

	MainNavigation intro = new MainNavigation();
	JPanel content = intro;

	int w, h;

	public MainPanel() {
		backButton.addActionListener(l);
		
		
		
		
		// setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

		setBackground(new Color(200, 200, 255));

		b1.addActionListener(levelPick);
		b2.addActionListener(levelPick);
		b3.addActionListener(levelPick);
		btotal.addActionListener(levelPick);
		binfo.addActionListener(levelPick);
		navig.setBackground(new Color(220, 255, 220));
		
		backButton.setFocusPainted(false);
		
		homepage.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				replacePanel(intro, true);
			}
		});
		
		create.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				replacePanel(new NewLesson(), true);
			}
		});
		
		try {
			BufferedImage im = ImageIO.read(new File("Files/Images/back_btn_arrow.png"));
			if (im == null) {
				backButton.setText("<-- Natrag");
				return;
			}
			int wIm = im.getWidth(), hIm = im.getHeight();
			if (wIm > 30 || hIm > 20) {
				im = im.getSubimage(0, 0, Math.min(im.getWidth(), 30), Math.min(im.getHeight(), 20));
			}

			ImageIcon backIcon = new ImageIcon(im);
			if (backIcon != null)
				backButton.setIcon(backIcon);

			contentPanel.setBackground(Color.blue);
			// navig.setLayout(new FlowLayout());
		} catch (IOException e) {
		}

	}

	public void setContent() {

	}

	public void initGUI() {
		intro.initGUI();
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// setBackground(Color.red);
				// navig.add(backButton);
				add(navig);
				add(content);
				// contentPanel.add(intro);
				w = getWidth();
				h = getHeight();
				intro.setPreferredSize(getPreferredSize());
				//add(new JLabel("<html>Java<sup>TM</sup></html>"));
				revalidate();
				//repaint();
			}
		});
	}

	boolean repaint = true;

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		w = getWidth();
		h = getHeight();
		int bh = (int) backButton.getPreferredSize().getHeight();

		navig.setPreferredSize(new Dimension(w, bh));
		content.setPreferredSize(new Dimension(w, h - bh));
		revalidate();
	}

	ActionListener l = new ActionListener() {


		@Override
		public void actionPerformed(ActionEvent e) {
			back();
		}

	};

	static JButton b1 = new JButton("Osnovna škola"), b2 = new JButton("Srednja škola"),
			b3 = new JButton("Vaša poglavlja"), btotal = new JButton("Samo razgledavam"),
			binfo = new JButton("O aplikaciji"), create = new JButton("Stvaranje");

	ActionListener levelPick = new ActionListener() {


		@Override
		public void actionPerformed(ActionEvent e) {
			NavPanel np = new NavPanel();
			np.root = MainPanel.this;
			JButton s = (JButton)e.getSource();
			boolean found = false;
			if (s == b1) {
				np.level = 1;
				found = true;
			} else if (s == b2) {
				np.level = 2;
				found = true;
			} else if (s == b3) {
				np.level = 3;
				found = true;
			} else if (s == btotal) {
				np.level = 4;
				found = true;
			}
			if (found) {
				replacePanel(np, true);
			}
			
			else if (s == binfo) {
				JPanel jp = new JPanel();
				JTextArea infT = new JTextArea(Utility.readFile("Files/misc/info.txt"));
				
				
				infT.setFont(new Font("Arial", 0, Constants.fontSize));
				infT.setLineWrap(true);
				infT.setWrapStyleWord(true);
				
				
				
				SpecificLessonPanel infoP = new SpecificLessonPanel();
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						infoP.remove(infoP.controls);
					}
					
				});
				
				infoP.contents.add(infT);
				infoP.showQueue();
				replacePanel(infoP,true);
			}
		}

	};

	public void replacePanel(JPanel next, boolean queue) {
		if (next == content) {
			repaint();
			return;
		}
		
		navig.removeAll();
		
		if (previousPanels.size() > 0) {
			navig.add(backButton);
		}
		if (queue) {
			navig.add(backButton);
			previousPanels.add(0, content);
		}
		
		
		if (next != intro) {
			
			navig.add(homepage);
		}
		else {
			navig.remove(homepage);
		}
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				remove(content);
				
				w = getWidth();
				h = getHeight();
				next.setPreferredSize(new Dimension(w, h - navig.getHeight()));
				content = next;
				add(next);
				revalidate();
				repaint();
			}
		});

	}

	public void back() {
		if (previousPanels.size() == 0) {
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					navig.remove(backButton);
				}
			});

			return;
		}
		JPanel prev = previousPanels.remove(0);
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				
				replacePanel(prev, false);
				
//				if (intro == prev) {
//					navig.remove(homepage);
//					if (intro == content) {
//						repaint();
//						return;
//					}
//				}
//				removeAll();
//				add(navig);
//				content = prev;
//				add(content);
//				if (previousPanels.size() == 0) {
//					navig.remove(backButton);
//
//				}
				
				
				
				revalidate();
				repaint();
			}
		});

	}

	static class MainNavigation extends JPanel {

		
		private static final long serialVersionUID = 428597912307261292L;
		JLabel title = new JLabel("Vektori");
		JLabel instruct = new JLabel("Odaberite željenu razinu");

		
		int x = -1, y = -1;
		
		@Override
		public String toString() {
			return "Main page";
		}
		
		public MainNavigation() {
			
			setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
			title.setFont(new Font("Comic Sans", 3, 60));
			instruct.setFont(new Font("Arial", 3, 40));

			setBackground(new Color(150, 255, 150));
			b1.setFont(Constants.font1);
			b2.setFont(Constants.font1);
			b3.setFont(Constants.font1);
			btotal.setFont(Constants.font1);
			create.setFont(Constants.font1);
			binfo.setFont(Constants.font1);

			
			addMouseMotionListener(new MouseMotionListener() {
				
				@Override
				public void mouseMoved(MouseEvent e) {
					x = e.getX(); y = e.getY();
					repaint();
				}
				
				@Override
				public void mouseDragged(MouseEvent e) {
				}
			});
			
		}

		public void initGUI() {
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					
					add(title);
					add(instruct);
					
					JPanel leftParent = new JPanel();
					JPanel left = new JPanel();
					
					left.setPreferredSize(new Dimension(300, 250));
					left.setLayout(new GridLayout(5,1));
					left.add(b1);
					left.add(b2);
					left.add(b3);
					JPanel buf = new JPanel();
					buf.setOpaque(false);
					left.setOpaque(false);
					left.add(buf);
					left.add(btotal);
					leftParent.add(left);
					add(leftParent);
					leftParent.setOpaque(false);
					add(Box.createVerticalGlue());
					
					JPanel rightParent = new JPanel();

					JPanel right = new JPanel();
					right.setPreferredSize(new Dimension(300,50));
					right.setLayout(new GridLayout(1,2));
					right.add(create);
					right.add(binfo);
					rightParent.add(right);
					right.setOpaque(false);
					rightParent.setOpaque(false);
					add(rightParent);
				}
			});
		}

		boolean first = true;

		
		
		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			
			int wi = getWidth(), hi = getHeight();
			int dw = 75, dh = 75;
			
			g.setColor(Constants.dark_green2);
			Graphics2D g2 = (Graphics2D)g;
			
			for (int i = 0; i<wi; i += dw) {
				for (int j = 0; j<hi; j += dh) {
					LocVektor lv = new LocVektor(i, j, x, y, true);
					lv.scaleToR(Math.min(20, Math.sqrt((i-x)*(i-x)+(j-y)*(j-y))));
					Utility.drawLocVector(lv, g2);
				}
			}
			
//			try {
//				BufferedImage im = ImageIO.read(new File("Files/Images/ilustr/triangle.png"));
//				g.drawImage(im, 0, 0, null);
//				im = ImageIO.read(new File("Files/Images/ilustr/polar.png"));
//				g.drawImage(im, 300, 0, null);
//
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
			
			
			
		}

	}

}
