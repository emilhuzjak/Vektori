package mainpackage;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import sim.LinComb;

public class Sandbox extends JPanel {


	private static final long serialVersionUID = -6932000854097428976L;

	public Sandbox() {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				LinComb lc = new LinComb();
				LocVektor a = new LocVektor(-6,1, 3, 0), b = new LocVektor(-5,-1, 4, 1);
				lc.a = a; lc.b = b;
				lc.paralellogram = false;
				lc.init();
				JButton par = new JButton("Pravilo paralelograma");
				lc.add(par);
				par.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						if (lc.paralellogram) {
							lc.paralellogram = false;
							par.setText("Pravilo paralelograma");
						}
						else {
							lc.paralellogram = true;
							par.setText("Pravilo trokuta");
						}
					}
				});
				JButton animB = new JButton("Kreni");
				animB.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						lc.animate();
					}
				});
				lc.add(animB);
				add(lc);
			}
			
		});
		
	}
	
	
}
