package mainpackage;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import exercises.ExerciseSelection;
import exercises.Quiz;
import lessons.SpecificLessonPanel;
import lessons.osnovna.Intro;
import lessons.srednja.Svojstva;

public class NavPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2992075067456433118L;

	
	MainPanel root;
	
	int level = -1;
	
	SpecificLessonPanel[] studyLevel = new SpecificLessonPanel[] {
		new Intro(), new Svojstva(), new Intro(), new Intro()
	};
	
	List<JButton> buttonslist = new ArrayList<>();
	
	JButton[] buttons = new JButton[] {new JButton("Nauči"),new JButton("Istraži"),new JButton("Izvježbaj"),new JButton("Provjeri")};
	JButton b1 = buttons[0], b2 = buttons[1], b3 = buttons[2], b4 = buttons[3];
	public NavPanel() {

		GridLayout layout = new GridLayout(2,2);
		setLayout(layout);
		
		
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (int i = 0; i<4; i++) {
					Font butFont = new Font("Consolas", 2, 40);
					JButton button = buttons[i];
					button.setFont(butFont);
					//button.setBorderPainted(false);
					button.setFocusPainted(false);
					//button.setContentAreaFilled(false);
					int g = 150 + (int)((i/4.0)*100);
					//button.setBackground(i==1 || i==2 ? new Color(220,220,250): new Color(250,220,220));
					button.setBackground(i==1 || i==2 ? new Color(100,150,150): new Color(150,150,100));
					
					add(button);
					
					button.addActionListener(l);

				}
				
			}
		});
		
		
	}
	
	ActionListener l = new ActionListener() {



		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource() == buttons[0]) {
				if (level < 1 || level > studyLevel.length)
					root.replacePanel(new Intro(), true);
				else {
					root.replacePanel(studyLevel[level-1], true);
				}
				
			}
			else if (e.getSource() == buttons[1]) {

				root.replacePanel(new Sandbox(), true);
				
			}
			else if (e.getSource() == buttons[2]) {
				root.replacePanel(new ExerciseSelection(), true);

			}
			
			else if (e.getSource() == buttons[3]) {
				root.replacePanel(new Quiz(level-1), true);
			}
		}
		
	};
	
}
