package mainpackage;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JPanel;

import vectUtilities.Mapper;
import vectUtilities.MouseHandler;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class VectorsCart extends JPanel {

	private static final long serialVersionUID = 6343472925141133827L;

	public boolean containsMouse = false;

	public VecPainter prePainter, painter;

	public VectorsCart() {

		setBackground(Color.cyan);
		setPreferredSize(new Dimension(500, 500));
		initialize();
		mapper = new Mapper();

	}

	public void initialize() {
		w = getWidth();
		h = getHeight();
		numVectors = vecList.size();
	}

	public int id = -1;

	public void setup() {
		if (mapper == null) {
			mapper = new Mapper();
		}
		mapper.reset(x0, y0 + yCoordSpan, xunit, yunit);
		mh.mapper = mapper;
		mh.action = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				repaint();
			}
		};
		mh.dragEnabled = draggy;
		mh.hoverEnabled = hoverEnabled;
		mh.map = true;
		mh.putVectors(vecList, whichDragBase, whichDragTip, whichHoverBase, whichHoverTip);
		// mh.putVectors(Arrays.asList(vectors), Arrays.asList(new Integer[] {1,1}),
		// Arrays.asList(new Integer[] {1,1}));
		if (draggy || hoverEnabled) {
			addMouseListener(mh);
			addMouseMotionListener(mh);
		}
		
	}

	public void putVector(LocVektor v, int dragTip, int dragBase) {
		putVector(v, dragTip, dragBase, 0, 0);
		vecList.add(v);
		whichDragTip.add(dragTip);
		whichDragBase.add(dragBase);
		numVectors = vecList.size();
		visible.add(1);
	}

	public void putVector(LocVektor v, int dragTip, int dragBase, int hoverTip, int hoverBase) {
		vecList.add(v);
		whichDragTip.add(dragTip);
		whichDragBase.add(dragBase);
		whichHoverTip.add(hoverTip);
		whichHoverBase.add(hoverBase);
		numVectors = vecList.size();
		visible.add(1);
	}

	public Mapper mapper;

	public MouseHandler mh = new MouseHandler();
	boolean firstRender = true;

	public void setPainter(VecPainter p) {
		painter = p;
	}

	public void adjustAspect() {
		double xunit1 = w / xCo;
		double yunit1 = h / yCo;
		if (xunit1 > yunit1) {
			yCoordSpan = h / xunit1;
			yunit = xunit1;
			xunit = xunit1;
		} else if (yunit1 > xunit1) {

			xCoordSpan = w / yunit1;
			yunit = yunit1;
			xunit = yunit1;
		}
		x0 = -xCoordSpan / 2;
		y0 = -yCoordSpan / 2;
		mapper.reset(x0, y0 + yCoordSpan, xunit, yunit);

	}

	public boolean gridLines = true;
	public boolean drawAxes = true;

	public boolean draggy = false, hoverEnabled = true;
	public List<Integer> whichDragTip = new ArrayList<>(), whichDragBase = new ArrayList<>();
	public List<Integer> whichHoverTip = new ArrayList<>(), whichHoverBase = new ArrayList<>();

	public boolean customColors = false;
	public List<Color> colors = new ArrayList<>();

	public List<Integer> visible = new ArrayList<>();

	public LocVektor[] vectors = {};
	public List<LocVektor> vecList = new ArrayList<>(), screenVecs = new ArrayList<>();
	public int numVectors = 0;
	public double xCoordSpan = 20;
	public double x0 = -8;
	public double yCoordSpan = 20;
	public double y0 = -8;
	public double scaling;

	double x00 = x0, y00 = y0, xCo = xCoordSpan, yCo = yCoordSpan;
	
	public double xunit, yunit;

	int w, h;

	public boolean drawLabels = false;
	public List<String> labels = new ArrayList<>();

	public void generateRandomVectors(int num) {
		numVectors = num;
		// vectors = new LocVektor[num];
		vecList.clear();
//		whichHoverTip.clear();
//		whichHoverBase.clear();
		for (int i = 0; i < num; i++) {
			int xr, yr;
			int attempt = 0;
			do {
				xr = (int) ((Math.random() - 0.5) * xCoordSpan);
				yr = (int) ((Math.random() - 0.5) * yCoordSpan);
				attempt++;
			} while (xr == 0 || yr == 0 || attempt > 100);
			LocVektor lv = new LocVektor(xr, yr);
			lv.add(lv);
			lv.fix();
//			whichDragTip.add(0);
//			whichDragBase.add(0);
		}
	}

	public int xs;
	public int ys;

	public void map(double x, double y) {

		xs = (int) ((x - x0) * xunit);
		ys = h - (int) ((y - y0) * yunit);

	}

	Graphics2D g2D;

	public void drawLocLine(LocVektor lv1) {
		LocVektor lv = lv1.copy();
		map(lv.x0, lv.y0);

		double x0v = xs, y0v = ys;
		map(lv.x0 + lv.x, lv.y0 + lv.y);
		drawLine(x0v, y0v, xs, ys);
	}

	double arrowLengthFactor = 1.0 / 10;
	double arrowHalfAngle = Math.PI / 6;
	LocVektor locArrow;

	public void drawLocVector(LocVektor lv1) {
		LocVektor lv = lv1.copy();
		drawLocLine(lv);
		lv.fix();

		map(lv.r, 0);

		if (xs / yunit < 2)
			return;

		locArrow = lv;
		locArrow.translate(lv);
		locArrow.scale(-arrowLengthFactor);
		locArrow.rotate(-arrowHalfAngle);
		drawLocLine(locArrow);
		locArrow.rotate(2 * arrowHalfAngle);
		drawLocLine(locArrow);
	}

	public void drawLine(double xl0, double yl0, double xl1, double yl1) {
		g2D.drawLine((int) xl0, (int) yl0, (int) xl1, (int) yl1);
	}

	public double giveDot() {
		if (vecList.size() > 1) {
			double dot = vecList.get(0).dot(vecList.get(1));
			return dot;
		}
		return 0;
	}

	public double giveAngle() {
		double dot = giveDot();
		return Math.acos(dot / (vecList.get(0).mag() * vecList.get(1).mag())) * 180 / Math.PI;
	}

	public int nearestInt(double d) {
		//double absd = Math.abs(d);
//		double space = absd - (int) absd;
//		int res = (int) d;
//		if (space > 0.5) {
//			res++;
//		}
		return (int) Math.round(d);
	}

	int sizeFont = 20;

	public boolean prePaint = true, paint = true;
	public boolean paintSuper = true;
	
	int paintBuffms = 50;
	double tms = 0;
	
	public boolean truePaint = false;
	
	public boolean rotate = false;
	public double angleRotRad = Math.PI/4;
	
	public List<VecPainter> painters = new ArrayList<>();
	public boolean otherPainters = true;
	
	public boolean setVert = true;
	
	public void paintComponent(Graphics g) {

		if (paintSuper)
			super.paintComponent(g);
		

		
		g2D = (Graphics2D) g;
		g2D.setColor(Color.black);
		if (rotate) {
			map(0,0);
			g2D.rotate(angleRotRad,xs,ys);
		}
		if (prePainter != null && prePaint) {
			prePainter.paint(g2D, this);
		}
		int wold = w, hold = h;
		w = getParent().getWidth();
		h = getHeight();
		if (wold != w || hold != h || firstRender) {
			adjustAspect();
			firstRender = false;
		}
		
		setPreferredSize(new Dimension(w, setVert ? 300 : (int)getPreferredSize().getHeight()));

		if (gridLines) {
			for (double i = x0 + 0.1; i < x0 + xCoordSpan; i++) {
				int ii = (int) Math.round(i);
				map(ii, 0);
				drawLine(xs, 0, xs, h);
				g.drawString((int) ii + "", xs, ys - 3);
			}
			for (double i = y0 + 0.1; i < y0 + yCoordSpan; i++) {
				int ii = (int) Math.round(i);
				map(0, ii);

				drawLine(0, ys, w, ys);
				g.drawString((int) ii + "", xs + 1, ys - 3);
			}
		}
		g2D.setStroke(new BasicStroke(3));
		map(0, 0);
		if (drawAxes) {
			drawLine(0, ys, w, ys);
			drawLine(xs, 0, xs, h);
		}
		g2D.setColor(Color.blue);
		g2D.setFont(new Font("Arial", 1, sizeFont));
		for (int i = 0; i < numVectors; i++) {
			if (visible.get(i).equals(0)) {
				continue;
			}
			LocVektor l = vecList.get(i);
			l.fix();

			if (customColors && colors.size() > i) {
				g2D.setColor(colors.get(i));
			}
			LocVektor mappedV = mapper.mapToScreen(l);
			LocVektor dir = mappedV.copy();
			dir.scaleToR(sizeFont);
			Utility.drawLocVector(mappedV, g2D);
			if (drawLabels) {
				Utility.drawFancyString(new String[] { labels.get(i) }, new int[] { 1 }, mappedV.x1 + dir.x,
						mappedV.y1 + dir.y, g2D);
			}
		}

		if (rotate) {
			g2D.rotate(-angleRotRad);
		}
		
		if (painter != null && paint) {
			painter.paint(g2D, this);
			
		}
		if (otherPainters) {
			for (VecPainter vp : painters) {
				vp.paint(g2D, this);
			}
		}
		if (truePaint) {
			paint = true;
			prePaint = true;
			truePaint = false;
		}

	}

	double xco, yco;

	public void mapreverse(double x, double y) {
		xco = (x / xunit) + x0;
		yco = (h - y) / yunit + y0;
	}

	public int held = -1;

	public void mapAllToScreen() {
		screenVecs.clear();
		if (mapper != null) {
			for (LocVektor v : vecList) {
				screenVecs.add(mapper.mapToScreen(v));
			}
		}
	}

	public VectorsCart copy() {

		VectorsCart copy = new VectorsCart();
		copy.containsMouse = containsMouse;
		copy.prePainter = prePainter;
		copy.painter = painter;

		copy.id = id+1;
		copy.gridLines = gridLines;
		copy.drawAxes = drawAxes;
		copy.draggy = draggy;
		
		for (int i = 0; i<numVectors; i++) {
			copy.whichDragTip.add(whichDragTip.get(i).intValue());
			copy.whichHoverTip.add(whichHoverTip.get(i).intValue());
			copy.whichDragBase.add(whichDragBase.get(i).intValue());
			copy.whichHoverBase.add(whichHoverBase.get(i).intValue());
		}
		
		copy.hoverEnabled = hoverEnabled;
//		copy.whichDragTip.addAll(whichDragTip);
//		copy.whichHoverTip.addAll(whichHoverTip);
		copy.customColors = customColors;
		copy.colors.addAll(colors);
		copy.visible.addAll(visible);

		copy.vectors = Arrays.copyOf(vectors, vectors.length);
		
		for(LocVektor v : vecList) {
			copy.vecList.add(v.copy());
		}
		for(LocVektor v : screenVecs) {
			copy.screenVecs.add(v.copy());
		}
		
		copy.numVectors = numVectors;
		copy.xCoordSpan = xCoordSpan;
		copy.x0 = x0;
		copy.yCoordSpan = yCoordSpan;
		copy.y0 = y0;
		copy.scaling = scaling;
		copy.xunit = xunit;
		copy.yunit = yunit;

		copy.w = w;
		copy.h = h;
		copy.drawLabels = drawLabels;
		copy.labels.addAll(labels);
		copy.xco = xco;
		copy.yco = yco;
		copy.held = held;
		copy.initialize();
		copy.setup();

		copy.mh.r = mh.r;
		
		return copy;
	}

}
