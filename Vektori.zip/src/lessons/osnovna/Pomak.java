package lessons.osnovna;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Pomak extends SpecificLessonPanel {


	@Override
	public SpecificLessonPanel nextPanel() {
		return new Suprotni();
	}

	String path = "Files/lessons/osnovna/tocke/";

	private static final long serialVersionUID = 2255220829698539908L;

	
	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	public Pomak() {
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");
		
		
		addNewText(texts[0]);
		queueText();
		
		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0, 0, 0.1, 0.1), 1, 1, 0, 0);
		vc1.x0 = -1;
		vc1.y0 = -0.5;
		vc1.xCoordSpan = 2;
		vc1.yCoordSpan = 1;
		vc1.drawAxes = false;
		vc1.gridLines = false;
		vc1.initialize();
		vc1.setup();
		vc1.setBackground(Color.CYAN);
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor lv = cart.mh.mapper.mapToScreen(cart.vecList.get(0));
				
				g.setFont(new Font("Arial", 1, 25));
				g.setColor(Color.red);
				g.drawString("A", (int) lv.x0, (int) lv.y0);
				g.drawString("B", (int) lv.x1, (int) lv.y1);
				g.setColor(Color.black);

				Utility.drawFancyString(new String[] { "AB" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);

			}

		};
		contents.add(vc1);
		
		addNewText(texts[1]);
		queueText();
		
		showQueue();
		
//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				addContent(vc1);
//				addContent(t2);
////				addContent(vc2);
////				addContent(t2);
////				addContent(vc3);
//			}
//		});
	}

}
