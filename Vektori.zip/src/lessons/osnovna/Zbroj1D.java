package lessons.osnovna;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.DoubleSlider;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Zbroj1D extends SpecificLessonPanel {

	private static final long serialVersionUID = 2231285320503938391L;

	public SpecificLessonPanel nextPanel() {
		return new Zbroj2D();
	}

	String path = "Files/lessons/osnovna/zbroj1D/";

	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	boolean moving = false;
	
	public Zbroj1D() {

		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		t1 = new VektorTextArea();
		addNewText(texts[0]);
queueText();
		double scalar[] = new double[] { 2, 2 };

		vc1 = new VectorsCart();
		LocVektor a = new LocVektor(-5, 2, 3, 0), b = new LocVektor(-5, 0, 3, 0);
		LocVektor add = LocVektor.add(a, b);
		add.translateTo(-5, -2);

		vc1.putVector(a, 1, 0, 0, 0);
		vc1.putVector(b, 1, 0, 0, 0);
		vc1.putVector(add, 0, 0, 0, 0);

		vc1.x0 = -20;
		vc1.y0 = -10;
		vc1.xCoordSpan = 40;
		vc1.yCoordSpan = 20;
		vc1.drawAxes = false;
		vc1.gridLines = false;
		vc1.initialize();
		vc1.setup();
		vc1.mh.r = 10;

		int[] stopped = new int[] {0,0,0};
		
		double dt = 0.05;
		ActionListener actt = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (stopped[0] == 0) 
					a.x0 += dt * a.x;
				if (stopped[1] == 0) 
					b.x0 += dt * b.x;
				if (stopped[2] == 0) 
					add.x0 += dt * add.x;
				a.fix();
				b.fix();
				add.fix();
				
				
				vc1.repaint();
			}
		};
		double boxsize = 20;

		Timer t = new Timer(50, actt);
		Constants.timers.add(t);

		vc1.prePainter = new VecPainter() {

			
			int rightMarg = 200;
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {

				add.x = a.x + b.x;
				a.y1 = a.y0;
				b.y1 = b.y0;
				a.fixLength(); b.fixLength();
				LocVektor lv;

				cart.mapAllToScreen();
				int wi = cart.getWidth();
				g.setFont(new Font("Arial", 1, 30));
				g.setColor(Color.black);
				lv = cart.screenVecs.get(0);
				Utility.drawFancyString(new String[] { "A" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2,
						g);
				if (lv.x0 > wi - rightMarg) {
					stopped[0] = 1;
				}
				Utility.drawString(g, "Samo A", 20, lv.y0);
				lv = cart.screenVecs.get(1);
				Utility.drawFancyString(new String[] { "B" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2,
						g);
				if (lv.x0 > wi - rightMarg) {
					stopped[1] = 1;
				}
				Utility.drawString(g, "Samo B", 20, lv.y0);

				lv = cart.screenVecs.get(2);
				Utility.drawFancyString(new String[] { "A", " + ", "B" }, new int[] { 1, 0, 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				if (lv.x0 > wi - rightMarg) {
					stopped[2] = 1;
				}
				Utility.drawString(g, "A i B zajedno", 20, lv.y0);

				if (stopped[0] == 1 && stopped[1] == 1  && stopped[2] == 1 ) {
					t.stop();
				}
				
				g.setColor(Constants.brownCol);
				Utility.fillRect(g, lv.x0-boxsize, lv.y0-boxsize/2, boxsize, boxsize);
				lv = cart.screenVecs.get(1);
				Utility.fillRect(g, lv.x0-boxsize, lv.y0-boxsize/2, boxsize, boxsize);
				lv = cart.screenVecs.get(0);
				Utility.fillRect(g, lv.x0-boxsize, lv.y0-boxsize/2, boxsize, boxsize);
			}

		};
		
		JButton jb = new JButton("Kreni");
		ActionListener actjb = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!moving) {
					moving = true;
					t.start();
					jb.setText("Stani");
				}
				else {
					moving = false;
					a.x0 = -5; a.fix();
					b.x0 = -5; b.fix();
					add.x0 = -5; add.fix();
					t.stop();
					jb.setText("Kreni");
					stopped[0] = 0; stopped[1] = 0; stopped[2] = 0;
					vc1.repaint();
				}
			}
		};
		jb.addActionListener(actjb);
		vc1.add(jb);
		contents.add(vc1);
		
		
		

		t2 = new VektorTextArea();
		addNewText(texts[1]);
		queueText();
		
		LocVektor v2v1 = new LocVektor(0, 0, 1, 1), v2v2 = new LocVektor(1, -1, 0.707, 0.707);
		
		//---------------------------------------------------------------
		vc2 = new VectorsCart();
		LocVektor a2 = new LocVektor(-5, 2, 6, 0), b2 = new LocVektor(-5, 0, -3, 0);
		LocVektor add2 = LocVektor.add(a, b);
		add2.translateTo(-5, -2);

		vc2.putVector(a2, 1, 0, 0, 0);
		vc2.putVector(b2, 1, 0, 0, 0);
		vc2.putVector(add2, 0, 0, 0, 0);

		vc2.x0 = -20;
		vc2.y0 = -10;
		vc2.xCoordSpan = 40;
		vc2.yCoordSpan = 20;
		vc2.drawAxes = false;
		vc2.gridLines = false;
		vc2.initialize();
		vc2.setup();
		vc2.mh.r = 10;

		int[] stopped2 = new int[] {0,0,0};
		
		ActionListener actt2 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (stopped2[0] == 0) 
					a2.x0 += dt * a2.x;
				if (stopped2[1] == 0) 
					b2.x0 += dt * b2.x;
				if (stopped2[2] == 0) 
					add2.x0 += dt * add2.x;
				a2.fix();
				b2.fix();
				add2.fix();
				
				
				vc2.repaint();
			}
		};
		
		double time;
		
		Timer t2 = new Timer(50, actt2);
		Constants.timers.add(t2);

		vc2.prePainter = new VecPainter() {

			
			int rightMarg = 200;
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {

				add2.x = a2.x + b2.x;
				a2.y1 = a2.y0;
				b2.y1 = b2.y0;
				a2.fixLength(); b2.fixLength();
				LocVektor lv;

				cart.mapAllToScreen();
				int wi = cart.getWidth();
				g.setFont(new Font("Arial", 1, 30));
				g.setColor(Color.black);
				lv = cart.screenVecs.get(0);
				Utility.drawFancyString(new String[] { "A" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2,
						g);
				if (lv.x0 > wi - rightMarg) {
					stopped2[0] = 1;
				}
				Utility.drawString(g, "Samo A", 20, lv.y0);
				lv = cart.screenVecs.get(1);
				Utility.drawFancyString(new String[] { "B" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2, (lv.y0 + lv.y1) / 2,
						g);
				if (lv.x0 > wi - rightMarg) {
					stopped2[1] = 1;
				}
				Utility.drawString(g, "Samo B", 20, lv.y0);

				lv = cart.screenVecs.get(2);
				Utility.drawFancyString(new String[] { "A", " + ", "B" }, new int[] { 1, 0, 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				if (lv.x0 > wi - rightMarg) {
					stopped2[2] = 1;
				}
				Utility.drawString(g, "A i B zajedno", 20, lv.y0);

				if (stopped2[0] == 1 && stopped2[1] == 1  && stopped2[2] == 1 ) {
					t2.stop();
				}
				
				g.setColor(Constants.brownCol);
				Utility.fillRect(g, lv.x0-boxsize, lv.y0-boxsize/2, boxsize, boxsize);
				lv = cart.screenVecs.get(1);
				Utility.fillRect(g, lv.x0-boxsize, lv.y0-boxsize/2, boxsize, boxsize);
				lv = cart.screenVecs.get(0);
				Utility.fillRect(g, lv.x0-boxsize, lv.y0-boxsize/2, boxsize, boxsize);
			}

		};
		
		JButton jb2 = new JButton("Kreni");
		ActionListener actjb2 = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!moving) {
					moving = true;
					t2.start();
					jb2.setText("Stani");
				}
				else {
					moving = false;
					a2.x0 = -5; a2.fix();
					b2.x0 = -5; b2.fix();
					add2.x0 = -5; add2.fix();
					t2.stop();
					jb2.setText("Kreni");
					stopped2[0] = 0; stopped2[1] = 0; stopped2[2] = 0;
					vc2.repaint();
				}
			}
		};
		jb2.addActionListener(actjb2);
		vc2.add(jb2);

		contents.add(vc2);
		
		t3 = new VektorTextArea();
		addNewText(texts[2]);
		queueText();
		
		showQueue();
		
//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				
//				addContent(vc1);
//				addContent(Zbroj1D.this.t2);
//				addContent(vc2);
//				addContent(t3);
//
//			}
//		});

		addContent(vc2);

	}

}
