package lessons.osnovna;

import java.awt.Color;
import java.awt.Graphics2D;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.Question;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;
import vectUtilities.VectorHint;

public class Koord extends SpecificLessonPanel {

	
	private static final long serialVersionUID = -1343338834730810970L;

	String path = "Files/lessons/osnovna/koord/";

	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new KompVec();
	}
	
	JTextArea jta1 = new JTextArea(), jta2 = new JTextArea();
	
	boolean moving = false;
	
	public Koord() {

		jta1.setFont(Constants.font40);
		jta2.setFont(Constants.font40);

		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();
		
		
		vc1 = new VectorsCart();
		vc1.setBackground(Color.cyan);
		//vc1.gridLines = false;
		LocVektor lv = new LocVektor(0,0,1,1);
		vc1.putVector(lv, 0,0,1,0);
		vc1.visible.set(0,0);
		vc1.hoverEnabled = true;
		vc1.draggy = true;
		vc1.mh.r = 500;
		vc1.initialize(); vc1.setup();
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.map(0,0);
				g.setFont(Constants.font1);
				double xs1 = cart.xs, ys1 = cart.ys;
				g.drawString("y", cart.xs+10, 30);
				g.drawString("x", cart.getWidth()-50, cart.ys+10);
				
				LocVektor v = cart.vecList.get(0);

				
				cart.map(v.x1, v.y1);
				
				g.setColor(Color.red);
				Utility.fillCircle(g, cart.xs, cart.ys, 7);
				
				g.setColor(Color.orange);
				Utility.drawLine(xs1, cart.ys, cart.xs, cart.ys,g);
				Utility.drawLine(cart.xs, ys1, cart.xs, cart.ys,g);
				double xp = (int)(v.x*10)/10.0, yp = (int)(v.y*10)/10.0;
				g.setColor(Color.black);
				Utility.drawString(g, "x = " + xp, (cart.xs+xs1)/2, cart.ys);
				Utility.drawString(g, "y = " + yp, cart.xs, (cart.ys+ys1)/2 );

				jta1.setText("(" + (int)(v.x*10)/10.0 + ", " + + (int)(v.y*10)/10.0 + ")");
				
			}
			
		};
		
		contents.add(vc1);
		contents.add(jta1);
		
		
		addNewText(texts[1]);
		queueText();
		JPanel pythP = new JPanel();
		pythP.add(new JLabel(new ImageIcon((Utility.readImage("Files/images/form/pyth.png")))));
		contents.add(pythP);
		
		vc2 = new VectorsCart();
		LocVektor lv2 = new LocVektor(0,0,1,1);
		vc2.putVector(lv2, 0,0,1,0);
		vc2.mh.r = 500;
		vc2.initialize(); vc2.setup();
		vc2.setBackground(Color.cyan);
		
		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.map(0,0);
				g.setFont(Constants.font1);
				double xs1 = cart.xs, ys1 = cart.ys;
				g.drawString("y", cart.xs+10, 30);
				g.drawString("x", cart.getWidth()-50, cart.ys+10);
				
				LocVektor v = cart.vecList.get(0);

				
				
				cart.map(v.x1, v.y1);
				
				g.setColor(Color.red);
				Utility.fillCircle(g, cart.xs, cart.ys, 7);
				
				g.setColor(Color.orange);
				Utility.drawLine(xs1, cart.ys, cart.xs, cart.ys,g);
				Utility.drawLine(cart.xs, ys1, cart.xs, cart.ys,g);
				double xp = (int)(v.x*10)/10.0, yp = (int)(v.y*10)/10.0;
				g.setColor(Color.black);
				Utility.drawString(g, "x = " + xp, (cart.xs+xs1)/2, cart.ys);
				Utility.drawString(g, "y = " + yp, cart.xs, (cart.ys+ys1)/2 );

				jta2.setText("r = " + (int)(v.r*10)/10.0);
				
			}
			
		};
		contents.add(vc2);
		contents.add(jta2);
		
		

		contents.add(new Question(Constants.quadrantQ, new String[] {"I.", "II.", "III.", "IV."}, 2));
		contents.add(new VectorHint(Constants.quadrantA));
		
		
		//---------------------------------------------------------------
		showQueue();



	}
	
	
}
