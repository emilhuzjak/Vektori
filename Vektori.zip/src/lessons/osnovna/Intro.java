package lessons.osnovna;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.Question;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;
import vectUtilities.VectorHint;


public class Intro extends SpecificLessonPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8546798545389109392L;

	String path = "Files/lessons/osnovna/uvod/";
	
	@Override
	public SpecificLessonPanel nextPanel() {
		return new Smjer();
	}
	
	
	VectorsCart vc1 = new VectorsCart();
	
	BufferedImage imPlane, imTree;
	
	
	
	VecPainter painter1 = new VecPainter() {

		
		ActionListener l = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (cartt != null) {
					cartt.repaint();
				}
			}
		};
		
		Timer t = new Timer(50, l);
		
		double x0 = 0, y0 = 0, dt = 0.1;
		int n = 5;
		
		VectorsCart cartt;
		
		double time = System.nanoTime() / 1e9;
		boolean start = true;
		boolean paused = false;
		@Override
		public void paint(Graphics2D g, VectorsCart cart) {
			if (start) {
				Constants.timers.add(t);
				t.start();
				start = false;
			}
			cartt = cart;
			
			if (!cart.containsMouse && !paused) {
				t.stop();
				paused = true;
			}
			if (cart.containsMouse && paused) {
				t.start();
				paused = false;
			}
			
			
			LocVektor lv = cart.vecList.get(0);
			if (lv.r > 100) {
				lv.scaleToR(100);
			}
			
			
			cart.map(0,0);
			
			
			
			double newT = System.nanoTime() / 1e9;
			dt = newT - time;
			x0 -= dt * lv.x; y0 += dt * lv.y * vc1.getHeight() / vc1.getWidth();
			time = newT;
			
			
			
			if (imTree != null) {
				
				
				double[] xc = new double[n], yc = new double[n];
				double dxt = cart.xCoordSpan/n*vc1.xunit, dyt = cart.yCoordSpan/n * vc1.yunit;
				double x1 = (int)(x0/dxt*200), y1 = (int)(y0/dyt*200);
				for (int i = 0; i<n; i++) {
					xc[i] = x1 + dxt*i;
					yc[i] = y1 + dyt*i;
				}
				
				for (int i = 0; i<n; i++) {
					for (int j = 0; j<n; j++) {
						g.drawImage(imTree, (int)(xc[i]), (int)(yc[j]), null);
					}
					
				}
				
			}
			
			if (imPlane != null) {
				g.rotate(-lv.angle, vc1.xs, vc1.ys);
				g.drawImage(imPlane, (int)(vc1.xs-imPlane.getWidth()/2), (int)(vc1.ys-imPlane.getHeight()/2), null);
				g.rotate(lv.angle, vc1.xs, vc1.ys);
			}
			g.setColor(Color.black);
			g.fillRect(10,10,250,70);
			g.setColor(Color.yellow);
			g.drawString("Brzinomjer: " + (int)(lv.r*100)/100 + " km/h", 20, 30);
			g.drawString("Smjer: prikazan strelicom", 20, 60);
			
		}
	};
	
	
	
	
	
	public Intro() {
		super();
		BufferedImage b1 = null, b2 = null;
		try {
			b1 = ImageIO.read(new File("Files/images/plane.png"));
			b2 = ImageIO.read(new File("Files/images/tree.png"));
		} catch (IOException e) {
			e.printStackTrace();
			
		}
		
		
		
		imPlane = b1; imTree = b2;
		
		Runnable r = new Runnable() {
			
			@Override
			public void run() {
				VektorTextArea text1 = new VektorTextArea();
				addNewText(Utility.readFile(path + "1.txt"));
				queueText();
//				text1.readVecText(Utility.readFile(path + "1.txt"));
//				addContent(text1);
				vc1.draggy = false;
				vc1.hoverEnabled = true;
				vc1.gridLines = false;
				vc1.drawAxes = false;
				vc1.mh.vc = vc1;
				vc1.mh.r = 1000;
				vc1.x0 = -200; vc1.y0 = -200; vc1.xCoordSpan = 400; vc1.yCoordSpan = 400;
				vc1.setBackground(new Color(0, 255, 100));
				
				
				LocVektor v = new LocVektor(0,0,100,50);
				
				vc1.painter = painter1;
				vc1.putVector(v, 0, 0, 1, 0);
				vc1.adjustAspect();
				vc1.initialize(); vc1.setup();
				vc1.mh.r = 500;
				contents.add(vc1);
				//addContent(vc1);
				
				
				
				contents.add(new Question("Temperatura je vektorska količina?", new String[] {"Da", "Ne"}, 1));
				contents.add(new VectorHint("Iako temperatura može rasti i padati, ona nema smjer u prostoru."));

				
				
				
				//VektorTextArea text2 = new VektorTextArea();
				
				addNewText(Utility.readFile(path + "2.txt"));
				queueText();
				
				VectorsCart vv = new VectorsCart();
				vv.customColors = true;
				vv.colors = Arrays.asList(new Color[] {Color.black, Color.blue});
				vv.putVector(new LocVektor(0,0,1,1),1,1,1,1);
				vv.visible.set(0,0);
				vv.hoverEnabled = true;
				LocVektor lvdist = new LocVektor(-2,-1,5, 6);
				vv.putVector(lvdist,0,0,0,0);

				vv.prePainter = new VecPainter() {
					
					@Override
					public void paint(Graphics2D g, VectorsCart cart) {
						double x = cart.mh.xmov, y = cart.mh.ymov;
						double[] xy = cart.mh.mapper.mapFromScreen(x,y);
						Stroke s = g.getStroke();
						g.setStroke(new BasicStroke(5));
						double dist = Utility.distPointVec(lvdist, xy[0],xy[1]);
						if (dist < 20/cart.xunit) {
							cart.colors.set(1, Color.red);
//							g.setColor(Color.red);
						}
						else {
							cart.colors.set(1, Color.blue);

						}
						g.setStroke(s);
						cart.map(Utility.proj[0], Utility.proj[1]);
						
//						Utility.drawLocVector(lvdist, g);
						Utility.fillCircle(g,cart.xs, cart.ys,5);
					}
				};
				vv.setup();vv.initialize();
				
				contents.add(vv);
				
				
				showQueue();
			}
		};
		
		SwingUtilities.invokeLater(r);
	}
	
	
	
	int sizeFont;
	
	public void initContent() {}
	


	
	
	
	
	

	
	
	
}
