package lessons.osnovna;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import sim.LinComb;
import textDisplays.VektorTextArea;
import vectUtilities.Utility;

public class Razlika2D extends SpecificLessonPanel{

	private static final long serialVersionUID = -7001119459815694634L;

	public SpecificLessonPanel nextPanel() {
		return new Koord();
	}

	String path = "Files/lessons/osnovna/razlika2D/";

	LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	boolean moving = false;
	
	public Razlika2D() {

		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();


		lc = new LinComb();
		LocVektor a = new LocVektor(-10,0, 3,0), b = new LocVektor(-5,-1, 1,-3);
		lc.a = a; lc.b = b;
		lc.a2 = -1;
		//lc.paralellogram = false;
		
		lc.init();
		lc.labels = Arrays.asList(new String[] {"u", "v", "u", "v", "w"});
		JButton animB = new JButton("Kreni");
		animB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lc.animate();
			}
		});
		lc.add(animB);
		//add.translateTo(-5, -2);
		contents.add(lc);

		addNewText(texts[1]);
		queueText();
		
		lc2 = new LinComb();
		LocVektor a2 = new LocVektor(-10,0, 3,0), b2 = new LocVektor(-5,-1, 1,-3);
		lc2.a = a2; lc2.b = b2;
		//lc2.a2 = -1;
		lc2.init();
		lc2.labels = Arrays.asList(new String[] {"u", "v", "u", "v", "w"});
		JButton animB2 = new JButton("Kreni");
		animB2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lc2.animate();
			}
		});
		lc2.add(animB2);
		contents.add(lc2);
		//---------------------------------------------------------------
		
		showQueue();

//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				
//				addContent(lc);
//				addContent(Razlika2D.this.t2);
//				addContent(lc2);
//				//addContent(t3);
//
//			}
//		});


	}
	
	
}
