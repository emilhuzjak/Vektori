package lessons.osnovna;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import sim.LinComb;
import textDisplays.VektorTextArea;
import vectUtilities.Utility;

public class Zbroj2D extends SpecificLessonPanel {


	private static final long serialVersionUID = -917319952638198644L;

	public SpecificLessonPanel nextPanel() {
		return new Razlika2D();
	}

	String path = "Files/lessons/osnovna/zbroj2D/";

	LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3;

	boolean moving = false;
	
	public Zbroj2D() {

		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		t1 = new VektorTextArea();
		addNewText(texts[0]);
		queueText();

		lc = new LinComb();
		LocVektor a = new LocVektor(-6,1, 3, 0), b = new LocVektor(-5,-1, 4, 1);
		lc.a = a; lc.b = b;
		lc.paralellogram = false;
		lc.init();
		JButton animB = new JButton("Kreni");
		animB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lc.animate();
			}
		});
		lc.add(animB);
		contents.add(lc);
		//add.translateTo(-5, -2);
		

		t2 = new VektorTextArea();
		addNewText(texts[1]);
		queueText();
		
		lc2 = new LinComb();
		LocVektor a2 = new LocVektor(-10,3, 3,5), b2 = new LocVektor(-10,-3, 1,-3);
		lc2.a = a2; lc2.b = b2;
		lc2.paralellogram = true;
		lc2.init();
		lc2.labels = Arrays.asList(new String[] {"u", "v", "u", "v", "w"});
		JButton animB2 = new JButton("Kreni");
		animB2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				lc2.animate();
			}
		});
		lc2.add(animB2);
		contents.add(lc2);
		
		//---------------------------------------------------------------
		
		showQueue();

//		SwingUtilities.invokeLater(new Runnable() {
//
//			@Override
//			public void run() {
//				addContent(t1);
//				
//				addContent(lc);
//				addContent(Zbroj2D.this.t2);
//				addContent(lc2);
//				//addContent(t3);
//
//			}
//		});
//
//
	}
	
}
