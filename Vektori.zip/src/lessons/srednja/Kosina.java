package lessons.srednja;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Arrays;

import javax.swing.JButton;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Kosina extends SpecificLessonPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7301151541750920873L;

	String path = "Files/lessons/srednja/kosina/";

	// LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3, t4, t5;

	@Override
	public SpecificLessonPanel nextPanel() {
		return new VektMnoz();
	}
	
	public Kosina() {
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();
		
		addNewText(texts[1]);
		queueText();
		vc2 = new VectorsCart();
		LocVektor v1 = new LocVektor(0,0,3.8,2.1), v2 = new LocVektor(0,0,4.5, -2);

		vc2.putVector(new LocVektor(0,0,3.8,2.1),0,0,0,0);
		vc2.putVector(new LocVektor(0,0,4.5, -2),0,0,0,0);
		vc2.customColors = true;
		vc2.colors = Arrays.asList(new Color[] {Color.red, Color.blue});
		
		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				g.setFont(Constants.font30);
				g.setColor(Color.red);

				//g.drawString(Constants.theta,100,200);
				g.setColor(Color.red);
//				Utility.drawFancyString(new String[] {"u"},new int[] {1},50,50, g);
//				g.setColor(Color.black);
//				g.setFont(Constants.font1);
//				Utility.drawFancyString(new String[] {"Projekcija ", "u", " na pravac"},new int[] {0,1,0},250,200, g);

			}
		};
		
		
		
		contents.add(vc2);
		addNewText(texts[2]);
		queueText();

		vc3 = new VectorsCart();
		vc3.drawAxes = false;
		vc3.gridLines = false;
		vc3.setBackground(new Color(153, 217, 234));

		vc3.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				g.setFont(Constants.font30);
				g.setColor(Color.red);

				g.setColor(Color.blue);
				Utility.drawFancyString(new String[] {"52.9"+Constants.theta},new int[] {0},50,50, g);

				g.setColor(Color.black);
				g.setFont(Constants.font1);
				Utility.drawFancyString(new String[] {"Projekcija ", "u", " na pravac"},new int[] {0,1,0},250,200, g);
				Utility.drawFancyString(new String[] {"Projekcija ", "v", " na pravac"},new int[] {0,1,0},250,240, g);

			}
			
		};
		
		contents.add(vc3);
		
		
		showQueue();
		
		
		addNewText(texts[3]);
		queueText();
		
		contents.add(new VectorsCart());

		
		addNewText(texts[4]);
		queueText();
		
		VectorsCart vc4 = new VectorsCart();
		vc4.rotate = true;
		vc4.angleRotRad = Math.PI/6;
		contents.add(vc4);
		vc4.setBackground(new Color(153, 217, 234));
		LocVektor g = new LocVektor(0,-3);
		g.rotate(Math.PI/6);
		vc4.putVector(g,0,0);
		vc4.putVector(g.xComp(),0,0);
		vc4.putVector(g.yComp(),0,0);

		addNewText(texts[5]);
		queueText();
		
		
		

	}

	
	
}
