package lessons.srednja;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import gui.PanelLink;
import lessons.SpecificLessonPanel;
import lessons.osnovna.Zbroj2D;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Comp extends SpecificLessonPanel {


	private static final long serialVersionUID = -8474780828380878342L;
	public SpecificLessonPanel nextPanel() {
		return new CompCalc();
	}

	String path = "Files/lessons/srednja/komponente/";

	VectorsCart vc1, vc2, vc3;
	VektorTextArea t1, t2, t3, t4, t5;

	boolean moving = false;
	
	public Comp() {

		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();

		JPanel jp = new JPanel();
		jp.add(new PanelLink("Podsjeti?", new Zbroj2D()));
		contents.add(jp);
		
		addNewText(texts[1]);
		queueText();
		
		vc1 = new VectorsCart();
		LocVektor v1 = new LocVektor(-0.1, -0.1, 0.3, 0.3);
		vc1.putVector(v1, 1, 0, 0, 0);
//		vc1.x0 = -5;
//		vc1.y0 = -5;
//		vc1.xCoordSpan = 10;
//		vc1.yCoordSpan = 10;
		
		vc1.drawAxes = false;
		vc1.gridLines = false;
		double x = Utility.random(-5,5), y = Utility.random(-2,2);
		vc1.putVector(new LocVektor(-0.1,-0.1,x,y, true), 1, 0, 0, 0);
		vc1.putVector(new LocVektor(x, y, v1.x1, v1.y1, true), 0,0, 0, 0);
		vc1.colors = Arrays.asList(new Color[] {Color.red, Color.blue, Color.blue});
		vc1.customColors = true;
		vc1.initialize();
		vc1.setup();
		vc1.setBackground(Color.CYAN);
		vc1.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor vdiff = LocVektor.sub(vc1.vecList.get(0), vc1.vecList.get(1));
				//vdiff.add(vc1.vecList.get(2));
				vc1.vecList.set(2, vdiff);
				System.out.println(cart.vecList.get(0));
				//vc1.vecList.get(2).translateTo(vc1.vecList.get(1).x1, vc1.vecList.get(1).y1);
				System.out.println(cart.x0 + " " + cart.xCoordSpan);
			}
			
		};
		contents.add(vc1);
		
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				LocVektor lv = //cart.mh.mapper.mapToScreen(cart.vecList.get(1));
						cart.screenVecs.get(1);
				g.setFont(new Font("Arial", 1, 25));
				g.setColor(Color.black);
				Utility.drawFancyString(new String[] { "a" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				
				lv = cart.mh.mapper.mapToScreen(cart.vecList.get(2));
				Utility.drawFancyString(new String[] { "b" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				
				lv = cart.mh.mapper.mapToScreen(cart.vecList.get(0));
				Utility.drawFancyString(new String[] { "v" }, new int[] { 1 }, (lv.x0 + lv.x1) / 2,
						(lv.y0 + lv.y1) / 2, g);
				
				

				

			}

		};
		
		//contents.add(vc1);
		
		addNewText(texts[2]);
		queueText();
		
		
		
		VectorsCart vc1c = vc1.copy();
		
		vc1c.prePainter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor vdiff = LocVektor.sub(cart.vecList.get(0), cart.vecList.get(1));
				//vdiff.add(cart.vecList.get(2));
				cart.vecList.set(2, vdiff);
				double angle = cart.vecList.get(1).angleTo(cart.vecList.get(2));
				
				g.setFont(new Font("Arial", 1, 25));
				
				if (Math.abs(angle-Math.PI/2) / Math.PI < 0.01) {
					g.setColor(Constants.dark_green1);
					g.drawString("Uspjeh", 10, 50);
				}
				else {
					g.setColor(Color.red);
					//g.drawString("Pribrojnici nisu okomiti", 10, 50);
				}
				//cart.vecList.get(2).translateTo(cart.vecList.get(1).x1, cart.vecList.get(1).y1);
			}
		};
		
		contents.add(vc1c);
		
		addNewText(texts[3]);
		queueText();
		
		vc2 = new VectorsCart();
//		vc2.x0 = -5; vc2.y0=-5;
//		vc2.xCoordSpan = 10; vc2.yCoordSpan = 10;
		vc2.putVector(new LocVektor(0,0,3,2),0,0,1,0);
		vc2.putVector(new LocVektor(0,0,3,0),0,0,0,0);
		vc2.putVector(new LocVektor(0,0,0,2),0,0,0,0);
		vc2.hoverEnabled = true;
		
		vc2.customColors = true;
		vc2.colors.add(0,Color.blue);
		vc2.colors.add(1,Color.yellow);
		vc2.colors.add(2,Color.yellow);
		vc2.initialize(); vc2.setup();
		vc2.mh.r = 500;
		
		vc2.prePainter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				LocVektor v = cart.vecList.get(0);
				cart.vecList.set(1,v.xComp());
				cart.vecList.set(2,v.yComp());

				LocVektor compx = v.xComp(), compy = v.yComp();
				compx.translate(compy); compy.translate(compx);
				g.setColor(Color.red);
				g.setStroke(new BasicStroke(1));
				LocVektor cxs = cart.mh.mapper.mapToScreen(compx), cys = cart.mh.mapper.mapToScreen(compy);
				Utility.drawLocLine(cxs, g);
				Utility.drawLocLine(cys, g);
				
				g.setFont(Constants.font1);
				
				Utility.drawString(g, "a = "+Utility.roundToDec(compx.x,1), (cxs.x0+cxs.x1)/2, (cxs.y0+cxs.y1)/2);
				Utility.drawString(g, "b = "+Utility.roundToDec(compy.y,1), (cys.x0+cys.x1)/2, (cys.y0+cys.y1)/2);
				g.setColor(Color.black);
				
			}
		};
		
		contents.add(vc2);
		
		JPanel pythP = new JPanel();
		pythP.add(new JLabel(new ImageIcon((Utility.readImage("Files/images/form/pyth.png")))));
		contents.add(pythP);
		
		addNewText(texts[4]);
		queueText();
		
		VTextPane vtp;
		
		vc3 = vc2.copy();
		vc3.putVector(new LocVektor(0,0,1,0),0,0,0,0);
		vc3.putVector(new LocVektor(0,0,0,1),0,0,0,0);
		vc3.colors.add(3,Color.green);
		vc3.colors.add(4,Color.green);
		vc3.painter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				lastPane.setText("");
				continueText("#veca#/vec = "+Utility.roundToDec(vc3.vecList.get(0).x,1) + "#veci#/vec + "
						+ Utility.roundToDec(vc3.vecList.get(0).y,1) + "#vecj#/vec");
			}
		};
		
		
		contents.add(vc3);
		
		addNewText("#veca#/vec = "+Utility.roundToDec(vc3.vecList.get(0).x,1) + "#veci#/vec + "
				+ Utility.roundToDec(vc3.vecList.get(0).y,1) + "vecj#/vec");
		queueText();
		vtp = lastPane;
		
		

		
		vtp.setPreferredSize(new Dimension(100, 200));
		showQueue();


		
		


	}
}
