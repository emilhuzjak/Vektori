package lessons.srednja;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Arrays;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VektorTextArea;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class VektMnoz extends SpecificLessonPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6552445493853465581L;

	
	@Override
	public SpecificLessonPanel nextPanel() {
		return this;
	}

	String path = "Files/lessons/srednja/vekt_mnoz/";

	public VektMnoz() {
		
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		
		VektorTextArea text1 = new VektorTextArea();

		text1.readVecText(texts[0]);
		addContent(text1);
		VectorsCart vc1 = new VectorsCart();
		vc1.setBackground(Color.cyan);
		vc1.customColors = true;
		vc1.colors = Arrays.asList(new Color[] {Color.blue, Color.red, Color.black});
		LocVektor v1 = new LocVektor(0, 0, 0.1, 0), v2 = new LocVektor(0, 0, 0.1, 0.1);
		vc1.putVector(v1, 1, 0, 0, 0);
		vc1.putVector(v2, 1, 0, 0, 0);
		vc1.putVector(new LocVektor(0, 0, 0, 5*LocVektor.crossLength(v1, v2)), 0, 0, 0, 0);
		vc1.x0 = -1;
		vc1.y0 = -0.5;
		vc1.xCoordSpan = 2;
		vc1.yCoordSpan = 1;
		vc1.drawAxes = false;
		vc1.gridLines = false;
		vc1.initialize();
		vc1.setup();
		vc1.mh.r = 10;
		vc1.prePainter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				// TODO Auto-generated method stub
				double[] map = cart.mh.mapper.mapToScreen(0,0);
				
				Utility.drawLine(0, map[1], 2000, map[1], g);
				LocVektor yAx = new LocVektor(map[0],map[1], 100,0);
				yAx.rotate(-0.9);
				Utility.drawLocLine(yAx, g);
				yAx.scale(-1);
				Utility.drawLocLine(yAx, g);
				yAx.scale(-1);
				
				Utility.drawString(g, "x", getWidth()-10, map[1]);
				Utility.drawString(g, "y", yAx.x1, yAx.y1);

			}
		};
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				// TODO Auto-generated method stub

				LocVektor lv1 = cart.vecList.get(0), lv2 = cart.vecList.get(1);
				
				cart.vecList.set(2, new LocVektor(0, 0, 0, 5*LocVektor.crossLength(lv1, lv2)));
				cart.mapAllToScreen();
				
				Utility.drawFancyString(new String[] {"a"}, new int[] {1}, cart.screenVecs.get(0).x1, cart.screenVecs.get(0).y1, g);
				Utility.drawFancyString(new String[] {"b"}, new int[] {1}, cart.screenVecs.get(1).x1, cart.screenVecs.get(1).y1, g);
				Utility.drawFancyString(new String[] {"a", "x", "b"}, new int[] {1,0,1}, cart.screenVecs.get(2).x1, cart.screenVecs.get(2).y1, g);
			}

		};
		addContent(vc1);
		
		
		
		VektorTextArea text2 = new VektorTextArea();
		text2.readVecText(texts[1]);
		addContent(text2);

		

		

	}
	
	
	
	
}
