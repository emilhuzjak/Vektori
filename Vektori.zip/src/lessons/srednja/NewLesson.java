package lessons.srednja;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import lessons.SpecificLessonPanel;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import vectUtilities.Constants;
import vectUtilities.VecPainter;

public class NewLesson extends SpecificLessonPanel {

	
	

	private static final long serialVersionUID = -2354921155473011586L;

	JButton spremi = new JButton("Spremi");
	
	
	List<VTextPane> texts = new ArrayList<>();
	
	
	public NewLesson() {
		VTextPane vtp = new VTextPane();
		vtp.setEditable(true);
		vtp.setFont(Constants.font2);
		addContent(new JButton("Spremi"));

		
		
		
		
		addContent(vtp);
		addContent(new JTextArea(""));
		addContent(new JButton("Dodaj"));
		
		VectorsCart vc = new VectorsCart();
		vc.gridLines = vc.drawAxes = false;
		vc.painter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				int[] x = new int[] {50,100,200}, y = new int[] {200,50,200};
				g.setColor(Color.black);
				g.drawPolygon(x, y, 3);
				g.setColor(Color.red);
				g.fillPolygon(x,y,3);
			}
		};
		addContent(vc);
		
		JPanel jp = new JPanel();
		jp.add(new JButton("   "));
		jp.add(new JButton("   "));
		jp.add(new JButton("   "));
		addContent(jp);
		
		VTextPane vtp1 = new VTextPane();
		vtp1.setEditable(true);
		addContent(vtp1);
		addContent(new JButton("Poveznica"));
	}
	
	
	
	
}
