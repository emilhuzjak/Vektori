package lessons.srednja;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JPanel;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class Proj extends SpecificLessonPanel {

	private static final long serialVersionUID = -6869605401107018250L;

	public SpecificLessonPanel nextPanel() {
		return new SkalMnoz();
	}

	String path = "Files/lessons/srednja/proj/";

	// LinComb lc, lc2;
	VectorsCart vc1, vc2, vc3, vc4;
	VektorTextArea t1, t2, t3, t4, t5;

	public Proj() {
		String[] texts = Utility.readFile(path + "1.txt").split("#break#");

		addNewText(texts[0]);
		queueText();

		vc1 = new VectorsCart();
		vc1.putVector(new LocVektor(0, 0, 2, 3), 1, 1, 0, 0);
		vc1.putVector(new LocVektor(0, 0, -1, 3), 1, 0, 0, 0);
		vc1.visible.set(0, 0);
		vc1.visible.set(1, 0);

		vc1.initialize();
		vc1.setup();
		vc1.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				LocVektor lineV = cart.screenVecs.get(0), dotV = cart.screenVecs.get(1);
				Utility.fillCircle(g, lineV.x1, lineV.y1, 7);
				Utility.fillCircle(g, lineV.x0, lineV.y0, 7);

				Utility.drawHugeLine(lineV, g);
				g.setColor(Color.red);
				Utility.fillCircle(g, dotV.x1, dotV.y1, 7);
				g.setFont(Constants.font1);
				Utility.drawString(g, "T", dotV.x1, dotV.y1);
				Utility.distPointVec(lineV, dotV.x1, dotV.y1);
				double xp = Utility.proj[0], yp = Utility.proj[1];
				Utility.fillCircle(g, xp, yp, 7);
				Utility.drawString(g, "T'", xp, yp);
				g.setColor(Color.yellow);
				Utility.drawDottedLine(new LocVektor(dotV.x1, dotV.y1, xp,yp,true), g, 10);
				
				
				
			}
		};
		contents.add(vc1);
		addNewText(texts[1]);
		queueText();
		vc2 = new VectorsCart();
		vc2.putVector(new LocVektor(0, 0, 2, 2,true), 1, 1, 0, 0);
		vc2.putVector(new LocVektor(1,2, -1, 3,true), 1, 1, 0, 0);
		

		vc2.visible.set(0, 0);
		vc2.visible.set(1, 0);
		vc2.initialize(); vc2.setup();
		
		
		//vc2.colors = Arrays.asList(new Color[] { Color.red, Color.blue });

		vc2.painter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.mapAllToScreen();
				LocVektor lineV = cart.screenVecs.get(0), dotV = cart.screenVecs.get(1);
				Utility.fillCircle(g, lineV.x1, lineV.y1, 7);
				Utility.fillCircle(g, lineV.x0, lineV.y0, 7);
				Utility.drawHugeLine(lineV, g);
				
				g.setColor(Color.red);
				Utility.fillCircle(g, dotV.x1, dotV.y1, 7);
				Utility.fillCircle(g, dotV.x0, dotV.y0, 7);
				Utility.drawLocLine(dotV, g);
				g.setFont(Constants.font1);
				Utility.drawString(g, "A", dotV.x1, dotV.y1);
				Utility.distPointVec(lineV, dotV.x1, dotV.y1);
				double xp = Utility.proj[0], yp = Utility.proj[1];
				Utility.fillCircle(g, xp, yp, 7);
				Utility.drawString(g, "A'", xp, yp);
				
				Utility.drawString(g, "B", dotV.x0, dotV.y0);
				Utility.distPointVec(lineV, dotV.x0, dotV.y0);
				double xp1 = Utility.proj[0]; double yp1 = Utility.proj[1];
				Utility.fillCircle(g, xp1, yp1, 7);
				Utility.drawString(g, "B'", xp1, yp1);
				g.setColor(Color.yellow);
				Utility.drawDottedLine(new LocVektor(dotV.x0, dotV.y0, xp1,yp1,true), g, 10);
				Utility.drawDottedLine(new LocVektor(dotV.x1, dotV.y1, xp,yp,true), g, 10);
				
			}
		};

		contents.add(vc2);
		addNewText(texts[2]);
		queueText();
		
		BufferedImage projim = Utility.conc(new BufferedImage[]
				{Utility.buffImageText("u", 1, 25, true), Utility.buffImageText("v", 1, 20, true)}, 0,-1),
		fracUnit = Utility.frac(Utility.buffImageText("v", 1,20,true),Utility.drawModulus(Utility.buffImageText("v", 1,20,true)));
		
		VTextPane vtp0 = new VTextPane();
		vtp0.insertImage(projim);
		contents.add(vtp0);
		vc3 = new VectorsCart();
		vc3.putVector(new LocVektor(0, 0, 2, 2,true), 1, 0, 0, 0);
		vc3.putVector(new LocVektor(0,0, -1, 3,true), 1, 0, 0, 0);
		vc3.putVector(new LocVektor(0,0, -1, 3,true), 1, 0, 0, 0);

		vc3.customColors = true;
		vc3.colors = Arrays.asList(new Color[] {Color.blue, Color.red, Color.black});

		
		vc3.initialize(); vc3.setup();

		vc3.prePainter = new VecPainter() {

			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				cart.vecList.set(2, cart.vecList.get(0).projOn( cart.vecList.get(1)));
			}

		};
		vc3.painter = new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {

				g.setFont(Constants.font30);
				g.setColor(cart.colors.get(0));
				cart.mapAllToScreen();
				LocVektor u =  cart.screenVecs.get(0), v =  cart.screenVecs.get(1), uv =  cart.screenVecs.get(2);
				u.mid();
				Utility.drawFancyString(new String[] {"u"}, new int[] { 1 }, u.midx, u.midy, g);

				g.setColor(cart.colors.get(1));
				v.mid();
				Utility.drawFancyString(new String[] {"v"}, new int[] { 1 }, v.midx, v.midy, g);

				g.setColor(cart.colors.get(2));
				uv.mid();
				Utility.drawFancyString(new String[] {"u"}, new int[] { 1 }, uv.midx, uv.midy, g);
				Utility.drawFancyString(new String[] {"v"}, new int[] { 1 }, uv.midx+20, uv.midy+10, g);
				
				g.setStroke(Constants.bs1);
				Utility.drawHugeLine(v, g);
				Utility.drawDottedLine(LocVektor.sub(u, uv), g, 10);
				
			}
		};

		contents.add(vc3);
		
		
		
	

		addNewText(texts[3]);
		queueText();

		VTextPane vtp = new VTextPane();

		vtp.insertImage(projim);
		vtp.readVecText(" = |#vecu#/vec| cos" + Constants.theta);
		vtp.insertImage(Utility.unitVec("v", 25));
		vtp.readVecText("\n= |#vecu#/vec| cos" + Constants.theta + " ");
		vtp.insertImage(fracUnit);
		
		contents.add(vtp);

		addNewText(texts[4]);
		queueText();
		VTextPane vtp20 = new VTextPane();
		vtp20.setPreferredSize(new Dimension(1,100));

		VTextPane vtp2 = new VTextPane();
		vtp2.setPreferredSize(new Dimension(1,400));
		vc4 = vc3.copy();
		vc4.painters.add(new VecPainter() {
			
			@Override
			public void paint(Graphics2D g, VectorsCart cart) {
				vtp20.setText("");
				vtp20.readVecText("#vecu#/vec = "+cart.vecList.get(0).VText(2) + "\n#vecv#/vec = "+cart.vecList.get(1).VText(2)
						 + "\n" + Constants.theta + " = " +
						Utility.roundToDec(cart.vecList.get(0).angleTo(cart.vecList.get(1))*180/Math.PI, 1)+Constants.deg);
			}
		});

		contents.add(vc4);
		JPanel discP = new JPanel();
		JButton discB = new JButton("Otkrij");
		discP.add(discB);
		contents.add(discP);
		contents.add(vtp20);
		contents.add(vtp2);
		
		discB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				LocVektor u = vc4.vecList.get(0), v = vc4.vecList.get(1), uv = vc4.vecList.get(2);
				vtp2.setText("");
				vtp2.readVecText("|#vecu#/vec| = "+Utility.roundToDec(u.r, 2)
					+ "\n|#vecv#/vec| = "+Utility.roundToDec(v.r, 2)+"\n");
				BufferedImage unv = Utility.unitVec("v", 20), imv = Utility.buffImageText("v", 1, 20, true);
				vtp2.insertImage(unv);
				vtp2.readVecText(" = ");
				vtp2.insertImage(Utility.frac(unv, Utility.drawModulus(imv)));
				vtp2.readVecText("\n = ");
				vtp2.insertImage(Utility.frac(Utility.buffImageText(Utility.roundToDec(v.x,2)+"", 1, 20, false),
						Utility.buffImageText(Utility.roundToDec(v.r,2)+"", 1, 20, false)));
				vtp2.readVecText("#veci#/vec + ");
				vtp2.insertImage(Utility.frac(Utility.buffImageText(Utility.roundToDec(v.y,2)+"", 1, 20, false),
						Utility.buffImageText(Utility.roundToDec(v.r,2)+"", 1, 20, false)));
				vtp2.readVecText("= " + v.unit().VText(2)+"\n\n");
				vtp2.insertImage(projim);
				vtp2.readVecText("= |#vecu#/vec| cos" + Constants.theta+"\n");
				
				vtp2.readVecText("= " + u.projOn(v).VText(2));
				vtp2.insertImage(Constants.checkMarkImg);
			}
		});

		
		addNewText(texts[5]);
		queueText();

		
		showQueue();
		
	}

}
