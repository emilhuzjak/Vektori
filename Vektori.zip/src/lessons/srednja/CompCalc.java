package lessons.srednja;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import lessons.SpecificLessonPanel;
import mainpackage.LocVektor;
import mainpackage.VectorsCart;
import textDisplays.VTextPane;
import textDisplays.VektorTextArea;
import vectUtilities.Constants;
import vectUtilities.Utility;
import vectUtilities.VecPainter;

public class CompCalc extends SpecificLessonPanel {


		private static final long serialVersionUID = -8474780828380878342L;
		public SpecificLessonPanel nextPanel() {
			return new KolinUvod();
		}

		String path = "Files/lessons/srednja/komp_calc/";

		//LinComb lc, lc2;
		VectorsCart vc1, vc2, vc3;
		VektorTextArea t1, t2, t3, t4, t5;

		boolean moving = false;
		
		public CompCalc() {

			String[] texts = Utility.readFile(path + "1.txt").split("#break#");

			addNewText(texts[0]);
			queueText();

			
			
			VectorsCart[] vcs = new VectorsCart[2];
			
			vc1 = new VectorsCart(); vc2 = new VectorsCart();
			vc1.setBackground(Color.cyan); vc2.setBackground(Color.green);
			vcs[0] = vc1; vcs[1] = vc2;
			
			JPanel jp = new JPanel();
			jp.setLayout(new GridLayout(1,2));
			jp.setPreferredSize(new Dimension(500,300));
			
			LocVektor a = new LocVektor(0,0,2,1), b = new LocVektor(0,0,4,2);
			LocVektor[] vecs = new LocVektor[] {a,b};
			
			for (int i = 0; i<2; i++) {

				//contents.add(vcs[i]);
				VectorsCart v = vcs[i], vother = vcs[1-i];
				
				JPanel jp2 = new JPanel();
				jp2.add(v);
				jp.add(jp2);
				
				v.putVector(vecs[i], 1, 0, 0, 0);
				
//				v.xCoordSpan = 10;
//				v.yCoordSpan = 5;
				
				v.mh.r = 500;
				v.draggy = true;
				v.hoverEnabled = false;
				v.initialize(); v.setup();
				Integer ii = Integer.valueOf(i);
				v.prePainter = new VecPainter() {
					VectorsCart vo = vother;
					@Override
					public void paint(Graphics2D g, VectorsCart cart) {
						double sc = 2;
						if (ii==1) sc = 0.5;
						double thisR = cart.vecList.get(0).r;
						vo.vecList.get(0).scaleToR(thisR*sc);
						vo.vecList.get(0).setAngle(cart.vecList.get(0).angle);
						vo.prePaint = false; vo.paint = false;
						vo.truePaint = true;
						vo.repaint();
						
						
					}
					
				};
				
			}
			
			contents.add(jp);
			vc1.repaint();
			vc2.repaint();
			
			addNewText(texts[1]);
			queueText();
			

			
			
			addNewText(texts[2]);
			queueText();
			
			
			
			
			
			addNewText(texts[3]);
			queueText();
			
			
			
			addNewText(texts[4]);
			queueText();
			
			
			
			//vtp.setPreferredSize(new Dimension(100, 500));
			showQueue();




		}
}
